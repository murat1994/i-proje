import {
  GET_TRAILERS_PENDING,
  GET_TRAILERS_FULFILLED,
  GET_TRAILERS_REJECTED,
} from "../actionTypes/trailersActionTypes";

const initialState = {
  trailers: [],
  loading: false,
  error: {},
};
const getTrailersReducer = (state = initialState, action) => {
  switch (action.type) {
    case GET_TRAILERS_PENDING:
      return { ...state, loading: true };

    case GET_TRAILERS_FULFILLED:
      return { ...state, loading: false, trailers: action.payload };

    case GET_TRAILERS_REJECTED:
      return { ...state, loading: false, error: action.payload };
    default:
      return state;
  }
};
export default getTrailersReducer;
