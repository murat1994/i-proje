import {
  GET_JUST_REVIEWED_MOVIES_FAIL,
  GET_JUST_REVIEWED_MOVIES_REQUEST,
  GET_JUST_REVIEWED_MOVIES_SUCCESS,
} from "../actionTypes/justReviewed";

const initialState = {
  justReviewed: [],
};
const justReviewedReducer = (state = initialState, action) => {
  switch (action.type) {
    case GET_JUST_REVIEWED_MOVIES_REQUEST:
      return { ...state, loading: true };

    case GET_JUST_REVIEWED_MOVIES_SUCCESS:
      return { ...state, loading: false, justReviewed: action.payload };

    case GET_JUST_REVIEWED_MOVIES_FAIL:
      return { ...state, loading: false, error: action.payload };
    default:
      return state;
  }
};
export default justReviewedReducer;
