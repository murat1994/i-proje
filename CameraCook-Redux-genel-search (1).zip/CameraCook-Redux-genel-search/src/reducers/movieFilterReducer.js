import { getSearchConstants } from "../actionTypes/movieFilterTypes";

const initialState = {
    fetching: false,
    fetched: false,
    getFilterList: [],
    getMovieList: [],
    getTvList: [],
    getPersonList: [],
    getMemberList: [],
    language: "TR",
    error: '',
  }

function movieFilterReducer(state = initialState, { type, payload }) {
    switch (type) {
      case getSearchConstants.GET_SEARCH_PAGE_PENDING:
        return {
          ...state,
          fetching: true,
          error: '',
        }
      case getSearchConstants.GET_SEARCH_PAGE_FULFILLED:
        return {
          ...state,
          getFilterList: payload,
          fetching: false,
          fetched: true,
        }
      case getSearchConstants.GET_SEARCH_PAGE_REJECTED:
        return {
          ...state,
          error: payload,
          fetching: false,
        }

        case getSearchConstants.GET_MOVIE_PAGE_PENDING:
        return {
          ...state,
          fetching: true,
          error: '',
        }
      case getSearchConstants.GET_MOVIE_PAGE_FULFILLED:
        return {
          ...state,
          getMovieList: payload,
          fetching: false,
          fetched: true,
        }
      case getSearchConstants.GET_MOVIE_PAGE_REJECTED:
        return {
          ...state,
          error: payload,
          fetching: false,
        }

        case getSearchConstants.GET_TV_PAGE_PENDING:
        return {
          ...state,
          fetching: true,
          error: '',
        }
      case getSearchConstants.GET_TV_PAGE_FULFILLED:
        return {
          ...state,
          getTvList: payload,
          fetching: false,
          fetched: true,
        }
      case getSearchConstants.GET_TV_PAGE_REJECTED:
        return {
          ...state,
          error: payload,
          fetching: false,
        }

        case getSearchConstants.GET_PERSON_PAGE_PENDING:
        return {
          ...state,
          fetching: true,
          error: '',
        }
      case getSearchConstants.GET_PERSON_PAGE_FULFILLED:
        return {
          ...state,
          getPersonList: payload,
          fetching: false,
          fetched: true,
        }
      case getSearchConstants.GET_PERSON_PAGE_REJECTED:
        return {
          ...state,
          error: payload,
          fetching: false,
        }

        case getSearchConstants.GET_MEMBER_PAGE_PENDING:
        return {
          ...state,
          fetching: true,
          error: '',
        }
      case getSearchConstants.GET_MEMBER_PAGE_FULFILLED:
        return {
          ...state,
          getMemberList: payload,
          fetching: false,
          fetched: true,
        }
      case getSearchConstants.GET_MEMBER_PAGE_REJECTED:
        return {
          ...state,
          error: payload,
          fetching: false,
        }

        case "CHANGE_LANGUAGE":
        return { ...state, language: payload };
      default:
        return state;
    }
  }
  
  
  export default movieFilterReducer;