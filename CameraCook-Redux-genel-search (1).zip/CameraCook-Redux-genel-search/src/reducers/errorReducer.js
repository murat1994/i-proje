import { SET_ERROR, CLEAR_ERROR } from "../actionTypes/messageTypes";

const initialState = null;

const errorReducer = (state = initialState, action) => {
  const { type, payload } = action;
  //console.log(payload)
  switch (type) {
    case SET_ERROR:
      return  payload ;

    case CLEAR_ERROR:
      return null ;

    default:
      return state;
  }
}

export default errorReducer;