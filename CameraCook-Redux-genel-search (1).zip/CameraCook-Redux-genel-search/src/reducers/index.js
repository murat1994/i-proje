import { combineReducers } from "redux";
import getTrailersReducer from "../reducers/getTrailersReducer";
import justReviewedReducer from "./justReviewed";
import popularMoviesReducer from "./popularMovies";
import searchMoviesReducer from "./searchMovies";
import authReducer from "./authReducer";
import userReducer from "./userReducer";
import messageReducer from "./messageReducer";
import errorReducer from "./errorReducer";
import { addmovieReducer } from "./addMovieReducer";
import movieFilterReducer from "./movieFilterReducer";
import {
  addListReducer,
  getListReducer,
  singleListReducer,
} from "./listReducers";
const reducer = combineReducers({
  msg: messageReducer,
  error: errorReducer,
  auth: authReducer,
  users: userReducer,
  getTrailers: getTrailersReducer,
  popularMovies: popularMoviesReducer,
  justReviewed: justReviewedReducer,
  searchMovies: searchMoviesReducer,
  addMovie: addmovieReducer,
  addList: addListReducer,
  allLists: getListReducer,
  singleList: singleListReducer,
  movieFilter: movieFilterReducer,
});

export default reducer;
