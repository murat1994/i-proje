import {} from "../actionTypes/justReviewed";
import {
  ADD_LIST_FAIL,
  ADD_LIST_REQUEST,
  ADD_LIST_SUCCESS,
  GET_LIST_FAIL,
  GET_LIST_REQUEST,
  GET_LIST_SUCCESS,
  GET_SINGLE_LIST_FAIL,
  GET_SINGLE_LIST_REQUEST,
  GET_SINGLE_LIST_SUCCESS,
} from "../actionTypes/list";
const initialState = {};
export const addListReducer = (state = initialState, action) => {
  switch (action.type) {
    case ADD_LIST_REQUEST:
      return { loading: true, success: false };

    case ADD_LIST_SUCCESS:
      return { ...state, loading: false, success: true, list: action.payload };

    case ADD_LIST_FAIL:
      return {
        ...state,
        loading: false,
        success: false,
        error: action.payload,
      };

    default:
      return state;
  }
};

export const getListReducer = (state = initialState, action) => {
  switch (action.type) {
    case GET_LIST_REQUEST:
      return { loading: true, success: false };

    case GET_LIST_SUCCESS:
      return {
        ...state,
        loading: false,
        success: true,
        allLists: action.payload,
      };

    case GET_LIST_FAIL:
      return {
        ...state,
        loading: false,
        success: false,
        error: action.payload,
      };

    default:
      return state;
  }
};
export const singleListReducer = (state = {}, action) => {
  switch (action.type) {
    case GET_SINGLE_LIST_REQUEST:
      return { loading: true, success: false };

    case GET_SINGLE_LIST_SUCCESS:
      return {
        ...state,
        loading: false,
        success: true,
        singleList: action.payload,
      };

    case GET_SINGLE_LIST_FAIL:
      return {
        ...state,
        loading: false,
        success: false,
        error: action.payload,
      };

    default:
      return state;
  }
};
