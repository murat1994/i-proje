import {} from "../actionTypes/justReviewed";
import {
  ADD_MOVIE_FAIL,
  ADD_MOVIE_REQUEST,
  ADD_MOVIE_SUCCESS,
} from "../actionTypes/movie";
const initialState = {};
export const addmovieReducer = (state = initialState, action) => {
  switch (action.type) {
    case ADD_MOVIE_REQUEST:
      return { loading: true, success: false };

    case ADD_MOVIE_SUCCESS:
      return { ...state, loading: false, success: true, movie: action.payload };

    case ADD_MOVIE_FAIL:
      return {
        ...state,
        loading: false,
        success: false,
        error: action.payload,
      };
    default:
      return state;
  }
};
