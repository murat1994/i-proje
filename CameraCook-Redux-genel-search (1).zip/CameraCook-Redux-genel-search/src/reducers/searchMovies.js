import {
  GET_SEARCH_MOVIES_FULFILLED,
  GET_SEARCH_MOVIES_PENDING,
  GET_SEARCH_MOVIES_REJECTED,
} from "../actionTypes/searchMovies";

const initialState = {
  searchMovies: [],
  language: "TR",
};
const searchMoviesReducer = (state = initialState, action) => {
  switch (action.type) {
    case GET_SEARCH_MOVIES_PENDING:
      return { ...state, loading: true };

    case GET_SEARCH_MOVIES_FULFILLED:
      return { ...state, loading: false, searchMovies: action.payload };

    case GET_SEARCH_MOVIES_REJECTED:
      return { ...state, loading: false, error: action.payload };
    case "CHANGE_LANGUAGE":
      return { ...state, language: action.payload };
    default:
      return state;
  }
};
export default searchMoviesReducer;
