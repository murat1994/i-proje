import {
  GET_POPULAR_MOVIES_FAIL,
  GET_POPULAR_MOVIES_REQUEST,
  GET_POPULAR_MOVIES_SUCCESS,
} from "../actionTypes/popularMovies";

const initialState = {
  popularMovies: [],
};
const popularMoviesReducer = (state = initialState, action) => {
  switch (action.type) {
    case GET_POPULAR_MOVIES_REQUEST:
      return { ...state, loading: true };

    case GET_POPULAR_MOVIES_SUCCESS:
      return { ...state, loading: false, popularMovies: action.payload };

    case GET_POPULAR_MOVIES_FAIL:
      return { ...state, loading: false, error: action.payload };
    default:
      return state;
  }
};
export default popularMoviesReducer;
