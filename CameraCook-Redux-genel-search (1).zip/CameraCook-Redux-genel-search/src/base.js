
export const API_KEY = process.env.REACT_APP_API_KEY; 

// export const BACKEND_URL = process.env.REACT_APP_BASE_URL; 