import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import { connect } from "react-redux";
import AutVerify from "./components/AutVerify";

import { Header } from "./components/Header/Header";
import Home from "./components/pages/Home";
import About from "./components/pages/pages/About";
import ContactUs from "./components/pages/pages/ContactUs";
import Faq from "./components/pages/pages/Faq";
import Policies from "./components/pages/pages/Policies";
import ErrorPage from "./components/pages/ErrorPage";
import Signin from "../src/components/pages/UserProfile/Signin";
import Signup from "../src/components/pages/UserProfile/Signup";
import ManageProfile from "../src/components/pages/UserProfile/ManageProfile";
import Settings from "../src/components/pages/UserProfile/Settings";
import Footer from "./components/Footer";
import NewMoviesSection from "./components/pages/newMoviewsSection/NewMoviesSection";
import Movie from "./components/pages/movie/MovieCard";
import { useEffect } from "react";
import { useDispatch } from "react-redux";
import getPopularMovies from "./actions/popularMovies";
import Members from "./components/Members/Members";
import MemberCard from "./components/Members/MemberCard";
import SearchPage from "./components/Search/SearchPage";
import List from "./components/List/List";
import AddNewList from "./components/List/AddNewList";
import ListCard from "./components/List/ListCard";
import MoviesAll from "./components/newMoviesSection/MoviesAll";
import MembersAll from "./components/Members/MembersAll";
import ListAll from "./components/List/ListAll";
import List1 from "./components/List/List1";
import PeopleCard from "./components/People/PeopleCard";
import { getAllLists } from "./actions/list";



function App(props) {
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(getPopularMovies());

    dispatch(getAllLists());
  }, []);

  const { isLoggedIn } = props.auth;
  //const {role} = props.auth.user
  return (
    <>
      <Router>
        {isLoggedIn && <Header />}
        <Switch>
          <Route path="/Signup" render={(props) => <Signup {...props} />} />
          {isLoggedIn ? (
            <>
              <Route path="/" exact component={Home} />
              <Route path="/movies" exact component={NewMoviesSection} />
              <Route path="/about" component={About}>{" "}<About />{" "} </Route>
              <Route path="/contact-us" component={ContactUs}> <ContactUs />{" "}</Route>
              <Route path="/faq" component={Faq}>  {" "}<Faq />{" "} </Route>
              <Route path="/policies" component={Policies}> {" "}<Policies />{" "} </Route>
              <Route path="/manage-profile" component={ManageProfile}> <ManageProfile />{" "} </Route>
              <Route path="/Settings" component={Settings}>   {" "}  <Settings />{" "}  </Route>
              <Route path="/movie/:id" component={Movie} />
              <Route path="/people/:id" component={PeopleCard} />
              {isLoggedIn ? ( //buraya admin sorgusu atılabilir
                <>
                  <Route path="/members" component={Members} />
                  <Route path="/member-card/:memberId" component={MemberCard} />
                  <Route path="/search-page" component={SearchPage} />
                  <Route path="/list" exact component={List} />
                  <Route path="/list/add-new-list" component={AddNewList} />
                  <Route path="/list-card/:id" component={ListCard} />
                  <Route path="/MoviesAll/:genre" component={MoviesAll} />
                  <Route path="/MembersAll" component={MembersAll} />
                  <Route path="/list-all" component={ListAll} />
                  <Route path="/List1" component={List1} />
                 

                  {/* <Route path="/people/:id" component={PeopleCard} /> */}
                  
                  
                </>
              ) : (
                <></>
              )}
            </>
          ) : (
            <Route
              path={["/", "/Signin"]}
              render={(props) => <Signin {...props} />}
            />
          )}

          {/* hasan */}

          <Route path="*" component={ErrorPage} />
        </Switch>
        <AutVerify />
        <Footer />
      </Router>
    </>
  );
}

const mapStateToProps = (state) => state;

const mapDispatchToProps = {};

export default connect(mapStateToProps, mapDispatchToProps)(App);
