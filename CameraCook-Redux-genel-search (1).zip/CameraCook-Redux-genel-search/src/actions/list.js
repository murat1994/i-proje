import axios from "axios";
import { API_BASE }  from "../actions/api_base";

import {
  ADD_LIST_FAIL,
  ADD_LIST_REQUEST,
  ADD_LIST_SUCCESS,
  GET_LIST_FAIL,
  GET_LIST_REQUEST,
  GET_LIST_SUCCESS,
  GET_SINGLE_LIST_FAIL,
  GET_SINGLE_LIST_REQUEST,
  GET_SINGLE_LIST_SUCCESS,
} from "../actionTypes/list";

export const addList = (movieList) => async (dispatch, getState) => {
  const { name, description, movieIds } = movieList;
  const { id } = getState().auth.user;
  try {
    dispatch({
      type: ADD_LIST_REQUEST,
    });
    const results = await axios.post(
      API_BASE + "lists",
      {
        name,
        description,
        movieIds: JSON.stringify(movieIds),
        userId: id,
      }
    );

    dispatch({
      type: ADD_LIST_SUCCESS,
      payload: results,
    });
  } catch (error) {
    dispatch({
      type: ADD_LIST_FAIL,
      payload: error,
    });
  }
};

export const getAllLists = () => async (dispatch) => {
  try {
    dispatch({
      type: GET_LIST_REQUEST,
    });
    const {
      data: { response },
    } = await axios.get(API_BASE + "lists");

    dispatch({
      type: GET_LIST_SUCCESS,
      payload: response,
    });
  } catch (error) {
    dispatch({
      type: GET_LIST_FAIL,
      payload: error,
    });
  }
};
export const getSingleList = (id) => async (dispatch) => {
  try {
    dispatch({
      type: GET_SINGLE_LIST_REQUEST,
    });
    const {
      data: { response },
    } = await axios.get(API_BASE + "lists/" + id);

    dispatch({
      type: GET_SINGLE_LIST_SUCCESS,
      payload: response,
    });
  } catch (error) {
    dispatch({
      type: GET_SINGLE_LIST_FAIL,
      payload: error,
    });
  }
};
