import axios from 'axios';
import { getSearchConstants } from "../actionTypes/movieFilterTypes";

export const getsearchPage = (movies) => async (dispatch, getState) => 
{
  try {
    dispatch({
      type: getSearchConstants.GET_SEARCH_PAGE_PENDING,
    });
    const {data} = await axios.get(`https://api.themoviedb.org/3/search/multi?api_key=325518aa4abde54cbc9a6ebb1e419283&language=en-US&query=${movies}&page=1&include_adult=false`);
    dispatch({
      type: getSearchConstants.GET_SEARCH_PAGE_FULFILLED,
      payload: data.results,
    });
    // console.log(results);
  }  catch (error) {
     dispatch({
      type: getSearchConstants.GET_SEARCH_PAGE_REJECTED,
      payload: error,
    });
  }
}

export default getsearchPage;