import axios from "axios";
import {
  GET_SEARCH_MOVIES_FULFILLED,
  GET_SEARCH_MOVIES_PENDING,
  GET_SEARCH_MOVIES_REJECTED,
} from "../actionTypes/searchMovies";

const getsearchMovies = (movieName) => async (dispatch, getState) => {
  try {
    dispatch({
      type: GET_SEARCH_MOVIES_PENDING,
    });
    const {
      data: { results },
    } = await axios.get(
      `https://api.themoviedb.org/3/search/movie?api_key=${process.env.REACT_APP_API_KEY}&query=` +
        movieName
    );

    dispatch({
      type: GET_SEARCH_MOVIES_FULFILLED,
      payload: results,
    });
  } catch (error) {
    dispatch({
      type: GET_SEARCH_MOVIES_REJECTED,
      payload: error,
    });
  }
};

export default getsearchMovies;
