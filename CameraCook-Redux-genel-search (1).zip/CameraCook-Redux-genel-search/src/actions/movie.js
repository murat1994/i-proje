import axios from "axios";
import { API_BASE }  from "../actions/api_base";
import {
  ADD_MOVIE_FAIL,
  ADD_MOVIE_REQUEST,
  ADD_MOVIE_SUCCESS,
} from "../actionTypes/movie";

export const addMovie = (movie) => async (dispatch, getState) => {
  try {
    dispatch({
      type: ADD_MOVIE_REQUEST,
    });

    const { data } = await axios.post( API_BASE +
      "movies",
      {
        ...movie,
        image_path: movie.poster_path,
        tmdb_id: movie.id.toString(),
      }
    );

    dispatch({
      type: ADD_MOVIE_SUCCESS,
      payload: data.data[0],
    });
  } catch (error) {
    dispatch({
      type: ADD_MOVIE_FAIL,
      payload: error,
    });
  }
};
