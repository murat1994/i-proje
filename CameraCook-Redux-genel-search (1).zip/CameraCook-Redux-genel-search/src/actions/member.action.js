import axios from 'axios';
import { getSearchConstants } from "../actionTypes/movieFilterTypes";

export const getmemberPage = (query) => async (dispatch, getState) => 
{
  try {
    dispatch({
      type: getSearchConstants.GET_MEMBER_PAGE_PENDING,
    });
    const {data} = await axios.get("https://movieapp-server.herokuapp.com/users");
    dispatch({
      type: getSearchConstants.GET_MEMBER_PAGE_FULFILLED,
      payload: data.response,
    });
     console.log(data);
  }  catch (error) {
     dispatch({
      type: getSearchConstants.GET_MEMBER_PAGE_REJECTED,
      payload: error,
    });
  }
}

export default getmemberPage;