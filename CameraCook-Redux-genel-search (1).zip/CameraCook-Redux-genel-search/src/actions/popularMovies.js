import React from "react";
import axios from "axios";
import {
  GET_POPULAR_MOVIES_FAIL,
  GET_POPULAR_MOVIES_REQUEST,
  GET_POPULAR_MOVIES_SUCCESS,
} from "../actionTypes/popularMovies";
import { API_BASE }  from "../actions/api_base";
import { GET_TRAILERS_FULFILLED } from "../actionTypes/trailersActionTypes";

const splitImages = (data) => {
  let imagesArray = [];
  let arr = [];

  for (let i = 0; i < data.length; i++) {
    arr.push(data[i].image);

    if (arr.length === 4) {
      imagesArray.push(arr);

      arr = [];
    }
  }
  return imagesArray;
};

export const getPopularMovies = () => async (dispatch, getState) => {
  const { language } = getState().searchMovies;
  //console.log(language, "language", getState());
  try {
    dispatch({
      type: GET_POPULAR_MOVIES_REQUEST,
    });
    const {
      data: { results },
    } = await axios.get(
      `https://api.themoviedb.org/3/movie/popular?api_key=${process.env.REACT_APP_API_KEY}&language=${
        language.toLowerCase() + "-" + language
      }`
    );
    //console.log(results);
    

    let promises = results.map(movie => {
      return axios.post(`${API_BASE}movies`,{
          imdb_id: movie.imdb_id,
          imdb_rating: movie.vote_average,
          tmdb_id: movie.id.toString(),
          original_title: movie.original_title,
          image_path: movie.poster_path,
          backdrop_path: movie.backdrop_path,
      })
        .then(res => {
          return res.data.data[0];
        })
    });

    const data = await Promise.all(promises)
      .then(responses => {
        //console.log(responses)
        return responses
      })
      .catch(e => {
        console.error(e);
      })
    // const data = await results.map(
    //   ({ poster_path, popularity, original_title, id, release_date }) => ({
    //     image: "https://image.tmdb.org/t/p/w342/" + poster_path,
    //     popularity,
    //     original_title,
    //     release_date,
    //     id,
    //   })
    // );
    const trailers = results.map(async (movie) => {
      try {
        const {
          data: { results: res },
        } = await axios.get(
          `
  https://api.themoviedb.org/3/movie/${movie.id}/videos?api_key=${process.env.REACT_APP_API_KEY}&language=${language.toLowerCase() + "-" + language}`
        );

        return {
          ...movie,
          trailer: res.find(({ site }) => site !== "Youtube")?.key,
        };
      } catch (error) {
        console.log(error);
      }
    });

    dispatch({
      type: GET_TRAILERS_FULFILLED,
      payload: results,
    });

    dispatch({
      type: GET_POPULAR_MOVIES_SUCCESS,
      payload: data,
    });
  } catch (error) {
    console.log(error);
    dispatch({
      type: GET_POPULAR_MOVIES_FAIL,
      payload: error,
    });
  }
};

export default getPopularMovies;
