import axios from "axios";
import {
  GET_JUST_REVIEWED_MOVIES_FAIL,
  GET_JUST_REVIEWED_MOVIES_REQUEST,
  GET_JUST_REVIEWED_MOVIES_SUCCESS,
} from "../actionTypes/justReviewed";

const getJustReviewed = () => async (dispatch, getState) => {
  const { language } = getState().searchMovies;
  try {
    dispatch({
      type: GET_JUST_REVIEWED_MOVIES_REQUEST,
    });
    const {
      data: { results },
    } = await axios.get(
      `https://api.themoviedb.org/3/movie/now_playing?api_key=${process.env.REACT_APP_API_KEY}&language=${
        language.toLowerCase() + "-" + language
      }`
    );

    dispatch({
      type: GET_JUST_REVIEWED_MOVIES_SUCCESS,
      payload: results,
    });
  } catch (error) {
    dispatch({
      type: GET_JUST_REVIEWED_MOVIES_FAIL,
      payload: error,
    });
  }
};

export default getJustReviewed;
