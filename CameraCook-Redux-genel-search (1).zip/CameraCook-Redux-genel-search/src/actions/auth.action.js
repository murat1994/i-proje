import axios from "axios";
import {
  REGISTER_SUCCESS,
  REGISTER_FAIL,
  LOGIN_SUCCESS,
  LOGIN_FAIL,
  LOGOUT,
  GET_USER_REQUEST,
  GET_USER_SUCCESS,
  GET_USER_FAIL,
} from "../actionTypes/authTypes";
import { SET_MESSAGE, CLEAR_MESSAGE } from "../actionTypes/messageTypes";

import { API_BASE } from "./api_base";

export const register = (data) => (dispatch) => {
  return axios.post(API_BASE + "users/signup", data).then(
    (response) => {
      dispatch({
        type: REGISTER_SUCCESS,
      });
      dispatch({
        type: SET_MESSAGE,
        payload: response.data.message,
      });
      setTimeout(() => {
        dispatch({
          type: CLEAR_MESSAGE,
        });
      }, 2000);
      return response.data.status;
    },
    (error) => {
      const message =
        (error.response &&
          error.response.data &&
          error.response.data.message) ||
        error.message ||
        error.toString();

      dispatch({
        type: REGISTER_FAIL,
      });

      dispatch({
        type: SET_MESSAGE,
        payload: message,
      });
      setTimeout(() => {
        dispatch({
          type: CLEAR_MESSAGE,
        });
      }, 2000);
      return Promise.reject();
    }
  );
};

export const login = (data) => (dispatch) => {
  return axios.post(API_BASE + "users/signin", data).then(
    (response) => {
      if (response.data.token) {
        //burda tüm verileri locale atmısız, sadece token için login durumunu göndersek ?
        localStorage.setItem("user", JSON.stringify(response.data));
        dispatch({
          type: LOGIN_SUCCESS,
          payload: { user: response.data },
        });
        dispatch({
          type: SET_MESSAGE,
          payload: response.data.message || "sign-in succesfully",
        });
        setTimeout(() => {
          dispatch({
            type: CLEAR_MESSAGE,
          });
        }, 2000);
      } else {
        dispatch({
          type: LOGIN_FAIL,
        });

        dispatch({
          type: SET_MESSAGE,
          payload: response.data.message,
        });
        setTimeout(() => {
          dispatch({
            type: CLEAR_MESSAGE,
          });
        }, 2000);
      }
      return response.data;
    },
    (error) => {
      const message =
        (error.response &&
          error.response.data &&
          error.response.data.message) ||
        error.message ||
        error.toString();

      dispatch({
        type: LOGIN_FAIL,
      });

      dispatch({
        type: SET_MESSAGE,
        payload: message,
      });
      setTimeout(() => {
        dispatch({
          type: CLEAR_MESSAGE,
        });
      }, 2000);
      return Promise.reject();
    }
  );
};

export const logout = () => (dispatch) => {
  localStorage.removeItem("user");

  dispatch({
    type: LOGOUT,
  });
};

export const getUsers = () => async (dispatch, getState) => {
  let result;
  try {
    dispatch({
      type: GET_USER_REQUEST,
    });
    const {
      data: { data },
    } = await axios.get( API_BASE + "users");

    dispatch({
      type: GET_USER_SUCCESS,
      payload: data,
    });
    result = data;
  } catch (error) {
    dispatch({
      type: GET_USER_FAIL,
      payload: error,
    });
  }
  return result;
};
