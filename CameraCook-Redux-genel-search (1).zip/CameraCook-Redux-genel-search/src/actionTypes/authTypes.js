    export const REGISTER_SUCCESS = "REGISTER_SUCCESS"
    export const REGISTER_FAIL = "REGISTER_FAIL"
    export const LOGIN_SUCCESS = "LOGIN_SUCCESS"
    export const LOGIN_FAIL = "LOGIN_FAIL"
    export const LOGOUT = "LOGOUT"
    export const GET_USER_REQUEST = "GET_USER_REQUEST"
    export const GET_USER_SUCCESS = "GET_USER_SUCCESS"
    export const GET_USER_FAIL = "GET_USER_FAIL"

