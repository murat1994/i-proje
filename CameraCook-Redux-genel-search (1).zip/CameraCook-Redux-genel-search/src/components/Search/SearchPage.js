import React, { useEffect, useState } from "react";
// import { useDispatch, useSelector } from "react-redux";
import { Container, Nav, Navbar, NavDropdown, Form, FormControl, Button, Row, Col } from "react-bootstrap";
import "./SearchPage.css";
import "../newMoviesSection/movieFilter/movieFilterSection.css";
// import { getSearchPage } from '../../actions/searchPageAction';
import   MovieFilterSection  from '../newMoviesSection/movieFilter/MovieFilterSection';
import { Link } from "react-router-dom";


const SearchPage = (props) => {
    return (                 

<div className="search-results logged-out" >
    <br/>
    <MovieFilterSection/><br/>
</div>

  )
}

export default SearchPage;
