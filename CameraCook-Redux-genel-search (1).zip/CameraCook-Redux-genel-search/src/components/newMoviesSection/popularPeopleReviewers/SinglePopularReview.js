import React from "react";
import { Link } from "react-router-dom";
import "./popularPeopleReviewer.css";
const SinglePopularReview = ({ title, mediaId: { url } }) => {
  return (
    <div className="single-popular-review-container">
      <Link to="/">
        <img src={url} alt="" className="single-popular-review-image" />
      </Link>
      <div className="single-popular-review-context-container">
        <h6>{title}</h6>
        <div>
          <h5>500 films</h5>
          <h5>1000 reviews</h5>
        </div>
      </div>
    </div>
  );
};

export default SinglePopularReview;
