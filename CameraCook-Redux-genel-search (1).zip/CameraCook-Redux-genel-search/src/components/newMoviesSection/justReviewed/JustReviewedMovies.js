import React, { useEffect, useState } from "react";
import "./justReviewedMovies.css";

import { Link } from "react-router-dom";
import { useSelector } from "react-redux";

const ReviewedMovies = () => {
  const { justReviewed } = useSelector(({ justReviewed }) => justReviewed);
  const [images, setImages] = useState(justReviewed);
  useEffect(() => {
    setImages(justReviewed);
  }, [justReviewed]);

  return (
    <div className="just-reviewed-movies-container">
      <header className="popular-top-movies-header under-line sub-menu">
        <li className="menu-item iq-up-view-all ">
          <p>JUST REVIEWED…</p>
        </li>

        <p>699,215,363 films watched</p>
      </header>

      <div className="just-reviewed-movies-image-container">
        {images.map(({ poster_path, original_title, id }, idx) => (
          <Link key={idx} to={`/movie/${id}`}>
            <img
              className="just-reviewed-movies-image"
              src={"https://image.tmdb.org/t/p/w154/" + poster_path}
              alt=""
            />
          </Link>
        ))}
      </div>
    </div>
  );
};

export default ReviewedMovies;
