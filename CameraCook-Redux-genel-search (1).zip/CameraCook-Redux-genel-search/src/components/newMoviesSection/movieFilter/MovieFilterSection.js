// import axios from "axios";
import { useDispatch, useSelector } from "react-redux";
import "./movieFilterSection.css";
import React, { useEffect, useState } from "react";
import { Button, ButtonGroup } from "react-bootstrap";
import { Link } from "react-router-dom";
import { getsearchPage } from "../../../actions/movieFilter.action";
import { getmoviePage } from "../../../actions/movie.action";
import { gettvPage } from "../../../actions/tv.action";
import { getpersonPage } from "../../../actions/person.action";
import { getmemberPage } from "../../../actions/member.action";
import MovieFilterList from "./MovieFilterList";
import MovieList from "./MovieList";
import TvList from "./TvList";
import PersonList from "./PersonList";
import MemberList from "./MemberList";
import MovieYearsList from "./MovieYearsList";

const MovieFilterSection = (props) => {
  const [query, setQuery] = useState("");
  const [conter, setConter] = useState(0);
  const [year, setYear] = useState(null);
  const dispatch = useDispatch();

  const { getFilterList } = useSelector((state) => state.movieFilter);
  useEffect(() => {
    dispatch(getsearchPage(query));
  }, [query]);

  const { getMovieList } = useSelector((state) => state.movieFilter);
  useEffect(() => {
    dispatch(getmoviePage(query));
  }, [query]);

  const { getTvList } = useSelector((state) => state.movieFilter);
  useEffect(() => {
    dispatch(gettvPage(query));
  }, [query]);

  const { getPersonList } = useSelector((state) => state.movieFilter);
  useEffect(() => {
    dispatch(getpersonPage(query));
  }, [query]);

  const { getMemberList } = useSelector((state) => state.movieFilter);
  useEffect(() => {
    dispatch(getmemberPage(query));
  }, [query]);

  useEffect(() => {
    console.log("year === ", year);
  }, [year]);

  return (
    <div>
      <div class="text-center" style={{ marginTop: 80, marginBottom: 0 }}>
        <ButtonGroup aria-label="Basic example">
          <Button
            variant="outline-dark"
            class="text-white bg-dark"
            onClick={() => setConter(1)}
          >
            Movies
          </Button>
          <Button variant="outline-dark" onClick={() => setConter(2)}>
            Tv
          </Button>
          <Button variant="outline-dark" onClick={() => setConter(3)}>
            Persons
          </Button>
          <Button variant="outline-dark" onClick={() => setConter(4)}>
            Members
          </Button>
        </ButtonGroup>
      </div>

      <nav className="filter-container navbar navbar-expand-lg navbar-light bg-light">
        <div style={{ marginTop: 0 }} className="container-label">
          <Link className="dropdown-label navbar-brand menu-item" href="#">
            BROWSE BY
          </Link>
        </div>
        <ul className="bar-nav">
          <li>
            <section className="smenu-wrapper">
              <div className="smenu">
                <li className="menu-item ">
                  <Link to="/search-page">Year</Link>
                  <ul className="sub-menu">
                    <li className="menu-item under-line channel-logo-1">
                      <Link to="/search-page">All</Link>
                    </li>
                    <li className="menu-item under-line channel-logo-1">
                      <Link to="/search-page">Upcoming</Link>
                    </li>
                    <li className="menu-item under-line channel-logo-1">
                      <Link to="/search-page" onClick={() => setYear(2020)}>
                        2020s
                      </Link>
                    </li>
                    <li className="menu-item under-line channel-logo-1">
                      <Link to="/search-page" onClick={() => setYear(2010)}>
                        2010s
                      </Link>
                    </li>
                    <li className="menu-item under-line channel-logo-1">
                      <Link to="/search-page" onClick={() => setYear(2000)}>
                        2000s
                      </Link>
                    </li>
                    <li className="menu-item under-line channel-logo-1">
                      <Link to="/search-page" onClick={() => setYear(1990)}>
                        1990s
                      </Link>
                    </li>
                    <li className="menu-item under-line channel-logo-1">
                      <Link to="/search-page" onClick={() => setYear(1980)}>
                        1980s
                      </Link>
                    </li>
                    <li className="menu-item under-line channel-logo-1">
                      <Link to="/search-page" onClick={() => setYear(1970)}>
                        1970s
                      </Link>
                    </li>
                    <li className="menu-item under-line channel-logo-1">
                      <Link to="/search-page" onClick={() => setYear(1960)}>
                        1960s
                      </Link>
                    </li>
                    <li className="menu-item under-line channel-logo-1">
                      <Link to="/search-page" onClick={() => setYear(1950)}>
                        &#x3e; 1950s &lt;
                      </Link>
                    </li>
                  </ul>
                </li>{" "}
              </div>
            </section>
          </li>

          <li>
            <section className="smenu-wrapper">
              <div className="smenu">
                <li className="menu-item ">
                  <Link to="/">Rating</Link>
                  <ul className="sub-menu">
                    <li className="menu-item under-line">
                      <Link to="/">Highest First</Link>
                    </li>
                    <li className="menu-item under-line">
                      <Link to="/">Lowest First</Link>
                    </li>
                    <li className="menu-item under-line">
                      <Link to="/">Top 250 narrative</Link>
                    </li>
                    <li className="menu-item under-line">
                      <Link to="/">Top 250 Documantaries</Link>
                    </li>
                  </ul>
                </li>{" "}
              </div>
            </section>
          </li>

          <li>
            <section className="smenu-wrapper">
              <div className="smenu">
                <li className="menu-item ">
                  <Link to="/">Popular</Link>
                  <ul className="sub-menu">
                    <li className="menu-item under-line">
                      <Link to="/">All Time</Link>
                    </li>
                    <li className="menu-item under-line">
                      <Link to="/">This Year</Link>
                    </li>
                    <li className="menu-item under-line">
                      <Link to="/">This Month</Link>
                    </li>
                    <li className="menu-item under-line">
                      <Link to="/">This Week</Link>
                    </li>
                  </ul>
                </li>
              </div>
            </section>
          </li>

          <li>
            <section className="smenu-wrapper">
              <div className="smenu">
                <li className="menu-item ">
                  <Link to="/">Genre</Link>
                  <ul className="sub-menu">
                    <li className="menu-item under-line">
                      <Link to="/">Action</Link>
                    </li>
                    <li className="menu-item under-line">
                      <Link to="/">Adventure</Link>
                    </li>
                    <li className="menu-item under-line">
                      <Link to="/">Animation</Link>
                    </li>
                    <li className="menu-item under-line">
                      <Link to="/">Comedy</Link>
                    </li>
                  </ul>
                </li>
              </div>
            </section>
          </li>

          <li>
            <section className="smenu-wrapper">
              <div className="smenu">
                <li className="menu-item ">
                  <Link to="/">Other</Link>
                  <ul className="sub-menu">
                    <li className="menu-item under-line">
                      <Link to="/">Most Anticipated</Link>
                    </li>
                    <li className="menu-item under-line">
                      <Link to="/">Film Name (A-Z)</Link>
                    </li>
                    <li className="menu-item under-line">
                      <Link to="/">Collections</Link>
                    </li>
                    <li className="menu-item under-line">
                      <Link to="/CountryLang">Countries/Languages</Link>
                    </li>
                    <li className="menu-item under-line">
                      <Link to="/">Lists</Link>
                    </li>
                    <li className="menu-item under-line">
                      <Link to="/">Members</Link>
                    </li>
                  </ul>
                </li>
              </div>
            </section>
          </li>
        </ul>

        <div className="search-movie">
          <label className="search-movie-text" htmlFor="find-movie">
            Find a Film
          </label>
          <input
            id="find-movie"
            className="form-control mr-sm-2"
            type="search"
            placeholder="Search"
            aria-label="Search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
        </div>
      </nav>

      <div className="componentBottom">
        {year !== null ? <MovieYearsList year={year} /> : null}
      </div>

      {conter === 0 ? <MovieFilterList getFilterList={getFilterList} /> : null}
      {conter === 1 ? <MovieList getMovieList={getMovieList} /> : null}
      {conter === 2 ? <TvList getTvList={getTvList} /> : null}
      {conter === 3 ? <PersonList getPersonList={getPersonList} /> : null}
      {conter === 4 ? (
        <MemberList getMemberList={getMemberList} query={query} />
      ) : null}
    </div>
  );
};

export default MovieFilterSection;
