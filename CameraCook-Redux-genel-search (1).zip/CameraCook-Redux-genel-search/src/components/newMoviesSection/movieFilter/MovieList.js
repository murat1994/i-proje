import React from "react";
import "../../Search/SearchPage.css";
import { Card, Container, Grid, Row, Col } from "react-bootstrap";
import { auto } from "@popperjs/core";
// import { row, col } from "react-router-dom";

export default function MovieList({ getMovieList }) {
  console.log("getMovieList  => ", getMovieList);
  return (
    <div id="content" className="site-body">
      {/* <div className="content-wrap">
        <section className="section col-main"> */}
      <h2 className="section-heading">
        Found at least 250 matches for “The Suicide Squad”
      </h2>
      {/* <ul className="results"> */}
      <Container>
        <Row class="d-flex justify-content-between">
          {getMovieList.map((movie) => (
            <Col style={{padding:5}} lg={2} >
              <Card style={{ width: "10rem", height: '100%', margin:0, padding:0}}>
                <Card.Img
                  variant="top"
                  src={`https://www.themoviedb.org/t/p/w600_and_h900_bestv2${movie.poster_path}`}
                />
                <Card.Body style={{height: '100%'}}>
                  <Card.Title>{movie.title}</Card.Title>
                  {/* <Card.Text >
                    {movie.overview.length < 30
                      ? `${movie.overview}`
                      : `${movie.overview.substring(0, 30)}... `}
                  </Card.Text> */}
                  <a
                    href={`https://www.themoviedb.org/movie/${movie.id}-${movie.title.replace(" ", "-")}`}
                    class="btn btn-primary"
                  >
                    Details
                  </a>
                </Card.Body>
              </Card>
            </Col>
          ))}
          ;
        </Row>
      </Container>

      {/* </ul> */}

      <div className="pagination">
        <div className="paginate-nextprev paginate-disabled">
          <span className="previous">Previous</span>
        </div>
        <div className="paginate-nextprev">
          <a className="next" href="/search/The%20Suicide%20Squad/page/2/">
            Next
          </a>
        </div>{" "}
        <div className="paginate-pages">
          <ul>
            <li className="paginate-page paginate-current">
              <span>1</span>
            </li>
            <li className="paginate-page">
              <a href="/search/The%20Suicide%20Squad/page/2/">2</a>
            </li>
            <li className="paginate-page">
              <a href="/search/The%20Suicide%20Squad/page/3/">3</a>
            </li>
            <li className="paginate-page">
              <a href="/search/The%20Suicide%20Squad/page/4/">4</a>
            </li>
            <li className="paginate-page">
              <a href="/search/The%20Suicide%20Squad/page/5/">5</a>
            </li>
            <li className="paginate-page unseen-pages">…</li>
            <li className="paginate-page">
              <a href="/search/The%20Suicide%20Squad/page/13/">13</a>
            </li>
          </ul>
        </div>
      </div>
      {/* </section>
      </div> */}
    </div>
  );
}
