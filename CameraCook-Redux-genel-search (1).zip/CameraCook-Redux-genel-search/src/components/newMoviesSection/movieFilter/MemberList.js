import React from "react";
import "../../Search/SearchPage.css";
import { Card, Container, Grid, Row, Col } from "react-bootstrap";

export default function MemberList({getMemberList, query}) {
  console.log("getMemberList  => ", getMemberList);
  console.log("query  =>" , query)
  return (
    <div id="content" className="site-body">
      <div className="content-wrap">
        <section className="section col-17 col-main">
          <h2 className="section-heading">
            Member List
          </h2>
          <Container>
        <Row class="d-flex justify-content-between">
          {getMemberList.map((member) => (
            member.firstname.includes(query) ? (
              <Col style={{padding:5}} lg={2} >
                <p>{member.firstname} {member.lastname}</p>
                {/* <p>{member.lastname}</p> */}
                <img src={member.mediaId[0].url} alt="member_avatar_image"/>
              {/* <Card style={{ width: "10rem", height: '100%', margin:0, padding:0}}>
                <Card.Img
                  variant="top"
                  src={`https://www.themoviedb.org/t/p/w600_and_h900_bestv2${member.poster_path}`}
                />
                <Card.Body style={{height: '100%'}}>
                  <Card.Title>{member.title}</Card.Title>
                  <a
                    href={`https://www.themoviedb.org/movie/${member.id}-${member.title.replace(" ", "-")}`}
                    class="btn btn-primary"
                  >
                    Details
                  </a>
                </Card.Body>
              </Card> */}
            </Col>
            ) : null
            
          ))};
        </Row>
      </Container>
          {/* <div>
          {getMemberList.filter(firstname => firstname.includes('J')).map(filteredName => (
             <li>
                 {filteredName}
             li>
         ))}
          </div> */}
          
         
        </section>
      </div>
    </div>
  );
}
