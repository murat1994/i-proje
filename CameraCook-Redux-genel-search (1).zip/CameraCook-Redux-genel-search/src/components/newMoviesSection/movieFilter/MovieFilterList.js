import React from "react";
// import {
//   Container,
//   Nav,
//   Navbar,
//   NavDropdown,
//   Form,
//   FormControl,
//   Button,
//   Row,
//   Col,
// } from "react-bootstrap";
import "../../Search/SearchPage.css";
import MovieYearsList from "../movieFilter/MovieYearsList";

export default function MovieFilterList({getFilterList}) {
  console.log("getFilterList  => ", getFilterList);
  return (
    <div id="content" className="site-body">
      <div className="content-wrap">
      {/* <MovieYearsList/> */}
        <section className="section col-17 col-main">
          <h2 className="section-heading">
            Found at least 250 matches for “The Suicide Squad”
          </h2>
          <ul className="results">
              {getFilterList.map(movie =>(
                <li>
                <div
                  className="react-component poster film-poster film-poster-369835 linked-film-poster"
                >
                  <div>
                    <img
                      src={`https://www.themoviedb.org/t/p/w600_and_h900_bestv2${movie.poster_path}`}
                      width="70"
                      height="105"
                      alt={movie.title}
                      srcset= {`https://www.themoviedb.org/t/p/w600_and_h900_bestv2${movie.poster_path}`}
                      className="image"
                    />
                    <a href="/film/the-suicide-squad/" className="frame">
                        {/* href kısmına film detayını getiren api */}
                      <span className="frame-title">
                        {movie.title}{movie.release_date}
                      </span>
                      <span className="overlay"></span>
                    </a>
                  </div>
                </div>
                <div className="film-detail-content">
                  <h2 className="headline-2 prettify">
                    <span className="film-title-wrapper">
                      <a href="/film/the-suicide-squad/">
                      {movie.title} <small className="metadata"></small>
                      </a>
                      <small className="metadata">
                        <a href="/films/year/2021/">{movie.release_date}</a>
                      </small>
                    </span>
                  </h2>
                  <div
                    className="truncate text film-metadata condenseable"
                    data-truncate="200"
                    style={{ display: "none" }}
                  >
                    <p>
                      {movie.overview}
                      <span
                        className="condense_control condense_control_less"
                        style={{ cursor: "pointer" }}
                      >
                        ×
                      </span>
                    </p>
                  </div>
                  <div
                    className="truncate text film-metadata condensed"
                    data-truncate="200"
                  >
                    <p>
                    {movie.overview}
                      <span
                        className="condense_control condense_control_more"
                        style={{ cursor: "pointer" }}
                      >
                        …more
                      </span>
                    </p>
                  </div>{" "}
                  <p className="film-metadata">
                    Directed by
                    <a href="/director/james-gunn/" className="text-slug">
                      James Gunn
                    </a>{" "}
                  </p>
                </div>
              </li>
              ))}
          
          </ul>


          <div className="pagination">
            <div className="paginate-nextprev paginate-disabled">
              <span className="previous">Previous</span>
            </div>
            <div className="paginate-nextprev">
              <a className="next" href="/search/The%20Suicide%20Squad/page/2/">
                Next
              </a>
            </div>{" "}
            <div className="paginate-pages">
              <ul>
                <li className="paginate-page paginate-current">
                  <span>1</span>
                </li>
                <li className="paginate-page">
                  <a href="/search/The%20Suicide%20Squad/page/2/">2</a>
                </li>
                <li className="paginate-page">
                  <a href="/search/The%20Suicide%20Squad/page/3/">3</a>
                </li>
                <li className="paginate-page">
                  <a href="/search/The%20Suicide%20Squad/page/4/">4</a>
                </li>
                <li className="paginate-page">
                  <a href="/search/The%20Suicide%20Squad/page/5/">5</a>
                </li>
                <li className="paginate-page unseen-pages">…</li>
                <li className="paginate-page">
                  <a href="/search/The%20Suicide%20Squad/page/13/">13</a>
                </li>
              </ul>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
