import React from 'react';
import {
    Container,
    Nav,
    Navbar,
    NavDropdown,
    Form,
    FormControl,
    button,
    ButtonGroup,
    Row,
    Col,
  } from "react-bootstrap";
//   import Button from "react-bootstrap/Button";
// import ButtonGroup from "react-bootstrap/ButtonGroup";
// import "bootstrap/dist/css/bootstrap.min.css";

export default function MovieYearsList({year}) {
    return (
        
        <div class="btn-group me-2 container" role="group" aria-label="Second group" >
            <button type="button" class="btn btn-secondary">{year}</button>
            <button type="button" class="btn btn-secondary">{year +1}</button>
            <button type="button" class="btn btn-secondary">{year +2}</button>
            <button type="button" class="btn btn-secondary">{year +3}</button>
            <button type="button" class="btn btn-secondary">{year +4}</button>
            <button type="button" class="btn btn-secondary">{year +5}</button>
            <button type="button" class="btn btn-secondary">{year +6}</button>
            <button type="button" class="btn btn-secondary">{year +7}</button>
            <button type="button" class="btn btn-secondary">{year +8}</button>
            <button type="button" class="btn btn-secondary">{year +9}</button>
       </div>
            
    )
}
