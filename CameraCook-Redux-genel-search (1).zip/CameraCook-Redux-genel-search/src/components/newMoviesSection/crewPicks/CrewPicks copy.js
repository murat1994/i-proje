import React from "react";
import { Fragment } from "react";
import { Link } from "react-router-dom";
import data from "../../../data";
import "./crewPicks.css";
const { response } = data;
const CrewPicks = () => {
  return (


<div className="col-4 crews-picks-popular-reiviewers-container">
  <header className="crew-picks-header popular-top-movies-header under-line sub-menu">
    <li className="menu-item iq-up-view-all ">
      <p>CREW.PICKS</p>
      </li>
     
      </header>
<div>
  <Link to="/">
  <img className="crew-pick-image" src="https://a.ltrbxd.com/resized/sm/upload/mm/d1/e8/u5/zola-0-70-0-105-crop.jpg" alt=""/></Link>
  
  <Link to="/">
  <img className="crew-pick-image" src="https://a.ltrbxd.com/resized/film-poster/4/3/8/7/2/2/438722-luca-0-70-0-105-crop.jpg" alt=""/></Link>
  <Link to="/">
    <img className="crew-pick-image" src="https://a.ltrbxd.com/resized/film-poster/5/6/1/7/6/3/561763-pig-0-70-0-105-crop.jpg" alt=""/></Link>
    <Link to="/">
      
      <img className="crew-pick-image" src="https://a.ltrbxd.com/resized/film-poster/4/5/0/3/3/7/450337-a-quiet-place-part-ii-0-70-0-105-crop.jpg" alt=""/></Link>
      <Link to="/">
        <img className="crew-pick-image" src="https://a.ltrbxd.com/resized/film-poster/3/9/9/5/0/0/399500-in-the-heights-0-70-0-105-crop.jpg" alt=""/></Link>
        <Link to="/">
          <img className="crew-pick-image" src="https://a.ltrbxd.com/resized/film-poster/6/9/5/4/8/8/695488-summer-of-soul-or-when-the-revolution-could-not-be-televi-0-70-0-105-crop.jpg" alt=""/>
            </Link>
            </div>
          <header className="crew-picks-header popular-top-movies-header under-line sub-menu">
            <li className="menu-item iq-up-view-all ">
              <p className="same-line-2" >POPULAR REVIEWERS</p></li>
              
              </header>
              <div>
                <div className="single-popular-review-container"><Link to="/">
                  <img src="https://a.ltrbxd.com/resized/avatar/twitter/1/4/7/0/0/7/shard/http___pbs.twimg.com_profile_images_697635373434982402_M9fARb2J-0-80-0-80-crop.jpg" alt="" className="single-popular-review-image"/></Link>
                  <div className="single-popular-review-context-container">
                    <h6>LUCY</h6>
                  <div><h5>500 films</h5>
                  <h5>1000 reviews</h5>
                  </div>
                  </div>
                  </div>
                  <div className="single-popular-review-container">
                    <Link to="/">
                    <img src="https://movieappimageupload.s3.eu-central-1.amazonaws.com/06cbcecc-fb6b-429a-9335-ac4751252563" alt="" className="single-popular-review-image"/></Link>
                    <div className="single-popular-review-context-container">
                      <h6>Shang-Chi and the Legend of the Ten Rings</h6>
                      <div><h5>500 films</h5>
                      <h5>1000 reviews</h5>
                      </div>
                      </div>
                      </div>
                    <div className="single-popular-review-container">
                      
                      <Link to="/">
                        <img src="https://movieappimageupload.s3.eu-central-1.amazonaws.com/3ddd2b44-5779-4475-b5d7-e9f4322ef7ef" alt="" className="single-popular-review-image"/></Link>
                      <div className="single-popular-review-context-container">
                        <h6>Last Night in Soho</h6>
                      <div><h5>500 films</h5>
                      <h5>1000 reviews</h5>
                      
                      </div>
                      </div>
                      </div>
                      
                      <div className="single-popular-review-container"><Link to="/">
                        <img src="https://movieappimageupload.s3.eu-central-1.amazonaws.com/180991ca-ff15-4c03-a789-2e9d86839e76" alt="" className="single-popular-review-image"/></Link>
                        <div className="single-popular-review-context-container">
                          <h6>Eternals</h6>
                        <div>
                          <h5>500 films</h5>
                          <h5>1000 reviews</h5>
                          </div>
                          </div>
                          </div>
                          <div className="single-popular-review-container">
                            <Link to="/">
                              <img src="https://movieappimageupload.s3.eu-central-1.amazonaws.com/9ac56871-b5c3-4990-b668-7c4a096b3d71" alt="" className="single-popular-review-image"/></Link>
                            <div className="single-popular-review-context-container">
                              <h6>Old</h6>
                            <div>
                              <h5>500 films</h5>
                            <h5>1000 reviews</h5>
                            </div>
                            </div>
                            </div>
                            <div className="single-popular-review-container">
                              <Link to="/">
                              <img src="https://movieappimageupload.s3.eu-central-1.amazonaws.com/4095b790-6d9e-4b23-9aca-09dcf28f86a7" alt="" className="single-popular-review-image"/></Link>
                              <div className="single-popular-review-context-container">
                                <h6>Top Gun: Maverick</h6>
                            <div><h5>500 films</h5><h5>1000 reviews</h5>
                            
                            </div>
                            
                            </div>
                            </div>
                            </div>
                            <div>
                              <header className="crew-picks-header popular-top-movies-header under-line sub-menu">
                                <li className="menu-item iq-up-view-all "><p>CAN’T FIND A FILM?</p></li>
                              </header>
                              <p style={{fontSize: "0.8rem"}}>Help keep cinetrail up to date. Find out how to <Link to="/">add or edit a film.</Link>
                              </p>
                              </div>
                              </div>















    // <Fragment>
      
    //   <header className="crew-picks-header popular-top-movies-header under-line sub-menu">      
    //   <li className="menu-item iq-up-view-all "> 
    //    <p>Crew Picks</p></li>        
    //     <p>More</p>        
    //   </header>


    //   <div>
    //     {response.slice(0, 6).map(({ mediaId: { url } }, idx) => (
    //       <Link to="/" key={idx}>
    //         <img className="crew-pick-image" src={url} alt="" />
    //       </Link>
    //     ))}
    //   </div>
    // </Fragment>
  );
};

export default CrewPicks;
