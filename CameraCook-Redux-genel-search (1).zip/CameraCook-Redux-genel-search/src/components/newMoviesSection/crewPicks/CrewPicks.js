import axios from "axios";
import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { Link } from "react-router-dom";
import "./crewPicks.css";
import { API_BASE }  from "../../../actions/api_base";


const CrewPicks = () => {

	const [state, setstate] = useState()
	useEffect(() => {
		GetLists()
	}, [])

	const GetLists = () => {
		axios.get(`${API_BASE}lists`)
		.then(res=>{
			//console.log(res.data)
			setstate(res.data.response)
		})
		.catch(err=>console.log(err))
	}





  return (


	<div style={{marginTop:"10%"}}>

	<section id="crew-picks" className="section">
		<h2 className="section-heading">Crew picks</h2>
		<div className="featured-list">

			{state?.map(list=>{
				return list.movieIds.length > 5 && <section className="list -overlapped -stacked list-stacked-narrow -ellipsis-230" data-film-list-id="18498317" data-person="tiff_net" key={list._id}>
				
				
				<Link to={`/list-card/${list._id}`} className="list-link">
					<div className="list-link-stacked clear">
						<ul className="poster-list -overlapped -p70">
							{list.movieIds?.map((movie,index)=>{
								return index < 5 && <li key={index} className="react-component poster film-poster film-poster-496193 listitem"  data-film-id="496193" data-film-name={movie.original_title} data-poster-url="/film/dear-evan-hansen/image-150/" data-film-release-year="2021" data-new-list-with-film-action="/list/new/with/dear-evan-hansen/" data-remove-from-watchlist-action="/film/dear-evan-hansen/remove-from-watchlist/" data-add-to-watchlist-action="/film/dear-evan-hansen/add-to-watchlist/" data-rate-action="/film/dear-evan-hansen/rate/" data-mark-as-watched-action="/film/dear-evan-hansen/mark-as-watched/" data-mark-as-not-watched-action="/film/dear-evan-hansen/mark-as-not-watched/" data-film-link="/film/dear-evan-hansen/">
								<div><img src={`https://image.tmdb.org/t/p/w92/${movie.image_path}`} width="70" height="105" alt={movie.original_title} srcSet={`https://image.tmdb.org/t/p/w92/${movie.image_path}`} className="image"/><span className="frame"><span className="frame-title">{movie.original_title}</span></span>
								</div></li>
							})}	
						</ul>
					</div>
					<span className="overlay"></span>
				</Link>
				
					
				<h3 className="title-3 prettify"> <a href="/tiff_net/list/2021-toronto-international-film-festival/">{list.name}</a> </h3>
				
				<div className="attribution-block">
					<Link className="avatar -a16" to={`/member-card/${list.userId[0]._id}`} data-original-title=""> <img src={list.userId[0].mediaId[0].url} alt={list.userId[0].firstname} width="16" height="16"/> </Link>
					
							<p className="attribution">
								<strong className="name"><Link to={`/member-card/${list.userId[0]._id}`}>{list.userId[0].firstname}</Link></strong> 
								<small className="value">{list.movieIds.length}&nbsp;films</small>
									
							</p>	
				</div>	
				<hr style={{marginTop:"14%"}}/>		
			</section>
			})}
			
						
		</div>
	</section>


	</div>
  );
};

export default CrewPicks;
