<section id="crew-picks" class="section">
			<h2 class="section-heading">Crew picks</h2>
			<div class="featured-list">
				
		<section class="list -overlapped -stacked list-stacked-narrow -ellipsis-230" data-film-list-id="18498317" data-person="tiff_net">
			
			
			<a href="/tiff_net/list/2021-toronto-international-film-festival/" class="list-link">
				<div class="list-link-stacked clear">
					<ul class="poster-list -overlapped -p70">
						
						
		<li class="react-component poster film-poster film-poster-496193 listitem" data-component-class="globals.comps.FilmPosterComponent" data-film-id="496193" data-film-name="Dear Evan Hansen" data-poster-url="/film/dear-evan-hansen/image-150/" data-film-release-year="2021" data-new-list-with-film-action="/list/new/with/dear-evan-hansen/" data-remove-from-watchlist-action="/film/dear-evan-hansen/remove-from-watchlist/" data-add-to-watchlist-action="/film/dear-evan-hansen/add-to-watchlist/" data-rate-action="/film/dear-evan-hansen/rate/" data-mark-as-watched-action="/film/dear-evan-hansen/mark-as-watched/" data-mark-as-not-watched-action="/film/dear-evan-hansen/mark-as-not-watched/" data-film-link="/film/dear-evan-hansen/">
      <div><img src="https://a.ltrbxd.com/resized/film-poster/4/9/6/1/9/3/496193-dear-evan-hansen-0-70-0-105-crop.jpg?k=ffffe7936d" width="70" height="105" alt="Dear Evan Hansen" srcset="https://a.ltrbxd.com/resized/film-poster/4/9/6/1/9/3/496193-dear-evan-hansen-0-140-0-210-crop.jpg?k=ffffe7936d 2x" class="image"/><span class="frame"><span class="frame-title">Dear Evan Hansen (2021)</span></span>
      </div></li>

							
						
	<li class="react-component poster film-poster film-poster-704152 listitem" data-component-class="globals.comps.FilmPosterComponent" data-film-id="704152" data-film-name="7 Prisoners" data-poster-url="/film/7-prisoners/image-150/" data-film-release-year="2021" data-new-list-with-film-action="/list/new/with/7-prisoners/" data-remove-from-watchlist-action="/film/7-prisoners/remove-from-watchlist/" data-add-to-watchlist-action="/film/7-prisoners/add-to-watchlist/" data-rate-action="/film/7-prisoners/rate/" data-mark-as-watched-action="/film/7-prisoners/mark-as-watched/" data-mark-as-not-watched-action="/film/7-prisoners/mark-as-not-watched/" data-film-link="/film/7-prisoners/">
    <div><img src="https://a.ltrbxd.com/resized/film-poster/7/0/4/1/5/2/704152-7-prisoners-0-70-0-105-crop.jpg?k=df5cce2025" width="70" height="105" alt="7 Prisoners" srcset="https://a.ltrbxd.com/resized/film-poster/7/0/4/1/5/2/704152-7-prisoners-0-140-0-210-crop.jpg?k=2b2162fe7e 2x" class="image"/><span class="frame"><span class="frame-title">7 Prisoners (2021)</span></span>
    </div>
    </li>

							
						
	<li class="react-component poster film-poster film-poster-587134 listitem" data-component-class="globals.comps.FilmPosterComponent" data-film-id="587134" data-film-name="Ahed's Knee" data-poster-url="/film/aheds-knee/image-150/" data-film-release-year="2021" data-new-list-with-film-action="/list/new/with/aheds-knee/" data-remove-from-watchlist-action="/film/aheds-knee/remove-from-watchlist/" data-add-to-watchlist-action="/film/aheds-knee/add-to-watchlist/" data-rate-action="/film/aheds-knee/rate/" data-mark-as-watched-action="/film/aheds-knee/mark-as-watched/" data-mark-as-not-watched-action="/film/aheds-knee/mark-as-not-watched/" data-film-link="/film/aheds-knee/">
    <div><img src="https://a.ltrbxd.com/resized/film-poster/5/8/7/1/3/4/587134-ahed-s-knee-0-70-0-105-crop.jpg?k=2366c6e492" width="70" height="105" alt="Ahed's Knee" srcset="https://a.ltrbxd.com/resized/film-poster/5/8/7/1/3/4/587134-ahed-s-knee-0-140-0-210-crop.jpg?k=0e4c36edcb 2x" class="image"/><span class="frame"><span class="frame-title">Ahed's Knee (2021)</span></span>
    </div>
    </li>

							
						
<li class="react-component poster film-poster film-poster-586726 listitem" data-component-class="globals.comps.FilmPosterComponent" data-film-id="586726" data-film-name="Ali &amp; Ava" data-poster-url="/film/ali-ava/image-150/" data-film-release-year="2021" data-new-list-with-film-action="/list/new/with/ali-ava/" data-remove-from-watchlist-action="/film/ali-ava/remove-from-watchlist/" data-add-to-watchlist-action="/film/ali-ava/add-to-watchlist/" data-rate-action="/film/ali-ava/rate/" data-mark-as-watched-action="/film/ali-ava/mark-as-watched/" data-mark-as-not-watched-action="/film/ali-ava/mark-as-not-watched/" data-film-link="/film/ali-ava/">
  <div><img src="https://a.ltrbxd.com/resized/film-poster/5/8/6/7/2/6/586726-ali-ava-0-70-0-105-crop.jpg?k=18c494404d" width="70" height="105" alt="Ali &amp; Ava" srcset="https://a.ltrbxd.com/resized/film-poster/5/8/6/7/2/6/586726-ali-ava-0-140-0-210-crop.jpg?k=303c60e9b0 2x" class="image"/><span class="frame"><span class="frame-title">Ali &amp; Ava (2021)</span></span>
  </div>
  </li>

							
						
	<li class="react-component poster film-poster film-poster-700928 listitem" data-component-class="globals.comps.FilmPosterComponent" data-film-id="700928" data-film-name="All My Puny Sorrows" data-poster-url="/film/all-my-puny-sorrows/image-150/" data-film-release-year="2021" data-new-list-with-film-action="/list/new/with/all-my-puny-sorrows/" data-remove-from-watchlist-action="/film/all-my-puny-sorrows/remove-from-watchlist/" data-add-to-watchlist-action="/film/all-my-puny-sorrows/add-to-watchlist/" data-rate-action="/film/all-my-puny-sorrows/rate/" data-mark-as-watched-action="/film/all-my-puny-sorrows/mark-as-watched/" data-mark-as-not-watched-action="/film/all-my-puny-sorrows/mark-as-not-watched/" data-film-link="/film/all-my-puny-sorrows/">
    <div><img src="https://a.ltrbxd.com/resized/film-poster/7/0/0/9/2/8/700928-all-my-puny-sorrows-0-70-0-105-crop.jpg?k=ad2e9e2061" width="70" height="105" alt="All My Puny Sorrows" srcset="https://a.ltrbxd.com/resized/film-poster/7/0/0/9/2/8/700928-all-my-puny-sorrows-0-140-0-210-crop.jpg?k=23e4d4acb1 2x" class="image"/><span class="frame"><span class="frame-title">All My Puny Sorrows (2021)</span></span>
    </div></li>
	
						
					</ul>
				</div>
				<span class="overlay"></span>
			</a>
			
				
	<h3 class="title-3 prettify"> <a href="/tiff_net/list/2021-toronto-international-film-festival/">2021 Toronto International Film Festival</a> </h3>
			
    	<div class="attribution-block">
						<a class="avatar -a16" href="/tiff_net/" data-original-title=""> <img src="https://a.ltrbxd.com/resized/avatar/twitter/2/7/4/4/1/0/0/shard/http___pbs.twimg.com_profile_images_1407700676084383750_LGTouQ9h-0-32-0-32-crop.png?k=f2463cd338" alt="TIFF" width="16" height="16"/> </a>
						
								<p class="attribution">
									<strong class="name"><a href="/tiff_net/">TIFF</a></strong> 
									
	
		<small class="value">153&nbsp;films</small>
										
								</p>
							
					</div>
					
		</section>
	
		<section class="list -overlapped -stacked list-stacked-narrow -ellipsis-230" data-film-list-id="5660837" data-person="rob_h">
						
			<a href="/rob_h/list/award-winners-venice-golden-lion/" class="list-link">
				<div class="list-link-stacked clear">
					<ul class="poster-list -overlapped -p70">
					
						
		<li class="react-component poster film-poster film-poster-20011 listitem" data-component-class="globals.comps.FilmPosterComponent" data-film-id="20011" data-film-name="The Southerner" data-poster-url="/film/the-southerner/image-150/" data-film-release-year="1945" data-new-list-with-film-action="/list/new/with/the-southerner/" data-remove-from-watchlist-action="/film/the-southerner/remove-from-watchlist/" data-add-to-watchlist-action="/film/the-southerner/add-to-watchlist/" data-rate-action="/film/the-southerner/rate/" data-mark-as-watched-action="/film/the-southerner/mark-as-watched/" data-mark-as-not-watched-action="/film/the-southerner/mark-as-not-watched/" data-film-link="/film/the-southerner/">
      <div><img src="https://a.ltrbxd.com/resized/film-poster/2/0/0/1/1/20011-the-southerner-0-70-0-105-crop.jpg?k=8764cb81f3" width="70" height="105" alt="The Southerner" srcset="https://a.ltrbxd.com/resized/film-poster/2/0/0/1/1/20011-the-southerner-0-140-0-210-crop.jpg?k=217c66a193 2x" class="image"/><span class="frame"><span class="frame-title">The Southerner (1945)</span></span>
      </div></li>

							
						
	<li class="react-component poster film-poster film-poster-146428 listitem" data-component-class="globals.comps.FilmPosterComponent" data-film-id="146428" data-film-name="The Strike" data-poster-url="/film/the-strike/image-150/" data-film-release-year="1947" data-new-list-with-film-action="/list/new/with/the-strike/" data-remove-from-watchlist-action="/film/the-strike/remove-from-watchlist/" data-add-to-watchlist-action="/film/the-strike/add-to-watchlist/" data-rate-action="/film/the-strike/rate/" data-mark-as-watched-action="/film/the-strike/mark-as-watched/" data-mark-as-not-watched-action="/film/the-strike/mark-as-not-watched/" data-film-link="/film/the-strike/">
    <div><img src="https://a.ltrbxd.com/resized/film-poster/1/4/6/4/2/8/146428-the-strike-0-70-0-105-crop.jpg?k=19fb27b09f" width="70" height="105" alt="The Strike" srcset="https://a.ltrbxd.com/resized/film-poster/1/4/6/4/2/8/146428-the-strike-0-140-0-210-crop.jpg?k=daaac3073f 2x" class="image"/><span class="frame"><span class="frame-title">The Strike (1947)</span></span>
    </div></li>

							
						
	<li class="react-component poster film-poster film-poster-37401 listitem" data-component-class="globals.comps.FilmPosterComponent" data-film-id="37401" data-film-name="Hamlet" data-poster-url="/film/hamlet/image-150/" data-film-release-year="1948" data-new-list-with-film-action="/list/new/with/hamlet/" data-remove-from-watchlist-action="/film/hamlet/remove-from-watchlist/" data-add-to-watchlist-action="/film/hamlet/add-to-watchlist/" data-rate-action="/film/hamlet/rate/" data-mark-as-watched-action="/film/hamlet/mark-as-watched/" data-mark-as-not-watched-action="/film/hamlet/mark-as-not-watched/" data-film-link="/film/hamlet/">
    <div><img src="https://a.ltrbxd.com/resized/sm/upload/du/cd/zy/ha/nWFbMI774M238az4k9vZk1hLyob-0-70-0-105-crop.jpg?k=241d3a1132" width="70" height="105" alt="Hamlet" srcset="https://a.ltrbxd.com/resized/sm/upload/du/cd/zy/ha/nWFbMI774M238az4k9vZk1hLyob-0-140-0-210-crop.jpg?k=36ebf1aa2f 2x" class="image"/><span class="frame"><span class="frame-title">Hamlet (1948)</span></span>
    </div></li>

							
						
		<li class="react-component poster film-poster film-poster-102353 listitem" data-component-class="globals.comps.FilmPosterComponent" data-film-id="102353" data-film-name="Manon" data-poster-url="/film/manon/image-150/" data-film-release-year="1949" data-new-list-with-film-action="/list/new/with/manon/" data-remove-from-watchlist-action="/film/manon/remove-from-watchlist/" data-add-to-watchlist-action="/film/manon/add-to-watchlist/" data-rate-action="/film/manon/rate/" data-mark-as-watched-action="/film/manon/mark-as-watched/" data-mark-as-not-watched-action="/film/manon/mark-as-not-watched/" data-film-link="/film/manon/">
      <div><img src="https://a.ltrbxd.com/resized/film-poster/1/0/2/3/5/3/102353-manon-0-70-0-105-crop.jpg?k=824bbc3cda" width="70" height="105" alt="Manon" srcset="https://a.ltrbxd.com/resized/film-poster/1/0/2/3/5/3/102353-manon-0-140-0-210-crop.jpg?k=824bbc3cda 2x" class="image"/><span class="frame"><span class="frame-title">Manon (1949)</span></span>
      </div></li>

							
						
		<li class="react-component poster film-poster film-poster-53460 listitem" data-component-class="globals.comps.FilmPosterComponent" data-film-id="53460" data-film-name="Justice Is Done" data-poster-url="/film/justice-is-done/image-150/" data-film-release-year="1950" data-new-list-with-film-action="/list/new/with/justice-is-done/" data-remove-from-watchlist-action="/film/justice-is-done/remove-from-watchlist/" data-add-to-watchlist-action="/film/justice-is-done/add-to-watchlist/" data-rate-action="/film/justice-is-done/rate/" data-mark-as-watched-action="/film/justice-is-done/mark-as-watched/" data-mark-as-not-watched-action="/film/justice-is-done/mark-as-not-watched/" data-film-link="/film/justice-is-done/">
      <div><img src="https://a.ltrbxd.com/resized/film-poster/5/3/4/6/0/53460-justice-is-done-0-70-0-105-crop.jpg?k=fe9d538325" width="70" height="105" alt="Justice Is Done" srcset="https://a.ltrbxd.com/resized/film-poster/5/3/4/6/0/53460-justice-is-done-0-140-0-210-crop.jpg?k=bb61a641b0 2x" class="image"/><span class="frame"><span class="frame-title">Justice Is Done (1950)</span></span>
      </div></li>

					</ul>
				</div>
				<span class="overlay"></span>
			</a>
			
				
	<h3 class="title-3 prettify"> <a href="/rob_h/list/award-winners-venice-golden-lion/">Award Winners: Venice - Golden Lion</a> </h3>
			
				
			<div class="attribution-block">
						<a class="avatar -a16" href="/rob_h/" data-original-title=""> <img src="https://a.ltrbxd.com/resized/avatar/twitter/1/3/5/7/4/6/8/shard/http___pbs.twimg.com_profile_images_1117777861270745088_PVqoVpms-0-32-0-32-crop.jpg?k=dc2deb77a4" alt="Rob" width="16" height="16"/> </a>
						
								<p class="attribution">
									<strong class="name"><a href="/rob_h/">Rob</a></strong> 
									
	
		<small class="value">68&nbsp;films</small>
	
								</p>
							
					</div>
				
		</section>
	
		<section class="list -overlapped -stacked list-stacked-narrow -ellipsis-230" data-film-list-id="1519598" data-person="dahveedgr">
			
			
			<a href="/dahveedgr/list/movie-posters-backs/" class="list-link">
				<div class="list-link-stacked clear">
					<ul class="poster-list -overlapped -p70">
						
						
	<li class="react-component poster film-poster film-poster-389734 listitem" data-component-class="globals.comps.FilmPosterComponent" data-film-id="389734" data-film-name="Turkish Saddle" data-poster-url="/film/turkish-saddle/image-150/" data-film-release-year="2017" data-new-list-with-film-action="/list/new/with/turkish-saddle/" data-remove-from-watchlist-action="/film/turkish-saddle/remove-from-watchlist/" data-add-to-watchlist-action="/film/turkish-saddle/add-to-watchlist/" data-rate-action="/film/turkish-saddle/rate/" data-mark-as-watched-action="/film/turkish-saddle/mark-as-watched/" data-mark-as-not-watched-action="/film/turkish-saddle/mark-as-not-watched/" data-film-link="/film/turkish-saddle/">
    <div><img src="https://a.ltrbxd.com/resized/film-poster/3/8/9/7/3/4/389734-turkish-saddle-0-70-0-105-crop.jpg?k=524b6848c5" width="70" height="105" alt="Turkish Saddle" srcset="https://a.ltrbxd.com/resized/film-poster/3/8/9/7/3/4/389734-turkish-saddle-0-140-0-210-crop.jpg?k=c1f1bd3c23 2x" class="image"/><span class="frame"><span class="frame-title">Turkish Saddle (2017)</span></span>
    </div></li>

							
						
	<li class="react-component poster film-poster film-poster-198030 listitem" data-component-class="globals.comps.FilmPosterComponent" data-film-id="198030" data-film-name="Selma" data-poster-url="/film/selma/image-150/" data-film-release-year="2014" data-new-list-with-film-action="/list/new/with/selma/" data-remove-from-watchlist-action="/film/selma/remove-from-watchlist/" data-add-to-watchlist-action="/film/selma/add-to-watchlist/" data-rate-action="/film/selma/rate/" data-mark-as-watched-action="/film/selma/mark-as-watched/" data-mark-as-not-watched-action="/film/selma/mark-as-not-watched/" data-film-link="/film/selma/">
    <div><img src="https://a.ltrbxd.com/resized/film-poster/1/9/8/0/3/0/198030-selma-0-70-0-105-crop.jpg?k=6994256b47" width="70" height="105" alt="Selma" srcset="https://a.ltrbxd.com/resized/film-poster/1/9/8/0/3/0/198030-selma-0-140-0-210-crop.jpg?k=60e9763b1e 2x" class="image"/><span class="frame"><span class="frame-title">Selma (2014)</span></span>
    </div></li>

							
						
<li class="react-component poster film-poster film-poster-293200 listitem" data-component-class="globals.comps.FilmPosterComponent" data-film-id="293200" data-film-name="Departure" data-poster-url="/film/departure-2015/image-150/" data-film-release-year="2015" data-new-list-with-film-action="/list/new/with/departure-2015/" data-remove-from-watchlist-action="/film/departure-2015/remove-from-watchlist/" data-add-to-watchlist-action="/film/departure-2015/add-to-watchlist/" data-rate-action="/film/departure-2015/rate/" data-mark-as-watched-action="/film/departure-2015/mark-as-watched/" data-mark-as-not-watched-action="/film/departure-2015/mark-as-not-watched/" data-film-link="/film/departure-2015/">
  <div><img src="https://a.ltrbxd.com/resized/film-poster/2/9/3/2/0/0/293200-departure-0-70-0-105-crop.jpg?k=73cd4820c6" width="70" height="105" alt="Departure" srcset="https://a.ltrbxd.com/resized/film-poster/2/9/3/2/0/0/293200-departure-0-140-0-210-crop.jpg?k=9fa90121d6 2x" class="image"/><span class="frame"><span class="frame-title">Departure (2015)</span></span>
  </div></li>

							
						
	<li class="react-component poster film-poster film-poster-11291 listitem" data-component-class="globals.comps.FilmPosterComponent" data-film-id="11291" data-film-name="Staggered" data-poster-url="/film/staggered/image-150/" data-film-release-year="1994" data-new-list-with-film-action="/list/new/with/staggered/" data-remove-from-watchlist-action="/film/staggered/remove-from-watchlist/" data-add-to-watchlist-action="/film/staggered/add-to-watchlist/" data-rate-action="/film/staggered/rate/" data-mark-as-watched-action="/film/staggered/mark-as-watched/" data-mark-as-not-watched-action="/film/staggered/mark-as-not-watched/" data-film-link="/film/staggered/">
    <div><img src="https://a.ltrbxd.com/resized/film-poster/1/1/2/9/1/11291-staggered-0-70-0-105-crop.jpg?k=d12da71e07" width="70" height="105" alt="Staggered" srcset="https://a.ltrbxd.com/resized/film-poster/1/1/2/9/1/11291-staggered-0-140-0-210-crop.jpg?k=bc41a82121 2x" class="image"/><span class="frame"><span class="frame-title">Staggered (1994)</span></span>
    </div></li>
							
						
		<li class="react-component poster film-poster film-poster-3520 listitem" data-component-class="globals.comps.FilmPosterComponent" data-film-id="3520" data-film-name="Bullhead" data-poster-url="/film/bullhead/image-150/" data-film-release-year="2011" data-new-list-with-film-action="/list/new/with/bullhead/" data-remove-from-watchlist-action="/film/bullhead/remove-from-watchlist/" data-add-to-watchlist-action="/film/bullhead/add-to-watchlist/" data-rate-action="/film/bullhead/rate/" data-mark-as-watched-action="/film/bullhead/mark-as-watched/" data-mark-as-not-watched-action="/film/bullhead/mark-as-not-watched/" data-film-link="/film/bullhead/">
      <div><img src="https://a.ltrbxd.com/resized/sm/upload/0m/k4/yj/0l/bullhead-0-70-0-105-crop.jpg?k=9b5d397271" width="70" height="105" alt="Bullhead" srcset="https://a.ltrbxd.com/resized/sm/upload/0m/k4/yj/0l/bullhead-0-140-0-210-crop.jpg?k=c51cce2164 2x" class="image"/><span class="frame"><span class="frame-title">Bullhead (2011)</span></span>
      </div>
      </li>

					</ul>
				</div>
				<span class="overlay"></span>
			</a>
							
	<h3 class="title-3 prettify"> <a href="/dahveedgr/list/movie-posters-backs/">Movie Posters: Backs</a> </h3>

					<div class="attribution-block">
						<a class="avatar -a16" href="/dahveedgr/" data-original-title=""> <img src="https://a.ltrbxd.com/resized/avatar/twitter/1/8/0/9/0/0/shard/http___pbs.twimg.com_profile_images_997519785091977221_t_AGnT0N-0-32-0-32-crop.jpg?k=6300bdd8a0" alt="David Gómez-Rosado" width="16" height="16"/> </a>
						
								<p class="attribution">
									<strong class="name"><a href="/dahveedgr/">David Gómez-Rosado</a></strong> 									
	
		<small class="value">1,287&nbsp;films</small>
									
								</p>
					</div>			
		</section>
	
		<section class="list -overlapped -stacked list-stacked-narrow -ellipsis-230" data-film-list-id="2567228" data-person="ellefnning">
				
			
			<a href="/ellefnning/list/movies-where-a-character-says-jack-in-an/" class="list-link">
				<div class="list-link-stacked clear">
					<ul class="poster-list -overlapped -p70">						
						
	<li class="react-component poster film-poster film-poster-51524 listitem" data-component-class="globals.comps.FilmPosterComponent" data-film-id="51524" data-film-name="Titanic" data-poster-url="/film/titanic-1997/image-150/" data-film-release-year="1997" data-new-list-with-film-action="/list/new/with/titanic-1997/" data-remove-from-watchlist-action="/film/titanic-1997/remove-from-watchlist/" data-add-to-watchlist-action="/film/titanic-1997/add-to-watchlist/" data-rate-action="/film/titanic-1997/rate/" data-mark-as-watched-action="/film/titanic-1997/mark-as-watched/" data-mark-as-not-watched-action="/film/titanic-1997/mark-as-not-watched/" data-film-link="/film/titanic-1997/">
    <div><img src="https://a.ltrbxd.com/resized/film-poster/5/1/5/2/4/51524-titanic-0-70-0-105-crop.jpg?k=3bcdb0321d" width="70" height="105" alt="Titanic" srcset="https://a.ltrbxd.com/resized/film-poster/5/1/5/2/4/51524-titanic-0-140-0-210-crop.jpg?k=22c86559e9 2x" class="image"/><span class="frame"><span class="frame-title">Titanic (1997)</span></span>
    </div></li>

						
				<li class="react-component poster film-poster film-poster-312204 listitem" data-component-class="globals.comps.FilmPosterComponent" data-film-id="312204" data-film-name="Jackie" data-poster-url="/film/jackie-2016/image-150/" data-film-release-year="2016" data-new-list-with-film-action="/list/new/with/jackie-2016/" data-remove-from-watchlist-action="/film/jackie-2016/remove-from-watchlist/" data-add-to-watchlist-action="/film/jackie-2016/add-to-watchlist/" data-rate-action="/film/jackie-2016/rate/" data-mark-as-watched-action="/film/jackie-2016/mark-as-watched/" data-mark-as-not-watched-action="/film/jackie-2016/mark-as-not-watched/" data-film-link="/film/jackie-2016/">
          <div><img src="https://a.ltrbxd.com/resized/sm/upload/kl/ys/8q/uf/iMkl2Akc1f4CSJCieVwczM4KjZR-0-70-0-105-crop.jpg?k=6b545191de" width="70" height="105" alt="Jackie" srcset="https://a.ltrbxd.com/resized/sm/upload/kl/ys/8q/uf/iMkl2Akc1f4CSJCieVwczM4KjZR-0-140-0-210-crop.jpg?k=f61ac4a79c 2x" class="image"/><span class="frame"><span class="frame-title">Jackie (2016)</span></span>
          </div></li>

							
						
				<li class="react-component poster film-poster film-poster-47119 listitem" data-component-class="globals.comps.FilmPosterComponent" data-film-id="47119" data-film-name="The Nightmare Before Christmas" data-poster-url="/film/the-nightmare-before-christmas/image-150/" data-film-release-year="1993" data-new-list-with-film-action="/list/new/with/the-nightmare-before-christmas/" data-remove-from-watchlist-action="/film/the-nightmare-before-christmas/remove-from-watchlist/" data-add-to-watchlist-action="/film/the-nightmare-before-christmas/add-to-watchlist/" data-rate-action="/film/the-nightmare-before-christmas/rate/" data-mark-as-watched-action="/film/the-nightmare-before-christmas/mark-as-watched/" data-mark-as-not-watched-action="/film/the-nightmare-before-christmas/mark-as-not-watched/" data-film-link="/film/the-nightmare-before-christmas/">
          <div><img src="https://a.ltrbxd.com/resized/film-poster/4/7/1/1/9/47119-the-nightmare-before-christmas-0-70-0-105-crop.jpg?k=03fc3ab8a8" width="70" height="105" alt="The Nightmare Before Christmas" srcset="https://a.ltrbxd.com/resized/film-poster/4/7/1/1/9/47119-the-nightmare-before-christmas-0-140-0-210-crop.jpg?k=290fba3953 2x" class="image"/><span class="frame"><span class="frame-title">The Nightmare Before Christmas (1993)</span></span>
          </div></li>
		
						
			<li class="react-component poster film-poster film-poster-187975 listitem" data-component-class="globals.comps.FilmPosterComponent" data-film-id="187975" data-film-name="Room" data-poster-url="/film/room-2015/image-150/" data-film-release-year="2015" data-new-list-with-film-action="/list/new/with/room-2015/" data-remove-from-watchlist-action="/film/room-2015/remove-from-watchlist/" data-add-to-watchlist-action="/film/room-2015/add-to-watchlist/" data-rate-action="/film/room-2015/rate/" data-mark-as-watched-action="/film/room-2015/mark-as-watched/" data-mark-as-not-watched-action="/film/room-2015/mark-as-not-watched/" data-film-link="/film/room-2015/">
        <div><img src="https://a.ltrbxd.com/resized/sm/upload/19/uq/1o/de/eqFckcHuFCT1FrzLOAvXBb4jHwq-0-70-0-105-crop.jpg?k=405b03426a" width="70" height="105" alt="Room" srcset="https://a.ltrbxd.com/resized/sm/upload/19/uq/1o/de/eqFckcHuFCT1FrzLOAvXBb4jHwq-0-140-0-210-crop.jpg?k=4de7251e3d 2x" class="image"/><span class="frame"><span class="frame-title">Room (2015)</span></span>
        </div></li>
									
							<li class="react-component poster film-poster film-poster-67639 listitem" data-component-class="globals.comps.FilmPosterComponent" data-film-id="67639" data-film-name="Rise of the Guardians" data-poster-url="/film/rise-of-the-guardians/image-150/" data-film-release-year="2012" data-new-list-with-film-action="/list/new/with/rise-of-the-guardians/" data-remove-from-watchlist-action="/film/rise-of-the-guardians/remove-from-watchlist/" data-add-to-watchlist-action="/film/rise-of-the-guardians/add-to-watchlist/" data-rate-action="/film/rise-of-the-guardians/rate/" data-mark-as-watched-action="/film/rise-of-the-guardians/mark-as-watched/" data-mark-as-not-watched-action="/film/rise-of-the-guardians/mark-as-not-watched/" data-film-link="/film/rise-of-the-guardians/">
                <div><img src="https://a.ltrbxd.com/resized/sm/upload/sq/uq/2f/zg/dnEZZ0ZIVIfSIPIYl7kqYktAZlm-0-70-0-105-crop.jpg?k=711e284b68" width="70" height="105" alt="Rise of the Guardians" srcset="https://a.ltrbxd.com/resized/sm/upload/sq/uq/2f/zg/dnEZZ0ZIVIfSIPIYl7kqYktAZlm-0-140-0-210-crop.jpg?k=a9c73a9722 2x" class="image"/><span class="frame"><span class="frame-title">Rise of the Guardians (2012)</span></span>
                </div></li>
				
					</ul>
				</div>
				<span class="overlay"></span>
			</a>
			
				
	<h3 class="title-3 prettify"> <a href="/ellefnning/list/movies-where-a-character-says-jack-in-an/">Movies where a character says ‘Jack’ in an emotional way</a> </h3>
				
					<div class="attribution-block">
						<a class="avatar -a16" href="/ellefnning/" data-original-title=""> <img src="https://secure.gravatar.com/avatar/4af28f1c1b35f03473665057b07de560?rating=PG&amp;size=32&amp;border=&amp;default=https%3A%2F%2Fs.ltrbxd.com%2Fstatic%2Fimg%2Favatar32.09445e73.png" alt="bel" width="16" height="16"/> </a>
						
								<p class="attribution">
									<strong class="name"><a href="/ellefnning/">bel</a></strong> 
									
	
		<small class="value">16&nbsp;films</small>
									
								</p>
							
					</div>
				
		</section>
	
		<section class="list -overlapped -stacked list-stacked-narrow -ellipsis-230" data-film-list-id="18857567" data-person="Deme0612">
			
			<a href="/deme0612/list/official-top-100-mexican-narrative-feature/" class="list-link">
				<div class="list-link-stacked clear">
					<ul class="poster-list -overlapped -p70">
												
							<li class="react-component poster film-poster film-poster-96070 listitem" data-component-class="globals.comps.FilmPosterComponent" data-film-id="96070" data-film-name="Macario" data-poster-url="/film/macario/image-150/" data-film-release-year="1960" data-new-list-with-film-action="/list/new/with/macario/" data-remove-from-watchlist-action="/film/macario/remove-from-watchlist/" data-add-to-watchlist-action="/film/macario/add-to-watchlist/" data-rate-action="/film/macario/rate/" data-mark-as-watched-action="/film/macario/mark-as-watched/" data-mark-as-not-watched-action="/film/macario/mark-as-not-watched/" data-film-link="/film/macario/">
                <div><img src="https://a.ltrbxd.com/resized/film-poster/9/6/0/7/0/96070-macario-0-70-0-105-crop.jpg?k=70b721d0d0" width="70" height="105" alt="Macario" srcset="https://a.ltrbxd.com/resized/film-poster/9/6/0/7/0/96070-macario-0-140-0-210-crop.jpg?k=a522d6acdc 2x" class="image"/><span class="frame"><span class="frame-title">Macario (1960)</span></span>
                </div></li>
												
							<li class="react-component poster film-poster film-poster-113927 listitem" data-component-class="globals.comps.FilmPosterComponent" data-film-id="113927" data-film-name="The Secret Formula" data-poster-url="/film/the-secret-formula/image-150/" data-film-release-year="1965" data-new-list-with-film-action="/list/new/with/the-secret-formula/" data-remove-from-watchlist-action="/film/the-secret-formula/remove-from-watchlist/" data-add-to-watchlist-action="/film/the-secret-formula/add-to-watchlist/" data-rate-action="/film/the-secret-formula/rate/" data-mark-as-watched-action="/film/the-secret-formula/mark-as-watched/" data-mark-as-not-watched-action="/film/the-secret-formula/mark-as-not-watched/" data-film-link="/film/the-secret-formula/">
                <div><img src="https://a.ltrbxd.com/resized/film-poster/1/1/3/9/2/7/113927-the-secret-formula-0-70-0-105-crop.jpg?k=3c014b9814" width="70" height="105" alt="The Secret Formula" srcset="https://a.ltrbxd.com/resized/film-poster/1/1/3/9/2/7/113927-the-secret-formula-0-140-0-210-crop.jpg?k=c442b99e57 2x" class="image"/><span class="frame"><span class="frame-title">The Secret Formula (1965)</span></span>
                </div></li>
												
							<li class="react-component poster film-poster film-poster-51352 listitem" data-component-class="globals.comps.FilmPosterComponent" data-film-id="51352" data-film-name="The Young and the Damned" data-poster-url="/film/the-young-and-the-damned/image-150/" data-film-release-year="1950" data-new-list-with-film-action="/list/new/with/the-young-and-the-damned/" data-remove-from-watchlist-action="/film/the-young-and-the-damned/remove-from-watchlist/" data-add-to-watchlist-action="/film/the-young-and-the-damned/add-to-watchlist/" data-rate-action="/film/the-young-and-the-damned/rate/" data-mark-as-watched-action="/film/the-young-and-the-damned/mark-as-watched/" data-mark-as-not-watched-action="/film/the-young-and-the-damned/mark-as-not-watched/" data-film-link="/film/the-young-and-the-damned/">
                <div><img src="https://a.ltrbxd.com/resized/film-poster/5/1/3/5/2/51352-los-olvidados-0-70-0-105-crop.jpg?k=3cd8eb058e" width="70" height="105" alt="The Young and the Damned" srcset="https://a.ltrbxd.com/resized/film-poster/5/1/3/5/2/51352-los-olvidados-0-140-0-210-crop.jpg?k=32b2eeb79a 2x" class="image"/><span class="frame"><span class="frame-title">The Young and the Damned (1950)</span></span>
                </div></li>
										
							<li class="react-component poster film-poster film-poster-92749 listitem" data-component-class="globals.comps.FilmPosterComponent" data-film-id="92749" data-film-name="Canoa: A Shameful Memory" data-poster-url="/film/canoa-a-shameful-memory/image-150/" data-film-release-year="1976" data-new-list-with-film-action="/list/new/with/canoa-a-shameful-memory/" data-remove-from-watchlist-action="/film/canoa-a-shameful-memory/remove-from-watchlist/" data-add-to-watchlist-action="/film/canoa-a-shameful-memory/add-to-watchlist/" data-rate-action="/film/canoa-a-shameful-memory/rate/" data-mark-as-watched-action="/film/canoa-a-shameful-memory/mark-as-watched/" data-mark-as-not-watched-action="/film/canoa-a-shameful-memory/mark-as-not-watched/" data-film-link="/film/canoa-a-shameful-memory/">
                <div><img src="https://a.ltrbxd.com/resized/film-poster/9/2/7/4/9/92749-canoa-a-shameful-memory-0-70-0-105-crop.jpg?k=ac0a5bd467" width="70" height="105" alt="Canoa: A Shameful Memory" srcset="https://a.ltrbxd.com/resized/film-poster/9/2/7/4/9/92749-canoa-a-shameful-memory-0-140-0-210-crop.jpg?k=b0675fe12f 2x" class="image"/><span class="frame"><span class="frame-title">Canoa: A Shameful Memory (1976)</span></span>
                </div></li>

							<li class="react-component poster film-poster film-poster-51047 listitem" data-component-class="globals.comps.FilmPosterComponent" data-film-id="51047" data-film-name="Pan's Labyrinth" data-poster-url="/film/pans-labyrinth/image-150/" data-film-release-year="2006" data-new-list-with-film-action="/list/new/with/pans-labyrinth/" data-remove-from-watchlist-action="/film/pans-labyrinth/remove-from-watchlist/" data-add-to-watchlist-action="/film/pans-labyrinth/add-to-watchlist/" data-rate-action="/film/pans-labyrinth/rate/" data-mark-as-watched-action="/film/pans-labyrinth/mark-as-watched/" data-mark-as-not-watched-action="/film/pans-labyrinth/mark-as-not-watched/" data-film-link="/film/pans-labyrinth/">
                <div><img src="https://a.ltrbxd.com/resized/film-poster/5/1/0/4/7/51047-pan-s-labyrinth-0-70-0-105-crop.jpg?k=39dcdcc0c1" width="70" height="105" alt="Pan's Labyrinth" srcset="https://a.ltrbxd.com/resized/film-poster/5/1/0/4/7/51047-pan-s-labyrinth-0-140-0-210-crop.jpg?k=f4d1ba4f75 2x" class="image"/><span class="frame"><span class="frame-title">Pan's Labyrinth (2006)</span></span>
                </div></li>

						
					</ul>
				</div>
				<span class="overlay"></span>
			</a>
				
	<h3 class="title-3 prettify"> <a href="/deme0612/list/official-top-100-mexican-narrative-feature/">“Official” Top 100 Mexican Narrative Feature Films</a> </h3>
				
					<div class="attribution-block">
						<a class="avatar -a16" href="/deme0612/" data-original-title=""> <img src="https://a.ltrbxd.com/resized/avatar/upload/2/4/9/3/4/4/5/shard/avtr-0-32-0-32-crop.jpg?k=40e77a0e1c" alt="Deme" width="16" height="16"/> </a>
						
								<p class="attribution">
									<strong class="name"><a href="/deme0612/">Deme</a></strong> 
                  		<small class="value">100&nbsp;films</small>									
								</p>							
					</div>			
		</section>				
			</div>
		</section>