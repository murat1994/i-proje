{/* <div class="container">
  <div class="header">
    <h1 class="heading">Watched Movies</h1>
    <span class="count-pill">20 Movies</span></div>
    <div class="movie-grid">
      <div class="movie-card">
      <div class="overlay"></div>
    <img src="https://image.tmdb.org/t/p/w200/uLjGWaK6riaa8jSuSmaE5FNFRtR.jpg" alt="Blood Tea and Red String Poster"/>
      <div class="inner-card-controls"><button class="ctrl-btn"><i class="fa-fw far fa-eye-slash"></i></button>
      <button class="ctrl-btn"><i class="fa-fw fa fa-times"></i></button></div></div>
      <div class="movie-card">
        <div class="overlay"></div>
      <img src="https://image.tmdb.org/t/p/w200/mWLBf0aSW9CPZcBvTEVglGlx3QT.jpg" alt="Death Wish V: The Face of Death Poster"/>
      <div class="inner-card-controls">
        <button class="ctrl-btn"><i class="fa-fw far fa-eye-slash"></i></button>
        <button class="ctrl-btn"><i class="fa-fw fa fa-times"></i></button></div></div>
        <div class="movie-card">
          <div class="overlay"></div>
        <img src="https://image.tmdb.org/t/p/w200/yBFNJA95MNiasdNUPCU6otdtJE8.jpg" alt="Blue in the Face Poster"/>
        <div class="inner-card-controls"><button class="ctrl-btn"><i class="fa-fw far fa-eye-slash"></i></button><button class="ctrl-btn"><i class="fa-fw fa fa-times"></i></button></div></div>
        <div class="movie-card">
          <div class="overlay"></div>
          <img src="https://image.tmdb.org/t/p/w200/uF2S5BJg418TdpwDSfx5hyTsaHR.jpg" alt="Smiley Face Killers Poster"/>
          <div class="inner-card-controls"><button class="ctrl-btn"><i class="fa-fw far fa-eye-slash"></i></button><button class="ctrl-btn"><i class="fa-fw fa fa-times"></i></button></div></div>
          <div class="movie-card">
            <div class="overlay"></div>
            <img src="https://image.tmdb.org/t/p/w200/fQ7CI5zmmhZlHuYBFKgK9w4hwlS.jpg" alt="R.I.P.D. Poster"/>
              <div class="inner-card-controls"><button class="ctrl-btn"><i class="fa-fw far fa-eye-slash"></i></button><button class="ctrl-btn"><i class="fa-fw fa fa-times"></i></button></div></div>
              <div class="movie-card">
                <div class="overlay"></div>
                <img src="https://image.tmdb.org/t/p/w200/3pyE6ZqDbuJi7zrNzzQzcKTWdmN.jpg" alt="The Rocky Horror Picture Show Poster"/>
                <div class="inner-card-controls"><button class="ctrl-btn"><i class="fa-fw far fa-eye-slash"></i></button><button class="ctrl-btn"><i class="fa-fw fa fa-times"></i></button></div></div>
                <div class="movie-card">
                  <div class="overlay"></div>
                  <img src="https://image.tmdb.org/t/p/w200/upC8KSyoqBUZf5AGTK6xECPuNI7.jpg" alt="Rocky Balboa Poster"/>
                  <div class="inner-card-controls"><button class="ctrl-btn"><i class="fa-fw far fa-eye-slash"></i></button><button class="ctrl-btn"><i class="fa-fw fa fa-times"></i></button></div></div>
                  <div class="movie-card">
                  <div class="overlay"></div>
                  <img src="https://image.tmdb.org/t/p/w200/qCARerjCFZOEeLiVdomhwRYlDSn.jpg" alt="Rocky V Poster"/>
                  <div class="inner-card-controls"><button class="ctrl-btn"><i class="fa-fw far fa-eye-slash"></i></button><button class="ctrl-btn"><i class="fa-fw fa fa-times"></i></button></div>
                  </div>
                  <div class="movie-card">
                    <div class="overlay"></div>
                    <img src="https://image.tmdb.org/t/p/w200/lklrplDDuALhY3k8IDFdRqtpZPk.jpg" alt="Rocky III Poster"/>
                      <div class="inner-card-controls"><button class="ctrl-btn"><i class="fa-fw far fa-eye-slash"></i></button>
                      <button class="ctrl-btn"><i class="fa-fw fa fa-times"></i></button>
                    </div></div>
                    <div class="movie-card">
                      <div class="overlay"></div>
                      <img src="https://image.tmdb.org/t/p/w200/a9UbfUELZHj96tBVWnKrDrtnQcr.jpg" alt="Rocky II Poster"/>
                        <div class="inner-card-controls"><button class="ctrl-btn"><i class="fa-fw far fa-eye-slash"></i></button>
                        <button class="ctrl-btn"><i class="fa-fw fa fa-times"></i></button></div></div>
                    <div class="movie-card">
                      <div class="overlay"></div>
                      <img src="https://image.tmdb.org/t/p/w200/jmvpwgW5M2kduR9zB0q8qGFC4zM.jpg" alt="Rocky IV Poster"/>
                      <div class="inner-card-controls"><button class="ctrl-btn"><i class="fa-fw far fa-eye-slash"></i></button><button class="ctrl-btn"><i class="fa-fw fa fa-times"></i></button></div></div>
                      <div class="movie-card">
                        <div class="overlay"></div>
                        <img src="https://image.tmdb.org/t/p/w200/xtkWmgPIeJ0SqCZyyxiTSsbZXvR.jpg" alt="Rocky Poster"/>
                          <div class="inner-card-controls"><button class="ctrl-btn"><i class="fa-fw far fa-eye-slash"></i></button>
                          <button class="ctrl-btn"><i class="fa-fw fa fa-times"></i></button></div></div>
                        <div class="movie-card">
                          <div class="overlay"></div><img src="https://image.tmdb.org/t/p/w200/xF1uc2pEf34X2G41wvZaF5H0V7C.jpg" alt="Survive the Game Poster"/>
                          <div class="inner-card-controls"><button class="ctrl-btn"><i class="fa-fw far fa-eye-slash"></i></button><button class="ctrl-btn"><i class="fa-fw fa fa-times"></i></button></div></div>
                        <div class="movie-card">
                          <div class="overlay"></div><img src="https://image.tmdb.org/t/p/w200/1fqDXE7nxsqWCng3rwlWZwzBBBn.jpg" alt="End Game Poster"/>
                          <div class="inner-card-controls"><button class="ctrl-btn"><i class="fa-fw far fa-eye-slash"></i></button><button class="ctrl-btn"><i class="fa-fw fa fa-times"></i></button></div></div>
                        <div class="movie-card">
                          <div class="overlay"></div>
                          <img src="https://image.tmdb.org/t/p/w200/fcLFvIqCUrhY96mkSmr3okxaMEw.jpg" alt="The Game Plan Poster"/>
                          <div class="inner-card-controls"><button class="ctrl-btn"><i class="fa-fw far fa-eye-slash"></i></button><button class="ctrl-btn"><i class="fa-fw fa fa-times"></i></button></div></div>
                        <div class="movie-card">
                          <div class="overlay"></div>
                          <img src="https://image.tmdb.org/t/p/w200/4UOa079915QjiTA2u5hT2yKVgUu.jpg" alt="The Game Poster"/>
                          <div class="inner-card-controls"><button class="ctrl-btn"><i class="fa-fw far fa-eye-slash"></i></button><button class="ctrl-btn"><i class="fa-fw fa fa-times"></i></button></div>
                        </div>
                        <div class="movie-card">
                          <div class="overlay"></div>
                          <img src="https://image.tmdb.org/t/p/w200/oP53PyexPlQd1xDt8kkvX5LdQdT.jpg" alt="Spy Kids 3-D: Game Over Poster"/>
                          <div class="inner-card-controls"><button class="ctrl-btn"><i class="fa-fw far fa-eye-slash"></i></button><button class="ctrl-btn"><i class="fa-fw fa fa-times"></i></button></div>
                        </div>
                        <div class="movie-card">
                          <div class="overlay"></div>
                          <img src="https://image.tmdb.org/t/p/w200/tBgkQqrO2RMgGQR6zod3bSjcPWx.jpg" alt="Ender's Game Poster"/>
                          <div class="inner-card-controls"><button class="ctrl-btn"><i class="fa-fw far fa-eye-slash"></i></button>
                          <button class="ctrl-btn"><i class="fa-fw fa fa-times"></i></button></div>
                        </div>
                        <div class="movie-card">
                          <div class="overlay"></div>
                          <img src="https://image.tmdb.org/t/p/w200/qxQFKxE1ehcCyQIUWjCna6lno46.jpg" alt="Spider-Man: Untangled Poster"/>
                          <div class="inner-card-controls"><button class="ctrl-btn"><i class="fa-fw far fa-eye-slash"></i></button>
                          <button class="ctrl-btn"><i class="fa-fw fa fa-times"></i></button></div>
                          </div>
                          <div class="movie-card">
                            <div class="overlay"></div>
                            <img src="https://image.tmdb.org/t/p/w200/fwoETElxZqiF3it8F4HitSliXqp.jpg" alt="Spider-Man Poster"/>
                          <div class="inner-card-controls"><button class="ctrl-btn"><i class="fa-fw far fa-eye-slash"></i></button>
                          <button class="ctrl-btn"><i class="fa-fw fa fa-times"></i></button>
                        </div></div></div>
                        </div> */}