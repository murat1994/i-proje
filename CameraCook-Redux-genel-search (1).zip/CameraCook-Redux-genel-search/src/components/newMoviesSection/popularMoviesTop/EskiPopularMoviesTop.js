import React, { useEffect, useState } from "react";
import "./popularMoviesTop.css";
import "../../pages/movie/CounterShare.css";
import "remixicon/fonts/remixicon.css";

import { Link } from "react-router-dom";
import { useSelector } from "react-redux";

const PopularMoviesTop = () => {
  const [images, setImages] = useState([]);
  const { popularMovies } = useSelector((state) => state.popularMovies);

  useEffect(() => {
    setImages(popularMovies);
  }, [popularMovies]);

  return (
    <div id="content" className="site-body">
      <div className="content-wrap">
        <section id="popular-films">
         

          <ul className="poster-list film-list -p230 film-slider">
          <header className="popular-top-movies-header under-line sub-menu">
            <li className="menu-item iq-up-view-all ">
              <Link to="/Movie">POPULAR FILMS THIS WEEK</Link>
            </li> 
            <li className="menu-item">  <Link to="/MoviesAll">ALL MOVIES</Link> </li>

            {/* <Link>More</Link> */}
          </header>
            {images.map(({ image, original_title, id }) => (
              <li className="listitem slide-item slick-slide slick-active">
                <div className="react-component poster film-poster film-poster-427807 linked-film-poster">
                  <div>
                    <img
                      src={image}
                      width="230"
                      height="345"
                      alt={original_title}
                      className="popular-movies-image-top"
                    />
                    <Link
                      to={`/movie/${id}`}
                      className="frame"
                      title={original_title}
                    >
                      <span className="frame-title">{original_title}</span>
                      <span className="overlay"></span>
                    </Link>
                  </div>
                </div>


              </li>
            ))}
          </ul>
        </section>
        <header className="popular-top-movies-header under-line sub-menu">
          <li className="menu-item iq-up-view-all ">
            <p>.</p>
          </li>

          <p>.</p>
        </header>
      </div>
    </div>
  );
};

export default PopularMoviesTop;
