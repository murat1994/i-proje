import React, { useEffect, useState } from "react";
import axios from "axios"
 import "./popularMoviesTop.css";
import "./popular-films.css";
import "./PopularMoviesNew.css";
 import "../../pages/movie/CounterShare.css";
import "remixicon/fonts/remixicon.css";
import { API_BASE }  from "../../../actions/api_base";

import { Link } from "react-router-dom";
import { useSelector } from "react-redux";

const PopularMoviesTop = () => {
  const [images, setImages] = useState([]);
  const [likedMovies, setLikedMovies] = useState([]);
  const [watchedMovies, setWatchedMovies] = useState([]);
  const [watchlist, setWatchlist] = useState([]);
  const { popularMovies } = useSelector((state) => state.popularMovies);
  const { user } = useSelector((state) => state.auth);

  useEffect(() => {
    setImages(popularMovies);
    GetCurrentUser()
  }, [popularMovies]);


  const GetCurrentUser =() =>{
    axios.get(`${API_BASE}users/${user.id}`)
    .then(res=>{
      //console.log(res.data)
      const arrayLikes = res.data.response[0].liked.map(movie=>{
        return movie.movieId[0].tmdb_id
      })
      setLikedMovies(arrayLikes)

      const arrayWatched = res.data.response[0].watched.map(movie=>{
        return movie.movieId[0].tmdb_id
      })
      setWatchedMovies(arrayWatched)

      const arrayWatchlist = res.data.response[0].watchlist.map(movie=>{
        return movie.movieId[0].tmdb_id
      })
      setWatchlist(arrayWatchlist)
    })
    .catch(err=>console.log(err))
  }
  
  const AddLikeMovie = (e) => {
    //console.log(e.target.classList[4])
   axios.post(`${API_BASE}liked`,{
     userId: user.id,
     movieId: e.target.id
   })
   .then(res=>{
     //console.log(res.data)
     if(res.data.message === "Removed from liked"){
      //setLikedMovies(likedMovies.filter(movie=>{return movie !== e.target.classList[4]}))
      e.target.classList.remove("noHover")
      e.target.classList.add("ctrl-btn")
      e.target.style.color = "#fefefe"
     } else if(res.data.message === "New liked is created successfully"){
      e.target.classList.add("noHover")
      e.target.classList.remove("ctrl-btn")
      e.target.style.color = "orange"
      

     }
   })
   .catch(err=>console.log(err))
  }

  const AddWatchedMovie = (e) => {
    //console.log(e.target.classList[4])
   axios.post(`${API_BASE}watched`,{
    userId: user.id,
    movieId: e.target.id
  })
  .then(res=>{
    //console.log(res.data)
    if(res.data.message === "Removed from watched"){
     //setLikedMovies(likedMovies.filter(movie=>{return movie !== e.target.classList[4]}))
     e.target.classList.remove("noHover")
     e.target.classList.add("ctrl-btn")
     e.target.style.color = "#fefefe"
    } else if(res.data.message === "New watched is created successfully"){
     e.target.classList.add("noHover")
     e.target.classList.remove("ctrl-btn")
     e.target.style.color = "rgb(81, 225, 30)"
     

    }
  })
  .catch(err=>console.log(err))
  }

  const AddWatchlistMovie = (e) => {
    //console.log(e.target.classList[4])
   axios.post(`${API_BASE}watchlist`,{
    userId: user.id,
    movieId: e.target.id
  })
  .then(res=>{
    //console.log(res.data)
    if(res.data.message === "Removed from watchlist"){
     //setLikedMovies(likedMovies.filter(movie=>{return movie !== e.target.classList[4]}))
     e.target.classList.remove("noHover")
     e.target.classList.add("ctrl-btn")
     e.target.style.color = "#fefefe"
    } else if(res.data.message === "New watchlist is created successfully"){
     e.target.classList.add("noHover")
     e.target.classList.remove("ctrl-btn")
     e.target.style.color = "rgb(81, 87, 240)"
     

    }
  })
  .catch(err=>console.log(err))
  }
 
  //console.log(likedMovies)
  return (
    <div id="content" className="site-body">
     <div className="container">  
     <div className="header">
     <header className="popular-top-movies-header under-line sub-menu">
            <li className="menu-item iq-up-view-all ">
              <Link to="/MoviesAll/popular">POPULAR FILMS THIS WEEK</Link>
            </li> 
            <li className="menu-item">  <Link to="/MoviesAll/popular">ALL MOVIES</Link> </li>

           
          </header>
        </div>

    <div className="movie-grid"> 
   

    {images.map(({ image_path, original_title, _id, tmdb_id }) => (
               <div className="movie-card" key={_id}>
               <div className="overlay"></div>
                  <div>
                    <img id="movie_popular"
                      src={"https://image.tmdb.org/t/p/w342/" + image_path}   style={{
                      // width:"14.375rem",
                      height:"21.563rem" 
                       }}
                      alt={original_title}
                      className="popular-movies-image-top"
                    />
                  <Link
                      to={`/movie/${tmdb_id}`}
                      className="frame"
                      title={original_title}
                    >
                      <span className="frame-title">{original_title}</span>
                      <span className="overlay"></span>
                    </Link>
                  </div>
             <div className="inner-card-controls">
               {watchedMovies.includes(tmdb_id) ? 
                // <button className="noHover" id={_id} style={{color:"rgb(81, 225, 30)"}}><i className="fa-fw far fa-eye" ></i></button>
                <i className={`fa-fw far fa-eye noHover ${tmdb_id}`} onClick={AddWatchedMovie} id={_id} style={{color:"rgb(81, 225, 30)"}}></i>
               : 
                <i className={`fa-fw far fa-eye ctrl-btn ${tmdb_id}`} onClick={AddWatchedMovie} id={_id} ></i>
              }

               

               {likedMovies?.includes(tmdb_id) ? 
                  // <button className="noHover" id={_id} style={{color:"orange"}}><i className="fa-fw fas fa-heart"></i></button>
                  <i className={`fa-fw fas fa-heart noHover ${tmdb_id}`} onClick={AddLikeMovie} id={_id} style={{color:"orange", margin:"0 13px 0 13px"}}></i>
                :
                  <i className={`fa-fw fas fa-heart ctrl-btn ${tmdb_id}`} onClick={AddLikeMovie} id={_id} style={{margin:"0 13px 0 13px"}}></i>
              }



              {watchlist.includes(tmdb_id) ?
                // <button className="noHover" id={_id} style={{color:"rgb(81, 87, 240)"}}><i className="fa-fw fas fa-clock"></i></button>
                <i className={`fa-fw fas fa-clock noHover ${tmdb_id}`} onClick={AddWatchlistMovie} id={_id} style={{color:"rgb(81, 87, 240)"}}></i>
              :
                <i className={`fa-fw fas fa-clock ctrl-btn ${tmdb_id}`} onClick={AddWatchlistMovie} id={_id} ></i>
              }
                              
                
                                
            </div>   
      </div>              
            ))}
            
        </div>
    </div>
    </div>
  );
};

export default PopularMoviesTop;
