import axios from 'axios';
import React, {useState, useEffect} from 'react';
import { useSelector } from 'react-redux';
import { Link, useParams } from 'react-router-dom';
import "./MoviesAll.css";

export default function MoviesAll() {
  const [state, setstate] = useState([]);
  const [genres, setGenres] = useState([]);
  const [header, setHeader] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const {genre} = useParams()
  const { language } = useSelector((state) => state.searchMovies);
  useEffect(() => {
    getGenres()
    if(genre==="popular"){
      getPopularMovies()
    } else {
      getGenreMovies()
    }
    
  }, [language,currentPage])

  useEffect(() => {
    const myHeader = genres?.filter(eachGenre=> {return eachGenre.id == genre ? eachGenre.name : ""})
    if(genre==="popular"){
      setHeader(genre)
    } else {
      setHeader(myHeader[0]?.name)
    }
    
  }, [genres,genre])

  const getGenreMovies = () => {
    let numbers = []
    for(let i = currentPage; i<currentPage+4; i++){
      numbers.push(i)
    }

    let promises = numbers.map(index => {
      return axios.get(`https://api.themoviedb.org/3/discover/movie?api_key=${process.env.REACT_APP_API_KEY}&language=${
        language.toLowerCase() + "-" + language}&page=${index}&with_genres=${genre}`)
        .then(res => {
          console.log(res.data)
          return res.data.results;
        })
    });

    Promise.all(promises)
      .then(results => {
        //console.log(results)
        let array = []
        results.map(list=>{return list.forEach(movie=>{return array.push(movie)})})
        //console.log(array)
        setstate(array)
      })
      .catch(e => {
        console.error(e);
      })
  }

  const getPopularMovies = () => {
    let numbers = []
    for(let i = currentPage; i<currentPage+4; i++){
      numbers.push(i)
    }

    let promises = numbers.map(index => {
      return axios.get(`https://api.themoviedb.org/3/movie/popular?api_key=${process.env.REACT_APP_API_KEY}&language=${
        language.toLowerCase() + "-" + language}&page=${index}`)
        .then(res => {
          console.log(res.data)
          return res.data.results;
        })
    });

    Promise.all(promises)
      .then(results => {
        //console.log(results)
        let array = []
        results.map(list=>{return list.forEach(movie=>{return array.push(movie)})})
        //console.log(array)
        setstate(array)
      })
      .catch(e => {
        console.error(e);
      })
  }

  const getGenres  = () => {
    axios.get(`https://api.themoviedb.org/3/genre/movie/list?api_key=${process.env.REACT_APP_API_KEY}&language=${
      language.toLowerCase() + "-" + language}`)
    .then(res=>{
      //console.log(res.data)
      setGenres(res.data.genres)
    })
    .catch(err=>console.log(err))
  }

  return (
      <>
      <div id="content" className="site-body">
        
        <div className="content-wrap">
      <section className="section col-24 col-main">	
      <div id="content-nav"> 
      <h2 className="section-heading">
        {header} Films
        </h2>
        
      {/* <div className="sorting-selects has-hide-toggle"> 
      <section className="grid-toggle-menu mob-hide"> 
      <ul>
        <li className="selected"><a href="/films/popular/this/week/size/small/" className="grid-toggle ir s grid-toggle-small" data-toggle="large">Small</a>
      </li>
      <li><a href="/films/popular/this/week/size/large/" className="grid-toggle ir s grid-toggle-large" data-toggle="small">Large</a>
      </li> 
      </ul>
      </section>
      <section className="smenu-wrapper hide-toggle-menu">
          <div className="smenu"> <label><span className="ir s hide-toggle-icon">Visibility Filters</span><i className="ir s icon"></i></label> 
        </div>
        </section> 
      <section className="smenu-wrapper"> <strong className="smenu-label">Sort by</strong>
        <div className="smenu"> <label>Film Popularity<i className="ir s icon"></i></label> 
        </div> </section> 
      <section className="smenu-wrapper"> 
      <div className="smenu"> <label>Service<i className="ir s icon"></i></label> 
      </div> 
      </section>
      <section className="smenu-wrapper">
          <div className="smenu"> <label> Genre<i className="ir s icon"></i> </label> 
        </div>
        </section>
        <section className="smenu-wrapper"> 
        <div className="smenu"> <label className="x"> Decade<i className="ir s icon"></i> </label> 
        </div>
          </section>
          </div> 
          <div className="clear">
            </div> */}

              </div>
        <div id="films-browser-list-container" data-url="/films/ajax/popular/this/week/size/small/">
        <section className="ui-block-header filtered-message body-text -small message-text">
          {/* <h2 className="ui-block-heading">
            There are 638,672&nbsp;films.
          </h2> */}
        </section>
          <ul className="poster-list-all-movies -p70 -grid">
          
          {state?.map(movie=>{
            return movie.poster_path !== null && <li className="listitem poster-container film-not-watched" key={movie.id}>
              <div className="react-component poster film-poster film-poster-493441 linked-film-poster removed-from-watchlist" data-film-id={movie.id} data-film-name={movie?.original_title} data-poster-url="/film/candyman-2021/image-150/" data-film-release-year="2021" data-new-list-with-film-action="/list/new/with/candyman-2021/" data-remove-from-watchlist-action="/film/candyman-2021/remove-from-watchlist/" data-add-to-watchlist-action="/film/candyman-2021/add-to-watchlist/" data-rate-action="/film/candyman-2021/rate/" data-mark-as-watched-action="/film/candyman-2021/mark-as-watched/" data-mark-as-not-watched-action="/film/candyman-2021/mark-as-not-watched/" data-film-link="/film/candyman-2021/" data-film-in-watchlist="false">
                <div><img src={`https://image.tmdb.org/t/p/w92/${movie?.poster_path}`} width="70" height="105" alt={movie?.original_title} srcSet={`https://image.tmdb.org/t/p/w92/${movie?.poster_path}`} className="image"/><Link to={`/movie/${movie.id}`} className="frame has-menu" data-original-title={movie?.original_title}><span className="frame-title">{movie?.original_title}</span><span className="overlay"></span></Link>
                </div>
                </div>

            </li>
          })}
          
            {/* <li className="listitem poster-container film-not-watched">
              <div className="react-component poster film-poster film-poster-93676 linked-film-poster removed-from-watchlist" data-component-className="globals.comps.FilmPosterComponent" data-film-id="93676" data-film-name="Guardians of the Galaxy" data-poster-url="/film/guardians-of-the-galaxy/image-150/" data-film-release-year="2014" data-new-list-with-film-action="/list/new/with/guardians-of-the-galaxy/" data-remove-from-watchlist-action="/film/guardians-of-the-galaxy/remove-from-watchlist/" data-add-to-watchlist-action="/film/guardians-of-the-galaxy/add-to-watchlist/" data-rate-action="/film/guardians-of-the-galaxy/rate/" data-mark-as-watched-action="/film/guardians-of-the-galaxy/mark-as-watched/" data-mark-as-not-watched-action="/film/guardians-of-the-galaxy/mark-as-not-watched/" data-film-link="/film/guardians-of-the-galaxy/" data-film-in-watchlist="false">
                <div><img src="https://a.ltrbxd.com/resized/film-poster/9/3/6/7/6/93676-guardians-of-the-galaxy-0-70-0-105-crop.jpg?k=b9ed22a1c6" width="70" height="105" alt="Guardians of the Galaxy" srcset="https://a.ltrbxd.com/resized/film-poster/9/3/6/7/6/93676-guardians-of-the-galaxy-0-140-0-210-crop.jpg?k=3030a7009c 2x" className="image"/><a href="/film/guardians-of-the-galaxy/" className="frame has-menu" data-original-title="Guardians of the Galaxy (2014)"><span className="frame-title">Guardians of the Galaxy (2014)</span><span className="overlay"></span><span className="overlay-actions js-film-options -w70" style={{display: "none"}}><span className="film-watch-link-target" data-film-id="93676"><span className="film-watch-link"><span className="has-icon icon-16 icon-watch ajax-click-action" data-action="/film/guardians-of-the-galaxy/mark-as-watched/"><span className="replace icon"></span>Seen this film?</span></span></span><span className="like-link-target" data-likeable-uid="film:93676"><span className="like-link"><span className="has-icon icon-16 ajax-click-action  icon-like" data-action="/s/film:93676/like/" data-recaptcha-action="film_like"><span className="icon"></span>Like this film?</span></span></span><span className="replace menu-link icon"></span></span></a>
                </div></div>

            </li>
            
            <li className="listitem poster-container film-not-watched">
              <div className="react-component poster film-poster film-poster-639559 linked-film-poster removed-from-watchlist" data-component-className="globals.comps.FilmPosterComponent" data-film-id="639559" data-film-name="Spencer" data-poster-url="/film/spencer-2021/image-150/" data-film-release-year="2021" data-new-list-with-film-action="/list/new/with/spencer-2021/" data-remove-from-watchlist-action="/film/spencer-2021/remove-from-watchlist/" data-add-to-watchlist-action="/film/spencer-2021/add-to-watchlist/" data-rate-action="/film/spencer-2021/rate/" data-mark-as-watched-action="/film/spencer-2021/mark-as-watched/" data-mark-as-not-watched-action="/film/spencer-2021/mark-as-not-watched/" data-film-link="/film/spencer-2021/" data-film-in-watchlist="false">
                <div><img src="https://a.ltrbxd.com/resized/film-poster/6/3/9/5/5/9/639559-spencer-0-70-0-105-crop.jpg?k=768f6d4103" width="70" height="105" alt="Spencer" srcset="https://a.ltrbxd.com/resized/film-poster/6/3/9/5/5/9/639559-spencer-0-140-0-210-crop.jpg?k=768f6d4103 2x" className="image"/>
                <a href="/film/spencer-2021/" 
                className="frame has-menu" data-original-title="Spencer (2021)">
                  <span className="frame-title">Spencer (2021)</span>
                  <span className="overlay"></span>
                  <span className="overlay-actions js-film-options -w70" style={{display: "none"}}>
                    <span className="film-watch-link-target" data-film-id="639559">
                      <span className="film-watch-link">
                    <span className="has-icon icon-16 icon-watch ajax-click-action" 
                    data-action="/film/spencer-2021/mark-as-watched/">
                      <span className="replace icon"></span>Seen this film?</span></span>
                  </span>
                  <span className="like-link-target" data-likeable-uid="film:639559">
                    <span className="like-link">
                    <span className="has-icon icon-16 ajax-click-action  icon-like" data-action="/s/film:639559/like/" data-recaptcha-action="film_like">
                      <span className="icon"></span>Like this film?</span></span></span>
                      <span className="replace menu-link icon"></span></span></a>
                </div>
                </div>
            </li>	*/}
        </ul>
        <div className="pagination" style={{display:"flex", justifyContent:"space-between"}}>
          <div className="paginate-nextprev">
            {currentPage !== 1 && <span className="previous" onClick={()=>{setCurrentPage(currentPage-4)}}>
            {"<--"} {language === "EN" && "Previous" || language === "TR" && "Önceki" || language === "DE" && "Vorherige"}
              </span>}
            
          </div> 
          <div className="paginate-nextprev">
            {currentPage !== state?.total_pages && <span className="next" onClick={()=>{setCurrentPage(currentPage+4)}}>
            {language === "EN" && "Next" || language === "TR" && "Sonraki" || language === "DE" && "Nächste"} {"-->"}
              </span>}
            
          </div> 
          </div>
      </div>	
        <div className="clear"></div>	
      </section>
          </div>     
        </div>   
      </>
    
  )
}
