import React,{useState, useEffect} from "react";
import "./popularMoviesBottom.css";
import SingleReview from "./SingleReview";
import data from "../../../data";
import axios from "axios";
import { useSelector } from "react-redux";
import { API_BASE }  from "../../../actions/api_base";

const PopularMoviesBottom = () => {

  const [state, setstate] = useState([])
  const [update, setUpdate] = useState(false)
  const [LikedComments, setLikedComemnts] = useState([])
  const { user } = useSelector((state) => state.auth);

  useEffect(() => {
    GetTheRecentComments()
    GetLikedComments()
  }, [update])

  const GetTheRecentComments=()=>{
    axios.get(`${API_BASE}comments`)
    .then(res=>{
      //console.log(res.data)
      setstate(res.data.response)
    })
    .catch(err=>console.log(err))
  }

  const GetLikedComments = () => {
    const array = []
    axios.get(`${API_BASE}users/${user.id}`)
    .then(res=>{
      //console.log(res.data.response[0].commentLikes)
      res.data.response[0].commentLikes.map(likes=>{
        return array.push(likes.commentId)
      })
      setLikedComemnts(array)
    })
    .catch(err=>console.log(err))
  }
  //console.log(LikedComments)
  return (
    <div className="">

     <header className="popular-top-movies-header under-line sub-menu">      
      <li className="menu-item iq-up-view-all "> 
       <p className="same-line" >POPULAR REVIEWS THIS WEEK</p>  </li>    
       {/* <li className="menu-item iq-up-view-all "><p>More</p>   </li>      */}
      </header>

      <main>
        {state?.map((movie, idx) => (
          movie.movieId.length !== 0 && <SingleReview key={idx} movie={movie} setUpdate={setUpdate} update={update} liked={LikedComments?.includes(movie._id)}/>
        ))}
      </main>
    </div>
  );
};

export default PopularMoviesBottom;
