import axios from "axios";
import React,{useState} from "react";
import { useSelector } from "react-redux";
import { Link } from "react-router-dom";
import "./SingleReviews.css";
import { API_BASE }  from "../../../actions/api_base";



const SingleReview = (props) => {
  const { user } = useSelector((state) => state.auth);
  let {
    movieId,
    userId,
    content,
    commentLikesCount,
    _id
  
  } = props.movie

  const [likes, setLikes] = useState(commentLikesCount)

  const ReviewLike = (e) => {
    console.log(user)
    
    
    axios.post(`${API_BASE}commentlikes`, {
      userId: user.id,
      commentId: e.target.id
    })
    .then(res=>{
      console.log(res.data)
      //console.log(e.target.className)
      if(res.data.message === "New commentlike is created successfully"){
        // e.target.classList.remove("notLiked")
        e.target.parentElement.classList.add("alreadyLiked")
        setLikes(likes + 1)
        props.setUpdate(!props.update)
      } else if (res.data.message === "Removed from commentlikes"){
        e.target.parentElement.classList.remove("alreadyLiked")
        setLikes(likes - 1);
        props.setUpdate(!props.update)
      }
    })
    .catch(err=>console.log(err))

  }
  //console.log(_id)
  return (
    <div className="single-review-container">
      <div className="single-review-image-container">
        <Link to={`/movie/${movieId[0].tmdb_id}`}>
        <img src={`https://image.tmdb.org/t/p/w154/${movieId[0]?.image_path}`} alt={movieId[0]?.original_title} className="single-review-image" />
        </Link>
        
      </div>
      <div className="single-review-context-container">
        <h5 className="headline-2 prettify">
          {movieId[0].original_title}{" "}
          {/* <small className="metadata">
            <a href="/films/year/2021/">{year}</a>
          </small> */}
        </h5>
        <Link
          className="avatar -a24"
          to={`/member-card/${userId[0]._id}`}
          data-original-title=""
        >
          {" "}
          <img
            src={userId[0].mediaId[0].url}
            alt={userId[0].firstname}
            width="24"
            height="24"
          />{" "}
        </Link>
        <h5 className="single-review-author">
          <p className="attribution">
            {" "}
            <strong className="name">
              <Link to={`/member-card/${userId[0]._id}`}>{userId[0].firstname}</Link>
            </strong>{" "}
            {/* <span className="rating -green rated-9"> ★★★★½ </span>{" "} */}
            {/* <span className="content-metadata"></span>{" "} */}
            {/* <i className="fas fa-comment"></i> 30 */}
          </p>
        </h5>
        <p className="summary">{content}</p>
        <span className={`single-review-likes ${props.liked ? "alreadyLiked" : ""}`}>
            <i className="fas fa-heart" id={_id} onClick={ReviewLike}></i>
            <span id={_id} onClick={ReviewLike}>{likes}</span>
            <span id={_id} onClick={ReviewLike}> likes</span>
        </span>
      </div>
    </div>
  );
};

export default SingleReview;
