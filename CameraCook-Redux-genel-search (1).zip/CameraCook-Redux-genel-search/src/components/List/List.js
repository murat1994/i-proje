import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Link } from "react-router-dom";
import "./List.css";
import SingleList from "./SingleList";

export default function List() {
  const dispatch = useDispatch();
  const { allLists } = useSelector((state) => state.allLists);

  return (
    <div>
      <div className="lists-page main-nav-lists logged-out">
        <div id="content-list" className="site-body-list">
          <div className="content-wrap">
            <h1 className="title-hero">
              <span className="mob-hide">Collect, curate, and share. </span>
              Lists are the perfect way to group films.
            </h1>
            <p className="create-your-own">
              <a href="/List/add-new-list" className="text-slug">
                Start your own list
              </a>
            </p>

            <section id="popular-lists" className="section list-set">
              <h2 className="section-heading under-line-1 -spaced listAll">
                <Link to="/list-all">Popular this week</Link>
              </h2>
              <Link to="/list-all" className="all-link">
                More
              </Link>
              {allLists
                ?.filter((movies) => movies.movieIds.length > 2)
                ?.map((list,index) => (
                  index < 3 && <SingleList key={list._id} {...list} />
                ))}
            </section>

            <section id="top-lists" className="section">
              <h2 className="section-heading -spaced">All-time lists</h2>
              <div className="list-grid-all-time1 -singlerow -twoup"></div>
            </section>
          </div>
        </div>
      </div>
    </div>
  );
}
