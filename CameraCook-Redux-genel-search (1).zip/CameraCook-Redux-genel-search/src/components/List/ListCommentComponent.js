import React, { useState, useEffect, useRef } from "react";
import { useSelector } from "react-redux";
import {useParams} from "react-router-dom"
import axios from "axios"
import { API_BASE }  from "../../actions/api_base";

const ListCommentComponent = (props,{ username }) => { 
  const commentRef = useRef()
  const commentBodyRef = useRef()
  const [comment, setComment] = useState("");
  const {id} = useParams()
  const { user } = useSelector(
    (state) => state?.auth
  );

  
  const postReview = () => {
    
    if(comment !== ""){
      axios.post(`${API_BASE}comments`, {
        userId: user?.id,
        listId: id,
        content: comment
      })
      .then(res=>{
        console.log(res.data)
        setComment("");
        props.GetAllComments()
        commentRef.current.style.display = "inline-block";
        commentBodyRef.current.style.border = "none"
        setTimeout(() => {
          commentRef.current.style.display = "none";
        }, 2000);
      })
      .catch(err=>console.log(err))
    } else {
      commentBodyRef.current.style.border = "2px red solid"
    }
  }
  // console.log(props)
  return (
    <form id="comment-form" className="col-12 col-right overflow">
      <fieldset>
        <div className="row-button">
          <textarea
            ref={commentBodyRef}
            name="commentBody"
            className="textarea"
            placeholder={`Reply as ${user.firstname}…`}
            value={comment}
            onChange={(e) => setComment(e.target.value)}
          ></textarea>
        </div>
        <div className="row-button -buttons">
          <button type="button" className="button -action right" onClick={postReview} >Submit</button>
          <span
                        ref={commentRef}
                        style={{
                          display: "none",
                          color: "#4DDC1A",
                          margin: "1% 3% 0 0",
                        }}
                      >
                        <b>Succesfully Added!</b>
                      </span>
          {/* <input type="submit"   /> */}
        </div>
      </fieldset>
    </form>
  );
};

export default ListCommentComponent;
