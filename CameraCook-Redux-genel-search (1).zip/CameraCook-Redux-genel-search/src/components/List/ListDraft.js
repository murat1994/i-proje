import React from "react";
import "./List.css";

export default function ListDraft() {
  return (
    <div>
      <div className="lists-page main-nav-lists logged-out">
        <div id="content" className="site-body">
          <div className="content-wrap">
            <h1 className="title-hero">
              <span className="mob-hide">Collect, curate, and share. </span>
              Lists are the perfect way to group films.
            </h1>
            <p className="create-your-own">
              <a href="/List/add-new-list" className="text-slug">
                Start your own list
              </a>
            </p>

            <section id="popular-lists" className="section list-set">
              <h2 className="section-heading -spaced">
                <a href="/lists/popular/this/week/">Popular this week</a>
              </h2>
              <a href="/lists/popular/this/week/" className="all-link">
                More
              </a>

              <section
                className="list -overlapped -stacked "
                data-film-list-id="18722885"
                data-person="okJosiah"
              >
                <a
                  href="/ListCard/"
                  className="list-link"
                >
                  <div className="list-link-stacked clear">
                    <ul className="poster-list -overlapped -p150">
                      <li
                        className="react-component poster film-poster film-poster-9952 listitem"
                        data-component-className="globals.comps.FilmPosterComponent"
                        data-film-id="9952"
                        data-film-name="The Gold of Naples"
                        data-poster-url="/film/the-gold-of-naples/image-150/"
                        data-film-release-year="1954"
                        data-new-list-with-film-action="/list/new/with/the-gold-of-naples/"
                        data-remove-from-watchlist-action="/film/the-gold-of-naples/remove-from-watchlist/"
                        data-add-to-watchlist-action="/film/the-gold-of-naples/add-to-watchlist/"
                        data-rate-action="/film/the-gold-of-naples/rate/"
                        data-mark-as-watched-action="/film/the-gold-of-naples/mark-as-watched/"
                        data-mark-as-not-watched-action="/film/the-gold-of-naples/mark-as-not-watched/"
                        data-film-link="/film/the-gold-of-naples/"
                      >
                        <div>
                          <img
                            src="https://a.ltrbxd.com/resized/film-poster/9/9/5/2/9952-the-gold-of-naples-0-150-0-225-crop.jpg?k=7ecb1b26ac"
                            width="150"
                            height="225"
                            alt="The Gold of Naples"
                            srcset="https://a.ltrbxd.com/resized/film-poster/9/9/5/2/9952-the-gold-of-naples-0-300-0-450-crop.jpg?k=83769ad9e4 2x"
                            className="image"
                          />
                          <span className="frame">
                            <span className="frame-title">
                              The Gold of Naples (1954)
                            </span>
                          </span>
                        </div>
                      </li>

                      <li
                        className="react-component poster film-poster film-poster-17157 listitem"
                        data-component-className="globals.comps.FilmPosterComponent"
                        data-film-id="17157"
                        data-film-name="Boudu Saved from Drowning"
                        data-poster-url="/film/boudu-saved-from-drowning/image-150/"
                        data-film-release-year="1932"
                        data-new-list-with-film-action="/list/new/with/boudu-saved-from-drowning/"
                        data-remove-from-watchlist-action="/film/boudu-saved-from-drowning/remove-from-watchlist/"
                        data-add-to-watchlist-action="/film/boudu-saved-from-drowning/add-to-watchlist/"
                        data-rate-action="/film/boudu-saved-from-drowning/rate/"
                        data-mark-as-watched-action="/film/boudu-saved-from-drowning/mark-as-watched/"
                        data-mark-as-not-watched-action="/film/boudu-saved-from-drowning/mark-as-not-watched/"
                        data-film-link="/film/boudu-saved-from-drowning/"
                      >
                        <div>
                          <img
                            src="https://a.ltrbxd.com/resized/film-poster/1/7/1/5/7/17157-boudu-saved-from-drowning-0-150-0-225-crop.jpg?k=d7ec00ee31"
                            width="150"
                            height="225"
                            alt="Boudu Saved from Drowning"
                            srcset="https://a.ltrbxd.com/resized/film-poster/1/7/1/5/7/17157-boudu-saved-from-drowning-0-300-0-450-crop.jpg?k=36b563bbff 2x"
                            className="image"
                          />
                          <span className="frame">
                            <span className="frame-title">
                              Boudu Saved from Drowning (1932)
                            </span>
                          </span>
                        </div>
                      </li>

                      <li
                        className="react-component poster film-poster film-poster-9952 listitem"
                        data-component-className="globals.comps.FilmPosterComponent"
                        data-film-id="9952"
                        data-film-name="The Gold of Naples"
                        data-poster-url="/film/the-gold-of-naples/image-150/"
                        data-film-release-year="1954"
                        data-new-list-with-film-action="/list/new/with/the-gold-of-naples/"
                        data-remove-from-watchlist-action="/film/the-gold-of-naples/remove-from-watchlist/"
                        data-add-to-watchlist-action="/film/the-gold-of-naples/add-to-watchlist/"
                        data-rate-action="/film/the-gold-of-naples/rate/"
                        data-mark-as-watched-action="/film/the-gold-of-naples/mark-as-watched/"
                        data-mark-as-not-watched-action="/film/the-gold-of-naples/mark-as-not-watched/"
                        data-film-link="/film/the-gold-of-naples/"
                      >
                        <div>
                          <img
                            src="https://a.ltrbxd.com/resized/film-poster/9/9/5/2/9952-the-gold-of-naples-0-150-0-225-crop.jpg?k=7ecb1b26ac"
                            width="150"
                            height="225"
                            alt="The Gold of Naples"
                            srcset="https://a.ltrbxd.com/resized/film-poster/9/9/5/2/9952-the-gold-of-naples-0-300-0-450-crop.jpg?k=83769ad9e4 2x"
                            className="image"
                          />
                          <span className="frame">
                            <span className="frame-title">
                              The Gold of Naples (1954)
                            </span>
                          </span>
                        </div>
                      </li>

                      <li
                        className="react-component poster film-poster film-poster-19477 listitem"
                        data-component-className="globals.comps.FilmPosterComponent"
                        data-film-id="19477"
                        data-film-name="The Lower Depths"
                        data-poster-url="/film/the-lower-depths/image-150/"
                        data-film-release-year="1936"
                        data-new-list-with-film-action="/list/new/with/the-lower-depths/"
                        data-remove-from-watchlist-action="/film/the-lower-depths/remove-from-watchlist/"
                        data-add-to-watchlist-action="/film/the-lower-depths/add-to-watchlist/"
                        data-rate-action="/film/the-lower-depths/rate/"
                        data-mark-as-watched-action="/film/the-lower-depths/mark-as-watched/"
                        data-mark-as-not-watched-action="/film/the-lower-depths/mark-as-not-watched/"
                        data-film-link="/film/the-lower-depths/"
                      >
                        <div>
                          <img
                            src="https://a.ltrbxd.com/resized/film-poster/1/9/4/7/7/19477-the-lower-depths-0-150-0-225-crop.jpg?k=bb22c699c8"
                            width="150"
                            height="225"
                            alt="The Lower Depths"
                            srcset="https://a.ltrbxd.com/resized/film-poster/1/9/4/7/7/19477-the-lower-depths-0-300-0-450-crop.jpg?k=69496aa679 2x"
                            className="image"
                          />
                          <span className="frame">
                            <span className="frame-title">
                              The Lower Depths (1936)
                            </span>
                          </span>
                        </div>
                      </li>

                      <li
                        className="react-component poster film-poster film-poster-16264 listitem"
                        data-component-className="globals.comps.FilmPosterComponent"
                        data-film-id="16264"
                        data-film-name="They Made Me a Fugitive"
                        data-poster-url="/film/they-made-me-a-fugitive/image-150/"
                        data-film-release-year="1947"
                        data-new-list-with-film-action="/list/new/with/they-made-me-a-fugitive/"
                        data-remove-from-watchlist-action="/film/they-made-me-a-fugitive/remove-from-watchlist/"
                        data-add-to-watchlist-action="/film/they-made-me-a-fugitive/add-to-watchlist/"
                        data-rate-action="/film/they-made-me-a-fugitive/rate/"
                        data-mark-as-watched-action="/film/they-made-me-a-fugitive/mark-as-watched/"
                        data-mark-as-not-watched-action="/film/they-made-me-a-fugitive/mark-as-not-watched/"
                        data-film-link="/film/they-made-me-a-fugitive/"
                      >
                        <div>
                          <img
                            src="https://a.ltrbxd.com/resized/film-poster/1/6/2/6/4/16264-they-made-me-a-fugitive-0-150-0-225-crop.jpg?k=44c45bad77"
                            width="150"
                            height="225"
                            alt="They Made Me a Fugitive"
                            srcset="https://a.ltrbxd.com/resized/film-poster/1/6/2/6/4/16264-they-made-me-a-fugitive-0-300-0-450-crop.jpg?k=f61aa20aaa 2x"
                            className="image"
                          />
                          <span className="frame">
                            <span className="frame-title">
                              They Made Me a Fugitive (1947)
                            </span>
                          </span>
                        </div>
                      </li>

                      <li
                        className="react-component poster film-poster film-poster-9952 listitem"
                        data-component-className="globals.comps.FilmPosterComponent"
                        data-film-id="9952"
                        data-film-name="The Gold of Naples"
                        data-poster-url="/film/the-gold-of-naples/image-150/"
                        data-film-release-year="1954"
                        data-new-list-with-film-action="/list/new/with/the-gold-of-naples/"
                        data-remove-from-watchlist-action="/film/the-gold-of-naples/remove-from-watchlist/"
                        data-add-to-watchlist-action="/film/the-gold-of-naples/add-to-watchlist/"
                        data-rate-action="/film/the-gold-of-naples/rate/"
                        data-mark-as-watched-action="/film/the-gold-of-naples/mark-as-watched/"
                        data-mark-as-not-watched-action="/film/the-gold-of-naples/mark-as-not-watched/"
                        data-film-link="/film/the-gold-of-naples/"
                      >
                        <div>
                          <img
                            src="https://a.ltrbxd.com/resized/film-poster/9/9/5/2/9952-the-gold-of-naples-0-150-0-225-crop.jpg?k=7ecb1b26ac"
                            width="150"
                            height="225"
                            alt="The Gold of Naples"
                            srcset="https://a.ltrbxd.com/resized/film-poster/9/9/5/2/9952-the-gold-of-naples-0-300-0-450-crop.jpg?k=83769ad9e4 2x"
                            className="image"
                          />
                          <span className="frame">
                            <span className="frame-title">
                              The Gold of Naples (1954)
                            </span>
                          </span>
                        </div>
                      </li>

                      <li
                        className="react-component poster film-poster film-poster-32590 listitem"
                        data-component-className="globals.comps.FilmPosterComponent"
                        data-film-id="32590"
                        data-film-name="City Streets"
                        data-poster-url="/film/city-streets/image-150/"
                        data-film-release-year="1931"
                        data-new-list-with-film-action="/list/new/with/city-streets/"
                        data-remove-from-watchlist-action="/film/city-streets/remove-from-watchlist/"
                        data-add-to-watchlist-action="/film/city-streets/add-to-watchlist/"
                        data-rate-action="/film/city-streets/rate/"
                        data-mark-as-watched-action="/film/city-streets/mark-as-watched/"
                        data-mark-as-not-watched-action="/film/city-streets/mark-as-not-watched/"
                        data-film-link="/film/city-streets/"
                      >
                        <div>
                          <img
                            src="https://a.ltrbxd.com/resized/film-poster/3/2/5/9/0/32590-city-streets-0-150-0-225-crop.jpg?k=60ebd78439"
                            width="150"
                            height="225"
                            alt="City Streets"
                            srcset="https://a.ltrbxd.com/resized/film-poster/3/2/5/9/0/32590-city-streets-0-300-0-450-crop.jpg?k=0259d535d4 2x"
                            className="image"
                          />
                          <span className="frame">
                            <span className="frame-title">
                              City Streets (1931)
                            </span>
                          </span>
                        </div>
                      </li>
                    </ul>
                  </div>
                  <span className="overlay"></span>
                </a>

                <h2 className="title-2 prettify">
                  <a href="/ListCard/">
                    Wes Anderson’s 32 Films to Watch Before The French Dispatch
                  </a>{" "}
                </h2>

                <div className="attribution-block">
                  <a
                    className="avatar -a16"
                    href="/okjosiah/"
                    data-original-title=""
                  >
                    <img
                      src="https://a.ltrbxd.com/resized/avatar/upload/1/5/0/0/6/4/0/shard/avtr-0-32-0-32-crop.jpg?k=b2b8993b64"
                      alt="josiah"
                      width="16"
                      height="16"
                    />{" "}
                  </a>
                  <p className="attribution">
                    <strong className="name">
                      <a href="/okjosiah/">josiah</a>
                    </strong>

                    <span className="content-metadata">
                      <a
                        href="/ListCard/"
                        className="has-icon icon-16 icon-like"
                      >
                        <span className="fas fa-heart"></span>{" "},077
                      </a>

                      <a
                        href="/ListCard"
                        className="has-icon icon-16 icon-comment"
                      >
                        <span className="fas fa-comment-alt"></span>{" "} 23
                      </a>
                    </span>
                  </p>
                </div>
              </section>

              <section
                className="list -overlapped -stacked "
                data-film-list-id="18399330"
                data-person="stephenage"
              >
                <a
                  href="/stephenage/list/anti-capitalist-anti-imperialist-and-anti/"
                  className="list-link"
                >
                  <div className="list-link-stacked clear">
                    <ul className="poster-list -overlapped -p150">
                      <li
                        className="react-component poster film-poster film-poster-97106 listitem"
                        data-component-className="globals.comps.FilmPosterComponent"
                        data-film-id="97106"
                        data-film-name="The Act of Killing"
                        data-poster-url="/film/the-act-of-killing/image-150/"
                        data-film-release-year="2012"
                        data-new-list-with-film-action="/list/new/with/the-act-of-killing/"
                        data-remove-from-watchlist-action="/film/the-act-of-killing/remove-from-watchlist/"
                        data-add-to-watchlist-action="/film/the-act-of-killing/add-to-watchlist/"
                        data-rate-action="/film/the-act-of-killing/rate/"
                        data-mark-as-watched-action="/film/the-act-of-killing/mark-as-watched/"
                        data-mark-as-not-watched-action="/film/the-act-of-killing/mark-as-not-watched/"
                        data-film-link="/film/the-act-of-killing/"
                      >
                        <div>
                          <img
                            src="https://a.ltrbxd.com/resized/sm/upload/kh/zg/3y/iv/the-act-of-killing-poster-0-150-0-225-crop.jpg?k=d9cbc5e9cc"
                            width="150"
                            height="225"
                            alt="The Act of Killing"
                            srcset="https://a.ltrbxd.com/resized/sm/upload/kh/zg/3y/iv/the-act-of-killing-poster-0-300-0-450-crop.jpg?k=9041b2c1b5 2x"
                            className="image"
                          />
                          <span className="frame">
                            <span className="frame-title">
                              The Act of Killing (2012)
                            </span>
                          </span>
                        </div>
                      </li>

                      <li
                        className="react-component poster film-poster film-poster-50612 listitem"
                        data-component-className="globals.comps.FilmPosterComponent"
                        data-film-id="50612"
                        data-film-name="Aguirre, the Wrath of God"
                        data-poster-url="/film/aguirre-the-wrath-of-god/image-150/"
                        data-film-release-year="1972"
                        data-new-list-with-film-action="/list/new/with/aguirre-the-wrath-of-god/"
                        data-remove-from-watchlist-action="/film/aguirre-the-wrath-of-god/remove-from-watchlist/"
                        data-add-to-watchlist-action="/film/aguirre-the-wrath-of-god/add-to-watchlist/"
                        data-rate-action="/film/aguirre-the-wrath-of-god/rate/"
                        data-mark-as-watched-action="/film/aguirre-the-wrath-of-god/mark-as-watched/"
                        data-mark-as-not-watched-action="/film/aguirre-the-wrath-of-god/mark-as-not-watched/"
                        data-film-link="/film/aguirre-the-wrath-of-god/"
                      >
                        <div>
                          <img
                            src="https://a.ltrbxd.com/resized/film-poster/5/0/6/1/2/50612-aguirre-the-wrath-of-god-0-150-0-225-crop.jpg?k=8c14401ef3"
                            width="150"
                            height="225"
                            alt="Aguirre, the Wrath of God"
                            srcset="https://a.ltrbxd.com/resized/film-poster/5/0/6/1/2/50612-aguirre-the-wrath-of-god-0-300-0-450-crop.jpg?k=81c420e480 2x"
                            className="image"
                          />
                          <span className="frame">
                            <span className="frame-title">
                              Aguirre, the Wrath of God (1972)
                            </span>
                          </span>
                        </div>
                      </li>

                      <li
                        className="react-component poster film-poster film-poster-51902 listitem"
                        data-component-className="globals.comps.FilmPosterComponent"
                        data-film-id="51902"
                        data-film-name="Akira"
                        data-poster-url="/film/akira/image-150/"
                        data-film-release-year="1988"
                        data-new-list-with-film-action="/list/new/with/akira/"
                        data-remove-from-watchlist-action="/film/akira/remove-from-watchlist/"
                        data-add-to-watchlist-action="/film/akira/add-to-watchlist/"
                        data-rate-action="/film/akira/rate/"
                        data-mark-as-watched-action="/film/akira/mark-as-watched/"
                        data-mark-as-not-watched-action="/film/akira/mark-as-not-watched/"
                        data-film-link="/film/akira/"
                      >
                        <div>
                          <img
                            src="https://a.ltrbxd.com/resized/sm/upload/xk/25/lu/0m/mi2Axov7Hy20wieoGfrbqDWLjSr-0-150-0-225-crop.jpg?k=a787a740df"
                            width="150"
                            height="225"
                            alt="Akira"
                            srcset="https://a.ltrbxd.com/resized/sm/upload/xk/25/lu/0m/mi2Axov7Hy20wieoGfrbqDWLjSr-0-300-0-450-crop.jpg?k=c1e119c29a 2x"
                            className="image"
                          />
                          <span className="frame">
                            <span className="frame-title">Akira (1988)</span>
                          </span>
                        </div>
                      </li>
                      <li
                        className="react-component poster film-poster film-poster-50612 listitem"
                        data-component-className="globals.comps.FilmPosterComponent"
                        data-film-id="50612"
                        data-film-name="Aguirre, the Wrath of God"
                        data-poster-url="/film/aguirre-the-wrath-of-god/image-150/"
                        data-film-release-year="1972"
                        data-new-list-with-film-action="/list/new/with/aguirre-the-wrath-of-god/"
                        data-remove-from-watchlist-action="/film/aguirre-the-wrath-of-god/remove-from-watchlist/"
                        data-add-to-watchlist-action="/film/aguirre-the-wrath-of-god/add-to-watchlist/"
                        data-rate-action="/film/aguirre-the-wrath-of-god/rate/"
                        data-mark-as-watched-action="/film/aguirre-the-wrath-of-god/mark-as-watched/"
                        data-mark-as-not-watched-action="/film/aguirre-the-wrath-of-god/mark-as-not-watched/"
                        data-film-link="/film/aguirre-the-wrath-of-god/"
                      >
                        <div>
                          <img
                            src="https://a.ltrbxd.com/resized/film-poster/5/0/6/1/2/50612-aguirre-the-wrath-of-god-0-150-0-225-crop.jpg?k=8c14401ef3"
                            width="150"
                            height="225"
                            alt="Aguirre, the Wrath of God"
                            srcset="https://a.ltrbxd.com/resized/film-poster/5/0/6/1/2/50612-aguirre-the-wrath-of-god-0-300-0-450-crop.jpg?k=81c420e480 2x"
                            className="image"
                          />
                          <span className="frame">
                            <span className="frame-title">
                              Aguirre, the Wrath of God (1972)
                            </span>
                          </span>
                        </div>
                      </li>
                      <li
                        className="react-component poster film-poster film-poster-51840 listitem"
                        data-component-className="globals.comps.FilmPosterComponent"
                        data-film-id="51840"
                        data-film-name="Ali: Fear Eats the Soul"
                        data-poster-url="/film/ali-fear-eats-the-soul/image-150/"
                        data-film-release-year="1974"
                        data-new-list-with-film-action="/list/new/with/ali-fear-eats-the-soul/"
                        data-remove-from-watchlist-action="/film/ali-fear-eats-the-soul/remove-from-watchlist/"
                        data-add-to-watchlist-action="/film/ali-fear-eats-the-soul/add-to-watchlist/"
                        data-rate-action="/film/ali-fear-eats-the-soul/rate/"
                        data-mark-as-watched-action="/film/ali-fear-eats-the-soul/mark-as-watched/"
                        data-mark-as-not-watched-action="/film/ali-fear-eats-the-soul/mark-as-not-watched/"
                        data-film-link="/film/ali-fear-eats-the-soul/"
                      >
                        <div>
                          <img
                            src="https://a.ltrbxd.com/resized/film-poster/5/1/8/4/0/51840-ali-fear-eats-the-soul-0-150-0-225-crop.jpg?k=57d51fda49"
                            width="150"
                            height="225"
                            alt="Ali: Fear Eats the Soul"
                            srcset="https://a.ltrbxd.com/resized/film-poster/5/1/8/4/0/51840-ali-fear-eats-the-soul-0-300-0-450-crop.jpg?k=75518e9be8 2x"
                            className="image"
                          />
                          <span className="frame">
                            <span className="frame-title">
                              Ali: Fear Eats the Soul (1974)
                            </span>
                          </span>
                        </div>
                      </li>
                      <li
                        className="react-component poster film-poster film-poster-50612 listitem"
                        data-component-className="globals.comps.FilmPosterComponent"
                        data-film-id="50612"
                        data-film-name="Aguirre, the Wrath of God"
                        data-poster-url="/film/aguirre-the-wrath-of-god/image-150/"
                        data-film-release-year="1972"
                        data-new-list-with-film-action="/list/new/with/aguirre-the-wrath-of-god/"
                        data-remove-from-watchlist-action="/film/aguirre-the-wrath-of-god/remove-from-watchlist/"
                        data-add-to-watchlist-action="/film/aguirre-the-wrath-of-god/add-to-watchlist/"
                        data-rate-action="/film/aguirre-the-wrath-of-god/rate/"
                        data-mark-as-watched-action="/film/aguirre-the-wrath-of-god/mark-as-watched/"
                        data-mark-as-not-watched-action="/film/aguirre-the-wrath-of-god/mark-as-not-watched/"
                        data-film-link="/film/aguirre-the-wrath-of-god/"
                      >
                        <div>
                          <img
                            src="https://a.ltrbxd.com/resized/film-poster/5/0/6/1/2/50612-aguirre-the-wrath-of-god-0-150-0-225-crop.jpg?k=8c14401ef3"
                            width="150"
                            height="225"
                            alt="Aguirre, the Wrath of God"
                            srcset="https://a.ltrbxd.com/resized/film-poster/5/0/6/1/2/50612-aguirre-the-wrath-of-god-0-300-0-450-crop.jpg?k=81c420e480 2x"
                            className="image"
                          />
                          <span className="frame">
                            <span className="frame-title">
                              Aguirre, the Wrath of God (1972)
                            </span>
                          </span>
                        </div>
                      </li>
                      <li
                        className="react-component poster film-poster film-poster-348772 listitem"
                        data-component-className="globals.comps.FilmPosterComponent"
                        data-film-id="348772"
                        data-film-name="Antiporno"
                        data-poster-url="/film/antiporno/image-150/"
                        data-film-release-year="2016"
                        data-new-list-with-film-action="/list/new/with/antiporno/"
                        data-remove-from-watchlist-action="/film/antiporno/remove-from-watchlist/"
                        data-add-to-watchlist-action="/film/antiporno/add-to-watchlist/"
                        data-rate-action="/film/antiporno/rate/"
                        data-mark-as-watched-action="/film/antiporno/mark-as-watched/"
                        data-mark-as-not-watched-action="/film/antiporno/mark-as-not-watched/"
                        data-film-link="/film/antiporno/"
                      >
                        <div>
                          <img
                            src="https://a.ltrbxd.com/resized/film-poster/3/4/8/7/7/2/348772-anti-porno-0-150-0-225-crop.jpg?k=7489fc6122"
                            width="150"
                            height="225"
                            alt="Antiporno"
                            srcset="https://a.ltrbxd.com/resized/film-poster/3/4/8/7/7/2/348772-anti-porno-0-300-0-450-crop.jpg?k=10b820f50d 2x"
                            className="image"
                          />
                          <span className="frame">
                            <span className="frame-title">
                              Antiporno (2016)
                            </span>
                          </span>
                        </div>
                      </li>
                    </ul>
                  </div>
                  <span className="overlay"></span>
                </a>

                <h2 className="title-2 prettify">
                  {" "}
                  <a href="/stephenage/list/anti-capitalist-anti-imperialist-and-anti/">
                    Anti-Capitalist, Anti-Imperialist and Anti-fascist ‘Canon’
                  </a>{" "}
                </h2>

                <div className="attribution-block">
                  <a
                    className="avatar -a16"
                    href="/stephenage/"
                    data-original-title=""
                  >
                    {" "}
                    <img
                      src="https://a.ltrbxd.com/resized/avatar/upload/1/4/6/1/6/9/6/shard/avtr-0-32-0-32-crop.jpg?k=b2333c97a3"
                      alt="Stephen Gillespie"
                      width="16"
                      height="16"
                    />{" "}
                  </a>

                  <p className="attribution">
                    <strong className="name">
                      <a href="/stephenage/">Stephen Gillespie</a>
                    </strong>

                    <span className="content-metadata">
                      <a
                        href="/stephenage/list/anti-capitalist-anti-imperialist-and-anti/likes/"
                        className="has-icon icon-16 icon-like"
                      >
                        <span className="icon"></span>8,930
                      </a>

                      <a
                        href="/stephenage/list/anti-capitalist-anti-imperialist-and-anti/#comments"
                        className="has-icon icon-16 icon-comment"
                      >
                        <span className="icon"></span>
                        673
                      </a>
                    </span>
                  </p>
                </div>
              </section>

              <section
                className="list -overlapped -stacked "
                data-film-list-id="18558972"
                data-person="Criterion"
              >
                <a
                  href="/criterion/list/films-to-watch-when-youre-questioning-love/"
                  className="list-link"
                >
                  <div className="list-link-stacked clear">
                    <ul className="poster-list -overlapped -p150">
                      <li
                        className="react-component poster film-poster film-poster-48800 listitem"
                        data-component-className="globals.comps.FilmPosterComponent"
                        data-film-id="48800"
                        data-film-name="Hiroshima Mon Amour"
                        data-poster-url="/film/hiroshima-mon-amour/image-150/"
                        data-film-release-year="1959"
                        data-new-list-with-film-action="/list/new/with/hiroshima-mon-amour/"
                        data-remove-from-watchlist-action="/film/hiroshima-mon-amour/remove-from-watchlist/"
                        data-add-to-watchlist-action="/film/hiroshima-mon-amour/add-to-watchlist/"
                        data-rate-action="/film/hiroshima-mon-amour/rate/"
                        data-mark-as-watched-action="/film/hiroshima-mon-amour/mark-as-watched/"
                        data-mark-as-not-watched-action="/film/hiroshima-mon-amour/mark-as-not-watched/"
                        data-film-link="/film/hiroshima-mon-amour/"
                      >
                        <div>
                          <img
                            src="https://a.ltrbxd.com/resized/sm/upload/d4/0z/wv/pr/xmW3o49z7iExUsren4R4QyN890H-0-150-0-225-crop.jpg?k=3f86139e69"
                            width="150"
                            height="225"
                            alt="Hiroshima Mon Amour"
                            srcset="https://a.ltrbxd.com/resized/sm/upload/d4/0z/wv/pr/xmW3o49z7iExUsren4R4QyN890H-0-300-0-450-crop.jpg?k=9d332f2ded 2x"
                            className="image"
                          />
                          <span className="frame">
                            <span className="frame-title">
                              Hiroshima Mon Amour (1959)
                            </span>
                          </span>
                        </div>
                      </li>

                      <li
                        className="react-component poster film-poster film-poster-17217 listitem"
                        data-component-className="globals.comps.FilmPosterComponent"
                        data-film-id="17217"
                        data-film-name="Certified Copy"
                        data-poster-url="/film/certified-copy/image-150/"
                        data-film-release-year="2010"
                        data-new-list-with-film-action="/list/new/with/certified-copy/"
                        data-remove-from-watchlist-action="/film/certified-copy/remove-from-watchlist/"
                        data-add-to-watchlist-action="/film/certified-copy/add-to-watchlist/"
                        data-rate-action="/film/certified-copy/rate/"
                        data-mark-as-watched-action="/film/certified-copy/mark-as-watched/"
                        data-mark-as-not-watched-action="/film/certified-copy/mark-as-not-watched/"
                        data-film-link="/film/certified-copy/"
                      >
                        <div>
                          <img
                            src="https://a.ltrbxd.com/resized/sm/upload/1s/rv/yf/4q/8f4gSxVxDk8A2UE0qOEjLAWljlb-0-150-0-225-crop.jpg?k=8b5e8483b6"
                            width="150"
                            height="225"
                            alt="Certified Copy"
                            srcset="https://a.ltrbxd.com/resized/sm/upload/1s/rv/yf/4q/8f4gSxVxDk8A2UE0qOEjLAWljlb-0-300-0-450-crop.jpg?k=9c623834de 2x"
                            className="image"
                          />
                          <span className="frame">
                            <span className="frame-title">
                              Certified Copy (2010)
                            </span>
                          </span>
                        </div>
                      </li>

                      <li
                        className="react-component poster film-poster film-poster-51309 listitem"
                        data-component-className="globals.comps.FilmPosterComponent"
                        data-film-id="51309"
                        data-film-name="In the Mood for Love"
                        data-poster-url="/film/in-the-mood-for-love/image-150/"
                        data-film-release-year="2000"
                        data-new-list-with-film-action="/list/new/with/in-the-mood-for-love/"
                        data-remove-from-watchlist-action="/film/in-the-mood-for-love/remove-from-watchlist/"
                        data-add-to-watchlist-action="/film/in-the-mood-for-love/add-to-watchlist/"
                        data-rate-action="/film/in-the-mood-for-love/rate/"
                        data-mark-as-watched-action="/film/in-the-mood-for-love/mark-as-watched/"
                        data-mark-as-not-watched-action="/film/in-the-mood-for-love/mark-as-not-watched/"
                        data-film-link="/film/in-the-mood-for-love/"
                      >
                        <div>
                          <img
                            src="https://a.ltrbxd.com/resized/sm/upload/g1/7l/2j/qk/tSRdvZY1waXrTeMqeLBmq9IRs08-0-150-0-225-crop.jpg?k=93919686e4"
                            width="150"
                            height="225"
                            alt="In the Mood for Love"
                            srcset="https://a.ltrbxd.com/resized/sm/upload/g1/7l/2j/qk/tSRdvZY1waXrTeMqeLBmq9IRs08-0-300-0-450-crop.jpg?k=768ba3989c 2x"
                            className="image"
                          />
                          <span className="frame">
                            <span className="frame-title">
                              In the Mood for Love (2000)
                            </span>
                          </span>
                        </div>
                      </li>

                      <li
                        className="react-component poster film-poster film-poster-198031 listitem"
                        data-component-className="globals.comps.FilmPosterComponent"
                        data-film-id="198031"
                        data-film-name="Losing Ground"
                        data-poster-url="/film/losing-ground/image-150/"
                        data-film-release-year="1982"
                        data-new-list-with-film-action="/list/new/with/losing-ground/"
                        data-remove-from-watchlist-action="/film/losing-ground/remove-from-watchlist/"
                        data-add-to-watchlist-action="/film/losing-ground/add-to-watchlist/"
                        data-rate-action="/film/losing-ground/rate/"
                        data-mark-as-watched-action="/film/losing-ground/mark-as-watched/"
                        data-mark-as-not-watched-action="/film/losing-ground/mark-as-not-watched/"
                        data-film-link="/film/losing-ground/"
                      >
                        <div>
                          <img
                            src="https://a.ltrbxd.com/resized/film-poster/1/9/8/0/3/1/198031-losing-ground-0-150-0-225-crop.jpg?k=02e1ea60d6"
                            width="150"
                            height="225"
                            alt="Losing Ground"
                            srcset="https://a.ltrbxd.com/resized/film-poster/1/9/8/0/3/1/198031-losing-ground-0-300-0-450-crop.jpg?k=8872b9a6e8 2x"
                            className="image"
                          />
                          <span className="frame">
                            <span className="frame-title">
                              Losing Ground (1982)
                            </span>
                          </span>
                        </div>
                      </li>

                      <li
                        className="react-component poster film-poster film-poster-14211 listitem"
                        data-component-className="globals.comps.FilmPosterComponent"
                        data-film-id="14211"
                        data-film-name="The Passionate Friends"
                        data-poster-url="/film/the-passionate-friends/image-150/"
                        data-film-release-year="1949"
                        data-new-list-with-film-action="/list/new/with/the-passionate-friends/"
                        data-remove-from-watchlist-action="/film/the-passionate-friends/remove-from-watchlist/"
                        data-add-to-watchlist-action="/film/the-passionate-friends/add-to-watchlist/"
                        data-rate-action="/film/the-passionate-friends/rate/"
                        data-mark-as-watched-action="/film/the-passionate-friends/mark-as-watched/"
                        data-mark-as-not-watched-action="/film/the-passionate-friends/mark-as-not-watched/"
                        data-film-link="/film/the-passionate-friends/"
                      >
                        <div>
                          <img
                            src="https://a.ltrbxd.com/resized/film-poster/1/4/2/1/1/14211-the-passionate-friends-0-150-0-225-crop.jpg?k=d6e9020908"
                            width="150"
                            height="225"
                            alt="The Passionate Friends"
                            srcset="https://a.ltrbxd.com/resized/film-poster/1/4/2/1/1/14211-the-passionate-friends-0-300-0-450-crop.jpg?k=0d29115d81 2x"
                            className="image"
                          />
                          <span className="frame">
                            <span className="frame-title">
                              The Passionate Friends (1949)
                            </span>
                          </span>
                        </div>
                      </li>
                    </ul>
                  </div>
                  <span className="overlay"></span>
                </a>

                <h2 className="title-2 prettify">
                  {" "}
                  <a href="/criterion/list/films-to-watch-when-youre-questioning-love/">
                    Films to Watch When You’re Questioning Love | Criterion
                    Channel
                  </a>{" "}
                </h2>

                <div className="attribution-block">
                  <a
                    className="avatar -a16"
                    href="/criterion/"
                    data-original-title=""
                  >
                    {" "}
                    <img
                      src="https://a.ltrbxd.com/resized/avatar/upload/2/8/0/0/1/1/9/shard/avtr-0-32-0-32-crop.jpg?k=df99712dea"
                      alt="Criterion"
                      width="16"
                      height="16"
                    />{" "}
                  </a>

                  <p className="attribution">
                    <strong className="name">
                      <a href="/criterion/">Criterion</a>
                    </strong>

                    <span className="content-metadata">
                      <a
                        href="/criterion/list/films-to-watch-when-youre-questioning-love/likes/"
                        className="has-icon icon-16 icon-like"
                      >
                        <span className="icon"></span>3,469
                      </a>

                      <a
                        href="/criterion/list/films-to-watch-when-youre-questioning-love/#comments"
                        className="has-icon icon-16 icon-comment"
                      >
                        <span className="icon"></span>
                        39
                      </a>
                    </span>
                  </p>
                </div>
              </section>
            </section>
            <div className="cols-3">
              <div className="col-16">
                <section
                  id="recently-liked-lists"
                  className="section list-set list-set-narrow"
                  data-url="/csi/most-recently-liked-lists/"
                  data-how-many="16"
                >
                  <h2 className="section-heading">Recently liked</h2>

                  <section
                    className="list -overlapped -summary "
                    data-film-list-id="18923654"
                    data-person="multiversees"
                  >
                    <a
                      href="/multiversees/list/vote-best-crime-narrative-features/"
                      className="list-link"
                    >
                      {" "}
                      <ul className="poster-list -p70 -overlapped">
                        {" "}
                        <li
                          className="react-component poster film-poster film-poster-51383 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="51383"
                          data-film-name="GoodFellas"
                          data-poster-url="/film/goodfellas/image-150/"
                          data-film-release-year="1990"
                          data-new-list-with-film-action="/list/new/with/goodfellas/"
                          data-remove-from-watchlist-action="/film/goodfellas/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/goodfellas/add-to-watchlist/"
                          data-rate-action="/film/goodfellas/rate/"
                          data-mark-as-watched-action="/film/goodfellas/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/goodfellas/mark-as-not-watched/"
                          data-film-link="/film/goodfellas/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/film-poster/5/1/3/8/3/51383-goodfellas-0-70-0-105-crop.jpg?k=721446f084"
                              width="70"
                              height="105"
                              alt="GoodFellas"
                              srcset="https://a.ltrbxd.com/resized/film-poster/5/1/3/8/3/51383-goodfellas-0-140-0-210-crop.jpg?k=721446f084 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                GoodFellas (1990)
                              </span>
                            </span>
                          </div>
                        </li>{" "}
                        <li
                          className="react-component poster film-poster film-poster-51896 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="51896"
                          data-film-name="The Dark Knight"
                          data-poster-url="/film/the-dark-knight/image-150/"
                          data-film-release-year="2008"
                          data-new-list-with-film-action="/list/new/with/the-dark-knight/"
                          data-remove-from-watchlist-action="/film/the-dark-knight/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/the-dark-knight/add-to-watchlist/"
                          data-rate-action="/film/the-dark-knight/rate/"
                          data-mark-as-watched-action="/film/the-dark-knight/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/the-dark-knight/mark-as-not-watched/"
                          data-film-link="/film/the-dark-knight/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/sm/upload/78/y5/zg/ej/oefdD26aey8GPdx7Rm45PNncJdU-0-70-0-105-crop.jpg?k=e9b979d6ad"
                              width="70"
                              height="105"
                              alt="The Dark Knight"
                              srcset="https://a.ltrbxd.com/resized/sm/upload/78/y5/zg/ej/oefdD26aey8GPdx7Rm45PNncJdU-0-140-0-210-crop.jpg?k=ec4170f408 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                The Dark Knight (2008)
                              </span>
                            </span>
                          </div>
                        </li>{" "}
                        <li
                          className="react-component poster film-poster film-poster-51444 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="51444"
                          data-film-name="Pulp Fiction"
                          data-poster-url="/film/pulp-fiction/image-150/"
                          data-film-release-year="1994"
                          data-new-list-with-film-action="/list/new/with/pulp-fiction/"
                          data-remove-from-watchlist-action="/film/pulp-fiction/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/pulp-fiction/add-to-watchlist/"
                          data-rate-action="/film/pulp-fiction/rate/"
                          data-mark-as-watched-action="/film/pulp-fiction/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/pulp-fiction/mark-as-not-watched/"
                          data-film-link="/film/pulp-fiction/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/film-poster/5/1/4/4/4/51444-pulp-fiction-0-70-0-105-crop.jpg?k=2929cc4796"
                              width="70"
                              height="105"
                              alt="Pulp Fiction"
                              srcset="https://a.ltrbxd.com/resized/film-poster/5/1/4/4/4/51444-pulp-fiction-0-140-0-210-crop.jpg?k=759e9d9116 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                Pulp Fiction (1994)
                              </span>
                            </span>
                          </div>
                        </li>{" "}
                        <li
                          className="react-component poster film-poster film-poster-51778 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="51778"
                          data-film-name="The Shawshank Redemption"
                          data-poster-url="/film/the-shawshank-redemption/image-150/"
                          data-film-release-year="1994"
                          data-new-list-with-film-action="/list/new/with/the-shawshank-redemption/"
                          data-remove-from-watchlist-action="/film/the-shawshank-redemption/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/the-shawshank-redemption/add-to-watchlist/"
                          data-rate-action="/film/the-shawshank-redemption/rate/"
                          data-mark-as-watched-action="/film/the-shawshank-redemption/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/the-shawshank-redemption/mark-as-not-watched/"
                          data-film-link="/film/the-shawshank-redemption/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/sm/upload/7l/hn/46/uz/zGINvGjdlO6TJRu9wESQvWlOKVT-0-70-0-105-crop.jpg?k=5168630f79"
                              width="70"
                              height="105"
                              alt="The Shawshank Redemption"
                              srcset="https://a.ltrbxd.com/resized/sm/upload/7l/hn/46/uz/zGINvGjdlO6TJRu9wESQvWlOKVT-0-140-0-210-crop.jpg?k=7ea5c507e9 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                The Shawshank Redemption (1994)
                              </span>
                            </span>
                          </div>
                        </li>{" "}
                        <li
                          className="react-component poster film-poster film-poster-51818 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="51818"
                          data-film-name="The Godfather"
                          data-poster-url="/film/the-godfather/image-150/"
                          data-film-release-year="1972"
                          data-new-list-with-film-action="/list/new/with/the-godfather/"
                          data-remove-from-watchlist-action="/film/the-godfather/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/the-godfather/add-to-watchlist/"
                          data-rate-action="/film/the-godfather/rate/"
                          data-mark-as-watched-action="/film/the-godfather/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/the-godfather/mark-as-not-watched/"
                          data-film-link="/film/the-godfather/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/film-poster/5/1/8/1/8/51818-the-godfather-0-70-0-105-crop.jpg?k=2454993409"
                              width="70"
                              height="105"
                              alt="The Godfather"
                              srcset="https://a.ltrbxd.com/resized/film-poster/5/1/8/1/8/51818-the-godfather-0-140-0-210-crop.jpg?k=4459fa02b7 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                The Godfather (1972)
                              </span>
                            </span>
                          </div>
                        </li>{" "}
                      </ul>{" "}
                      <span className="overlay"></span>{" "}
                    </a>
                    <div className="film-list-summary">
                      {" "}
                      <h2 className="title-2 prettify">
                        {" "}
                        <a href="/multiversees/list/vote-best-crime-narrative-features/">
                          VOTE: Best Crime Narrative Features
                        </a>{" "}
                      </h2>
                      <div className="attribution-block">
                        {" "}
                        <a
                          className="avatar -a16"
                          href="/multiversees/"
                          data-original-title=""
                        >
                          {" "}
                          <img
                            src="https://a.ltrbxd.com/resized/avatar/upload/2/4/3/6/6/2/9/shard/avtr-0-32-0-32-crop.jpg?k=915e46c311"
                            alt="Multiverse of Film"
                            width="16"
                            height="16"
                          />{" "}
                        </a>{" "}
                        <p className="attribution">
                          {" "}
                          <strong className="name">
                            <a href="/multiversees/">Multiverse of Film</a>
                          </strong>{" "}
                          <small className="value">45&nbsp;films</small>{" "}
                          <span className="content-metadata">
                            {" "}
                            <a
                              href="/multiversees/list/vote-best-crime-narrative-features/likes/"
                              className="has-icon icon-16 icon-like"
                            >
                              <span className="icon"></span>11
                            </a>{" "}
                            <a
                              href="/multiversees/list/vote-best-crime-narrative-features/#comments"
                              className="has-icon icon-16 icon-comment"
                            >
                              <span className="icon"></span> 98{" "}
                            </a>{" "}
                          </span>{" "}
                        </p>
                      </div>{" "}
                      <div
                        className="body-text -prose"
                        data-more="/multiversees/list/vote-best-crime-narrative-features/"
                      >
                        {" "}
                        <p>
                          - your <b>FIRST</b> choice will give the film{" "}
                          <b>THREE</b> points. - your <b>SECOND</b> choice will
                          give the film <b>TWO</b> points.…
                        </p>
                      </div>{" "}
                    </div>
                  </section>

                  <section
                    className="list -overlapped -summary "
                    data-film-list-id="2562518"
                    data-person="mlkarasek"
                  >
                    <a
                      href="/mlkarasek/list/sofia-coppolas-favorite-films/"
                      className="list-link"
                    >
                      {" "}
                      <ul className="poster-list -p70 -overlapped">
                        {" "}
                        <li
                          className="react-component poster film-poster film-poster-51787 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="51787"
                          data-film-name="Breathless"
                          data-poster-url="/film/breathless/image-150/"
                          data-film-release-year="1960"
                          data-new-list-with-film-action="/list/new/with/breathless/"
                          data-remove-from-watchlist-action="/film/breathless/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/breathless/add-to-watchlist/"
                          data-rate-action="/film/breathless/rate/"
                          data-mark-as-watched-action="/film/breathless/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/breathless/mark-as-not-watched/"
                          data-film-link="/film/breathless/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/film-poster/5/1/7/8/7/51787-breathless-0-70-0-105-crop.jpg?k=e5465ac3a4"
                              width="70"
                              height="105"
                              alt="Breathless"
                              srcset="https://a.ltrbxd.com/resized/film-poster/5/1/7/8/7/51787-breathless-0-140-0-210-crop.jpg?k=03271d0ea9 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                Breathless (1960)
                              </span>
                            </span>
                          </div>
                        </li>{" "}
                        <li
                          className="react-component poster film-poster film-poster-42565 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="42565"
                          data-film-name="Sixteen Candles"
                          data-poster-url="/film/sixteen-candles/image-150/"
                          data-film-release-year="1984"
                          data-new-list-with-film-action="/list/new/with/sixteen-candles/"
                          data-remove-from-watchlist-action="/film/sixteen-candles/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/sixteen-candles/add-to-watchlist/"
                          data-rate-action="/film/sixteen-candles/rate/"
                          data-mark-as-watched-action="/film/sixteen-candles/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/sixteen-candles/mark-as-not-watched/"
                          data-film-link="/film/sixteen-candles/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/film-poster/4/2/5/6/5/42565-sixteen-candles-0-70-0-105-crop.jpg?k=d6e1814dbb"
                              width="70"
                              height="105"
                              alt="Sixteen Candles"
                              srcset="https://a.ltrbxd.com/resized/film-poster/4/2/5/6/5/42565-sixteen-candles-0-140-0-210-crop.jpg?k=11adbc02ca 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                Sixteen Candles (1984)
                              </span>
                            </span>
                          </div>
                        </li>{" "}
                        <li
                          className="react-component poster film-poster film-poster-51350 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="51350"
                          data-film-name="Lolita"
                          data-poster-url="/film/lolita/image-150/"
                          data-film-release-year="1962"
                          data-new-list-with-film-action="/list/new/with/lolita/"
                          data-remove-from-watchlist-action="/film/lolita/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/lolita/add-to-watchlist/"
                          data-rate-action="/film/lolita/rate/"
                          data-mark-as-watched-action="/film/lolita/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/lolita/mark-as-not-watched/"
                          data-film-link="/film/lolita/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/film-poster/5/1/3/5/0/51350-lolita-0-70-0-105-crop.jpg?k=4569c523cc"
                              width="70"
                              height="105"
                              alt="Lolita"
                              srcset="https://a.ltrbxd.com/resized/film-poster/5/1/3/5/0/51350-lolita-0-140-0-210-crop.jpg?k=919cbe0912 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">Lolita (1962)</span>
                            </span>
                          </div>
                        </li>{" "}
                        <li
                          className="react-component poster film-poster film-poster-51824 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="51824"
                          data-film-name="Rumble Fish"
                          data-poster-url="/film/rumble-fish/image-150/"
                          data-film-release-year="1983"
                          data-new-list-with-film-action="/list/new/with/rumble-fish/"
                          data-remove-from-watchlist-action="/film/rumble-fish/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/rumble-fish/add-to-watchlist/"
                          data-rate-action="/film/rumble-fish/rate/"
                          data-mark-as-watched-action="/film/rumble-fish/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/rumble-fish/mark-as-not-watched/"
                          data-film-link="/film/rumble-fish/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/film-poster/5/1/8/2/4/51824-rumble-fish-0-70-0-105-crop.jpg?k=bbb6bfabbe"
                              width="70"
                              height="105"
                              alt="Rumble Fish"
                              srcset="https://a.ltrbxd.com/resized/film-poster/5/1/8/2/4/51824-rumble-fish-0-140-0-210-crop.jpg?k=27f9a2914a 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                Rumble Fish (1983)
                              </span>
                            </span>
                          </div>
                        </li>{" "}
                        <li
                          className="react-component poster film-poster film-poster-36222 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="36222"
                          data-film-name="The Last Picture Show"
                          data-poster-url="/film/the-last-picture-show/image-150/"
                          data-film-release-year="1971"
                          data-new-list-with-film-action="/list/new/with/the-last-picture-show/"
                          data-remove-from-watchlist-action="/film/the-last-picture-show/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/the-last-picture-show/add-to-watchlist/"
                          data-rate-action="/film/the-last-picture-show/rate/"
                          data-mark-as-watched-action="/film/the-last-picture-show/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/the-last-picture-show/mark-as-not-watched/"
                          data-film-link="/film/the-last-picture-show/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/film-poster/3/6/2/2/2/36222-the-last-picture-show-0-70-0-105-crop.jpg?k=0a7edbc7d7"
                              width="70"
                              height="105"
                              alt="The Last Picture Show"
                              srcset="https://a.ltrbxd.com/resized/film-poster/3/6/2/2/2/36222-the-last-picture-show-0-140-0-210-crop.jpg?k=9248f5447e 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                The Last Picture Show (1971)
                              </span>
                            </span>
                          </div>
                        </li>{" "}
                      </ul>{" "}
                      <span className="overlay"></span>{" "}
                    </a>
                    <div className="film-list-summary">
                      {" "}
                      <h2 className="title-2 prettify">
                        {" "}
                        <a href="/mlkarasek/list/sofia-coppolas-favorite-films/">
                          SOFIA COPPOLA'S FAVORITE FILMS
                        </a>{" "}
                      </h2>
                      <div className="attribution-block">
                        {" "}
                        <a
                          className="avatar -a16"
                          href="/mlkarasek/"
                          data-original-title=""
                        >
                          {" "}
                          <img
                            src="https://a.ltrbxd.com/resized/avatar/twitter/7/0/8/3/9/3/shard/http___pbs.twimg.com_profile_images_840336177249030146_FOyL8H8s-0-32-0-32-crop.jpg?k=0ee245e185"
                            alt="Monica"
                            width="16"
                            height="16"
                          />{" "}
                        </a>{" "}
                        <p className="attribution">
                          {" "}
                          <strong className="name">
                            <a href="/mlkarasek/">Monica</a>
                          </strong>{" "}
                          <small className="value">22&nbsp;films</small>{" "}
                          <span className="content-metadata">
                            {" "}
                            <a
                              href="/mlkarasek/list/sofia-coppolas-favorite-films/likes/"
                              className="has-icon icon-16 icon-like"
                            >
                              <span className="icon"></span>303
                            </a>{" "}
                            <a
                              href="/mlkarasek/list/sofia-coppolas-favorite-films/#comments"
                              className="has-icon icon-16 icon-comment"
                            >
                              <span className="icon"></span> 2{" "}
                            </a>{" "}
                          </span>{" "}
                        </p>
                      </div>
                      <div
                        className="body-text -prose"
                        data-more="/mlkarasek/list/sofia-coppolas-favorite-films/"
                      >
                        {" "}
                        <p>
                          Source: New York Times, Six Directors Pick Their
                          Favorite Films of the 21st-Century, written by Melena
                          Ryzik, June 9, 2017…
                        </p>
                      </div>
                    </div>
                  </section>

                  <section
                    className="list -overlapped -summary "
                    data-film-list-id="44313"
                    data-person="peterstanley"
                  >
                    <a
                      href="/peterstanley/list/1001-movies-you-must-see-before-you-die/"
                      className="list-link"
                    >
                      {" "}
                      <ul className="poster-list -p70 -overlapped">
                        {" "}
                        <li
                          className="react-component poster film-poster film-poster-51377 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="51377"
                          data-film-name="A Trip to the Moon"
                          data-poster-url="/film/a-trip-to-the-moon/image-150/"
                          data-film-release-year="1902"
                          data-new-list-with-film-action="/list/new/with/a-trip-to-the-moon/"
                          data-remove-from-watchlist-action="/film/a-trip-to-the-moon/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/a-trip-to-the-moon/add-to-watchlist/"
                          data-rate-action="/film/a-trip-to-the-moon/rate/"
                          data-mark-as-watched-action="/film/a-trip-to-the-moon/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/a-trip-to-the-moon/mark-as-not-watched/"
                          data-film-link="/film/a-trip-to-the-moon/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/film-poster/5/1/3/7/7/51377-a-trip-to-the-moon-0-70-0-105-crop.jpg?k=49d97eaa8e"
                              width="70"
                              height="105"
                              alt="A Trip to the Moon"
                              srcset="https://a.ltrbxd.com/resized/film-poster/5/1/3/7/7/51377-a-trip-to-the-moon-0-140-0-210-crop.jpg?k=c236168a1b 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                A Trip to the Moon (1902)
                              </span>
                            </span>
                          </div>
                        </li>{" "}
                        <li
                          className="react-component poster film-poster film-poster-48719 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="48719"
                          data-film-name="The Great Train Robbery"
                          data-poster-url="/film/the-great-train-robbery/image-150/"
                          data-film-release-year="1903"
                          data-new-list-with-film-action="/list/new/with/the-great-train-robbery/"
                          data-remove-from-watchlist-action="/film/the-great-train-robbery/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/the-great-train-robbery/add-to-watchlist/"
                          data-rate-action="/film/the-great-train-robbery/rate/"
                          data-mark-as-watched-action="/film/the-great-train-robbery/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/the-great-train-robbery/mark-as-not-watched/"
                          data-film-link="/film/the-great-train-robbery/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/film-poster/4/8/7/1/9/48719-the-great-train-robbery-0-70-0-105-crop.jpg?k=42ee502e3a"
                              width="70"
                              height="105"
                              alt="The Great Train Robbery"
                              srcset="https://a.ltrbxd.com/resized/film-poster/4/8/7/1/9/48719-the-great-train-robbery-0-140-0-210-crop.jpg?k=42ee502e3a 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                The Great Train Robbery (1903)
                              </span>
                            </span>
                          </div>
                        </li>{" "}
                        <li
                          className="react-component poster film-poster film-poster-51505 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="51505"
                          data-film-name="The Birth of a Nation"
                          data-poster-url="/film/the-birth-of-a-nation/image-150/"
                          data-film-release-year="1915"
                          data-new-list-with-film-action="/list/new/with/the-birth-of-a-nation/"
                          data-remove-from-watchlist-action="/film/the-birth-of-a-nation/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/the-birth-of-a-nation/add-to-watchlist/"
                          data-rate-action="/film/the-birth-of-a-nation/rate/"
                          data-mark-as-watched-action="/film/the-birth-of-a-nation/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/the-birth-of-a-nation/mark-as-not-watched/"
                          data-film-link="/film/the-birth-of-a-nation/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/sm/upload/7m/96/27/ps/pNpOXpQI5GSUfiWypubYtMh9928-0-70-0-105-crop.jpg?k=5636476a9d"
                              width="70"
                              height="105"
                              alt="The Birth of a Nation"
                              srcset="https://a.ltrbxd.com/resized/sm/upload/7m/96/27/ps/pNpOXpQI5GSUfiWypubYtMh9928-0-140-0-210-crop.jpg?k=ff81182b63 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                The Birth of a Nation (1915)
                              </span>
                            </span>
                          </div>
                        </li>{" "}
                        <li
                          className="react-component poster film-poster film-poster-33155 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="33155"
                          data-film-name="Les Vampires"
                          data-poster-url="/film/les-vampires/image-150/"
                          data-film-release-year="1915"
                          data-new-list-with-film-action="/list/new/with/les-vampires/"
                          data-remove-from-watchlist-action="/film/les-vampires/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/les-vampires/add-to-watchlist/"
                          data-rate-action="/film/les-vampires/rate/"
                          data-mark-as-watched-action="/film/les-vampires/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/les-vampires/mark-as-not-watched/"
                          data-film-link="/film/les-vampires/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/sm/upload/5g/a9/8u/i2/tv4o4wQOyehsJo612eiV9DJgGpz-0-70-0-105-crop.jpg?k=95cf3f9367"
                              width="70"
                              height="105"
                              alt="Les Vampires"
                              srcset="https://a.ltrbxd.com/resized/sm/upload/5g/a9/8u/i2/tv4o4wQOyehsJo612eiV9DJgGpz-0-140-0-210-crop.jpg?k=95cf3f9367 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                Les Vampires (1915)
                              </span>
                            </span>
                          </div>
                        </li>{" "}
                        <li
                          className="react-component poster film-poster film-poster-49912 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="49912"
                          data-film-name="Intolerance: Love's Struggle Throughout the Ages"
                          data-poster-url="/film/intolerance-loves-struggle-throughout-the-ages/image-150/"
                          data-film-release-year="1916"
                          data-new-list-with-film-action="/list/new/with/intolerance-loves-struggle-throughout-the-ages/"
                          data-remove-from-watchlist-action="/film/intolerance-loves-struggle-throughout-the-ages/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/intolerance-loves-struggle-throughout-the-ages/add-to-watchlist/"
                          data-rate-action="/film/intolerance-loves-struggle-throughout-the-ages/rate/"
                          data-mark-as-watched-action="/film/intolerance-loves-struggle-throughout-the-ages/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/intolerance-loves-struggle-throughout-the-ages/mark-as-not-watched/"
                          data-film-link="/film/intolerance-loves-struggle-throughout-the-ages/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/sm/upload/jf/np/en/p4/pnUj8htRLf53aNuFV5vkiWRCrfn-0-70-0-105-crop.jpg?k=66dbe2c395"
                              width="70"
                              height="105"
                              alt="Intolerance: Love's Struggle Throughout the Ages"
                              srcset="https://a.ltrbxd.com/resized/sm/upload/jf/np/en/p4/pnUj8htRLf53aNuFV5vkiWRCrfn-0-140-0-210-crop.jpg?k=46a829be6e 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                Intolerance: Love's Struggle Throughout the Ages
                                (1916)
                              </span>
                            </span>
                          </div>
                        </li>{" "}
                      </ul>{" "}
                      <span className="overlay"></span>{" "}
                    </a>
                    <div className="film-list-summary">
                      {" "}
                      <h2 className="title-2 prettify">
                        {" "}
                        <a href="/peterstanley/list/1001-movies-you-must-see-before-you-die/">
                          1001 Movies You Must See Before You Die
                        </a>{" "}
                      </h2>
                      <div className="attribution-block">
                        {" "}
                        <a
                          className="avatar -a16"
                          href="/peterstanley/"
                          data-original-title=""
                        >
                          {" "}
                          <img
                            src="https://secure.gravatar.com/avatar/71ec1069f65e1afb3782fdb15960969e?rating=PG&amp;size=32&amp;border=&amp;default=https%3A%2F%2Fs.ltrbxd.com%2Fstatic%2Fimg%2Favatar32.09445e73.png"
                            alt="Peter Stanley"
                            width="16"
                            height="16"
                          />{" "}
                        </a>{" "}
                        <p className="attribution">
                          {" "}
                          <strong className="name">
                            <a href="/peterstanley/">Peter Stanley</a>
                          </strong>{" "}
                          <small className="value">1,235&nbsp;films</small>{" "}
                          <span className="content-metadata">
                            {" "}
                            <a
                              href="/peterstanley/list/1001-movies-you-must-see-before-you-die/likes/"
                              className="has-icon icon-16 icon-like"
                            >
                              <span className="icon"></span>58,845
                            </a>{" "}
                            <a
                              href="/peterstanley/list/1001-movies-you-must-see-before-you-die/#comments"
                              className="has-icon icon-16 icon-comment"
                            >
                              <span className="icon"></span> 1535{" "}
                            </a>{" "}
                          </span>{" "}
                        </p>
                      </div>{" "}
                      <div
                        className="body-text -prose"
                        data-more="/peterstanley/list/1001-movies-you-must-see-before-you-die/"
                      >
                        {" "}
                        <p>
                          All the films from all the editions, including those
                          subsequently removed, presently totalling 1235. An
                          easy way of seeing how…
                        </p>
                      </div>{" "}
                    </div>
                  </section>

                  <section
                    className="list -overlapped -summary "
                    data-film-list-id="16123667"
                    data-person="jcgabriel"
                  >
                    <a
                      href="/jcgabriel/list/criterion-challenge-2021/"
                      className="list-link"
                    >
                      {" "}
                      <ul className="poster-list -p70 -overlapped">
                        {" "}
                        <li
                          className="react-component poster film-poster film-poster-51469 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="51469"
                          data-film-name="Paris, Texas"
                          data-poster-url="/film/paris-texas/image-150/"
                          data-film-release-year="1984"
                          data-new-list-with-film-action="/list/new/with/paris-texas/"
                          data-remove-from-watchlist-action="/film/paris-texas/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/paris-texas/add-to-watchlist/"
                          data-rate-action="/film/paris-texas/rate/"
                          data-mark-as-watched-action="/film/paris-texas/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/paris-texas/mark-as-not-watched/"
                          data-film-link="/film/paris-texas/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/film-poster/5/1/4/6/9/51469-paris-texas-0-70-0-105-crop.jpg?k=727ac982c8"
                              width="70"
                              height="105"
                              alt="Paris, Texas"
                              srcset="https://a.ltrbxd.com/resized/film-poster/5/1/4/6/9/51469-paris-texas-0-140-0-210-crop.jpg?k=84b0cc9949 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                Paris, Texas (1984)
                              </span>
                            </span>
                          </div>
                        </li>{" "}
                        <li
                          className="react-component poster film-poster film-poster-44542 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="44542"
                          data-film-name="High and Low"
                          data-poster-url="/film/high-and-low/image-150/"
                          data-film-release-year="1963"
                          data-new-list-with-film-action="/list/new/with/high-and-low/"
                          data-remove-from-watchlist-action="/film/high-and-low/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/high-and-low/add-to-watchlist/"
                          data-rate-action="/film/high-and-low/rate/"
                          data-mark-as-watched-action="/film/high-and-low/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/high-and-low/mark-as-not-watched/"
                          data-film-link="/film/high-and-low/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/sm/upload/do/zm/ur/ug/dgnyE40yWdI7gbaHmmB5yCCIVpI-0-70-0-105-crop.jpg?k=7ddd677abf"
                              width="70"
                              height="105"
                              alt="High and Low"
                              srcset="https://a.ltrbxd.com/resized/sm/upload/do/zm/ur/ug/dgnyE40yWdI7gbaHmmB5yCCIVpI-0-140-0-210-crop.jpg?k=61c81470b4 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                High and Low (1963)
                              </span>
                            </span>
                          </div>
                        </li>{" "}
                        <li
                          className="react-component poster film-poster film-poster-51787 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="51787"
                          data-film-name="Breathless"
                          data-poster-url="/film/breathless/image-150/"
                          data-film-release-year="1960"
                          data-new-list-with-film-action="/list/new/with/breathless/"
                          data-remove-from-watchlist-action="/film/breathless/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/breathless/add-to-watchlist/"
                          data-rate-action="/film/breathless/rate/"
                          data-mark-as-watched-action="/film/breathless/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/breathless/mark-as-not-watched/"
                          data-film-link="/film/breathless/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/film-poster/5/1/7/8/7/51787-breathless-0-70-0-105-crop.jpg?k=e5465ac3a4"
                              width="70"
                              height="105"
                              alt="Breathless"
                              srcset="https://a.ltrbxd.com/resized/film-poster/5/1/7/8/7/51787-breathless-0-140-0-210-crop.jpg?k=03271d0ea9 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                Breathless (1960)
                              </span>
                            </span>
                          </div>
                        </li>{" "}
                        <li
                          className="react-component poster film-poster film-poster-51347 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="51347"
                          data-film-name="Rosemary's Baby"
                          data-poster-url="/film/rosemarys-baby/image-150/"
                          data-film-release-year="1968"
                          data-new-list-with-film-action="/list/new/with/rosemarys-baby/"
                          data-remove-from-watchlist-action="/film/rosemarys-baby/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/rosemarys-baby/add-to-watchlist/"
                          data-rate-action="/film/rosemarys-baby/rate/"
                          data-mark-as-watched-action="/film/rosemarys-baby/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/rosemarys-baby/mark-as-not-watched/"
                          data-film-link="/film/rosemarys-baby/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/sm/upload/ea/vc/su/y2/fdLOXB8AysEGRL44I1RvoKiWDcW-0-70-0-105-crop.jpg?k=5577bda96e"
                              width="70"
                              height="105"
                              alt="Rosemary's Baby"
                              srcset="https://a.ltrbxd.com/resized/sm/upload/ea/vc/su/y2/fdLOXB8AysEGRL44I1RvoKiWDcW-0-140-0-210-crop.jpg?k=6d01fc7c10 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                Rosemary's Baby (1968)
                              </span>
                            </span>
                          </div>
                        </li>{" "}
                        <li
                          className="react-component poster film-poster film-poster-2702 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="2702"
                          data-film-name="Citizen Kane"
                          data-poster-url="/film/citizen-kane/image-150/"
                          data-film-release-year="1941"
                          data-new-list-with-film-action="/list/new/with/citizen-kane/"
                          data-remove-from-watchlist-action="/film/citizen-kane/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/citizen-kane/add-to-watchlist/"
                          data-rate-action="/film/citizen-kane/rate/"
                          data-mark-as-watched-action="/film/citizen-kane/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/citizen-kane/mark-as-not-watched/"
                          data-film-link="/film/citizen-kane/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/film-poster/2/7/0/2/2702-citizen-kane-0-70-0-105-crop.jpg?k=3dcd28fed2"
                              width="70"
                              height="105"
                              alt="Citizen Kane"
                              srcset="https://a.ltrbxd.com/resized/film-poster/2/7/0/2/2702-citizen-kane-0-140-0-210-crop.jpg?k=1aa9cd9de8 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                Citizen Kane (1941)
                              </span>
                            </span>
                          </div>
                        </li>{" "}
                      </ul>{" "}
                      <span className="overlay"></span>{" "}
                    </a>
                    <div className="film-list-summary">
                      {" "}
                      <h2 className="title-2 prettify">
                        {" "}
                        <a href="/jcgabriel/list/criterion-challenge-2021/">
                          Criterion Challenge 2021
                        </a>{" "}
                      </h2>
                      <div className="attribution-block">
                        {" "}
                        <a
                          className="avatar -a16"
                          href="/jcgabriel/"
                          data-original-title=""
                        >
                          <img
                            src="https://a.ltrbxd.com/resized/avatar/twitter/1/9/7/8/9/7/0/shard/http___pbs.twimg.com_profile_images_1227884884041093120_qa2dspMC-0-32-0-32-crop.jpg?k=2b24b1151e"
                            alt="João Gabriel"
                            width="16"
                            height="16"
                          />{" "}
                        </a>{" "}
                        <p className="attribution">
                          {" "}
                          <strong className="name">
                            <a href="/jcgabriel/">João Gabriel</a>
                          </strong>{" "}
                          <small className="value">17&nbsp;films</small>{" "}
                          <span className="content-metadata">
                            {" "}
                            <a
                              href="/jcgabriel/list/criterion-challenge-2021/likes/"
                              className="has-icon icon-16 icon-like"
                            >
                              <span className="icon"></span>2
                            </a>{" "}
                          </span>{" "}
                        </p>
                      </div>{" "}
                      <div
                        className="body-text -prose"
                        data-more="/jcgabriel/list/criterion-challenge-2021/"
                      >
                        {" "}
                        <p>
                          Welcome to the first annual "The Criterion Challenge"
                          where we celebrate The Criterion Collection. There are
                          52 categories - one…
                        </p>
                      </div>{" "}
                    </div>
                  </section>

                  <section
                    className="list -overlapped -summary "
                    data-film-list-id="345176"
                    data-person="hamburgersplash"
                  >
                    <a
                      href="/hamburgersplash/list/weirdo-watchlist/"
                      className="list-link"
                    >
                      {" "}
                      <ul className="poster-list -p70 -overlapped">
                        {" "}
                        <li
                          className="react-component poster film-poster film-poster-524405 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="524405"
                          data-film-name="Tux and Fanny"
                          data-poster-url="/film/tux-and-fanny/image-150/"
                          data-film-release-year="2019"
                          data-new-list-with-film-action="/list/new/with/tux-and-fanny/"
                          data-remove-from-watchlist-action="/film/tux-and-fanny/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/tux-and-fanny/add-to-watchlist/"
                          data-rate-action="/film/tux-and-fanny/rate/"
                          data-mark-as-watched-action="/film/tux-and-fanny/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/tux-and-fanny/mark-as-not-watched/"
                          data-film-link="/film/tux-and-fanny/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/film-poster/5/2/4/4/0/5/524405-tux-and-fanny-0-70-0-105-crop.jpg?k=85da5f4add"
                              width="70"
                              height="105"
                              alt="Tux and Fanny"
                              srcset="https://a.ltrbxd.com/resized/film-poster/5/2/4/4/0/5/524405-tux-and-fanny-0-140-0-210-crop.jpg?k=9793d3e19f 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                Tux and Fanny (2019)
                              </span>
                            </span>
                          </div>
                        </li>{" "}
                        <li
                          className="react-component poster film-poster film-poster-12002 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="12002"
                          data-film-name="The Visitor"
                          data-poster-url="/film/the-visitor-1979/image-150/"
                          data-film-release-year="1979"
                          data-new-list-with-film-action="/list/new/with/the-visitor-1979/"
                          data-remove-from-watchlist-action="/film/the-visitor-1979/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/the-visitor-1979/add-to-watchlist/"
                          data-rate-action="/film/the-visitor-1979/rate/"
                          data-mark-as-watched-action="/film/the-visitor-1979/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/the-visitor-1979/mark-as-not-watched/"
                          data-film-link="/film/the-visitor-1979/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/sm/upload/gc/az/le/k3/tv45081UZKcFmXGbdFRLaOTcRHo-0-70-0-105-crop.jpg?k=9ce97e52bc"
                              width="70"
                              height="105"
                              alt="The Visitor"
                              srcset="https://a.ltrbxd.com/resized/sm/upload/gc/az/le/k3/tv45081UZKcFmXGbdFRLaOTcRHo-0-140-0-210-crop.jpg?k=e2daafec04 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                The Visitor (1979)
                              </span>
                            </span>
                          </div>
                        </li>{" "}
                        <li
                          className="react-component poster film-poster film-poster-476042 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="476042"
                          data-film-name="Greener Grass"
                          data-poster-url="/film/greener-grass-2019/image-150/"
                          data-film-release-year="2019"
                          data-new-list-with-film-action="/list/new/with/greener-grass-2019/"
                          data-remove-from-watchlist-action="/film/greener-grass-2019/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/greener-grass-2019/add-to-watchlist/"
                          data-rate-action="/film/greener-grass-2019/rate/"
                          data-mark-as-watched-action="/film/greener-grass-2019/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/greener-grass-2019/mark-as-not-watched/"
                          data-film-link="/film/greener-grass-2019/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/film-poster/4/7/6/0/4/2/476042-greener-grass-0-70-0-105-crop.jpg?k=e1f73fcf14"
                              width="70"
                              height="105"
                              alt="Greener Grass"
                              srcset="https://a.ltrbxd.com/resized/film-poster/4/7/6/0/4/2/476042-greener-grass-0-140-0-210-crop.jpg?k=4294e48c1f 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                Greener Grass (2019)
                              </span>
                            </span>
                          </div>
                        </li>{" "}
                        <li
                          className="react-component poster film-poster film-poster-302919 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="302919"
                          data-film-name="The Flying Luna Clipper"
                          data-poster-url="/film/the-flying-luna-clipper/image-150/"
                          data-film-release-year="1987"
                          data-new-list-with-film-action="/list/new/with/the-flying-luna-clipper/"
                          data-remove-from-watchlist-action="/film/the-flying-luna-clipper/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/the-flying-luna-clipper/add-to-watchlist/"
                          data-rate-action="/film/the-flying-luna-clipper/rate/"
                          data-mark-as-watched-action="/film/the-flying-luna-clipper/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/the-flying-luna-clipper/mark-as-not-watched/"
                          data-film-link="/film/the-flying-luna-clipper/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/film-poster/3/0/2/9/1/9/302919-the-flying-luna-clipper-0-70-0-105-crop.jpg?k=3c3b1997b7"
                              width="70"
                              height="105"
                              alt="The Flying Luna Clipper"
                              srcset="https://a.ltrbxd.com/resized/film-poster/3/0/2/9/1/9/302919-the-flying-luna-clipper-0-140-0-210-crop.jpg?k=3c3b1997b7 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                The Flying Luna Clipper (1987)
                              </span>
                            </span>
                          </div>
                        </li>{" "}
                        <li
                          className="react-component poster film-poster film-poster-38248 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="38248"
                          data-film-name="Mind Game"
                          data-poster-url="/film/mind-game/image-150/"
                          data-film-release-year="2004"
                          data-new-list-with-film-action="/list/new/with/mind-game/"
                          data-remove-from-watchlist-action="/film/mind-game/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/mind-game/add-to-watchlist/"
                          data-rate-action="/film/mind-game/rate/"
                          data-mark-as-watched-action="/film/mind-game/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/mind-game/mark-as-not-watched/"
                          data-film-link="/film/mind-game/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/film-poster/3/8/2/4/8/38248-mind-game-0-70-0-105-crop.jpg?k=8a1d0ec8d4"
                              width="70"
                              height="105"
                              alt="Mind Game"
                              srcset="https://a.ltrbxd.com/resized/film-poster/3/8/2/4/8/38248-mind-game-0-140-0-210-crop.jpg?k=989e9c2fe9 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                Mind Game (2004)
                              </span>
                            </span>
                          </div>
                        </li>{" "}
                      </ul>{" "}
                      <span className="overlay"></span>{" "}
                    </a>
                    <div className="film-list-summary">
                      {" "}
                      <h2 className="title-2 prettify">
                        {" "}
                        <a href="/hamburgersplash/list/weirdo-watchlist/">
                          Weirdo Watchlist
                        </a>{" "}
                      </h2>
                      <div className="attribution-block">
                        {" "}
                        <a
                          className="avatar -a16"
                          href="/hamburgersplash/"
                          data-original-title=""
                        >
                          {" "}
                          <img
                            src="https://a.ltrbxd.com/resized/avatar/upload/6/3/3/0/5/shard/avtr-0-32-0-32-crop.jpg?k=8f45cb6746"
                            alt="Tyler Wallace"
                            width="16"
                            height="16"
                          />{" "}
                        </a>{" "}
                        <p className="attribution">
                          {" "}
                          <strong className="name">
                            <a href="/hamburgersplash/">Tyler Wallace</a>
                          </strong>{" "}
                          <small className="value">1,768&nbsp;films</small>{" "}
                          <span className="content-metadata">
                            {" "}
                            <a
                              href="/hamburgersplash/list/weirdo-watchlist/likes/"
                              className="has-icon icon-16 icon-like"
                            >
                              <span className="icon"></span>22,856
                            </a>{" "}
                            <a
                              href="/hamburgersplash/list/weirdo-watchlist/#comments"
                              className="has-icon icon-16 icon-comment"
                            >
                              <span className="icon"></span> 98{" "}
                            </a>{" "}
                          </span>{" "}
                        </p>
                      </div>{" "}
                      <div className="body-text -prose">
                        {" "}
                        <p>Movies that are slightly off.</p>
                      </div>{" "}
                    </div>
                  </section>

                  <section
                    className="list -overlapped -summary "
                    data-film-list-id="5480541"
                    data-person="mgAmber"
                  >
                    <a
                      href="/mgamber/list/ari-asters-favorite-films/"
                      className="list-link"
                    >
                      {" "}
                      <ul className="poster-list -p70 -overlapped">
                        {" "}
                        <li
                          className="react-component poster film-poster film-poster-29368 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="29368"
                          data-film-name="Songs from the Second Floor"
                          data-poster-url="/film/songs-from-the-second-floor/image-150/"
                          data-film-release-year="2000"
                          data-new-list-with-film-action="/list/new/with/songs-from-the-second-floor/"
                          data-remove-from-watchlist-action="/film/songs-from-the-second-floor/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/songs-from-the-second-floor/add-to-watchlist/"
                          data-rate-action="/film/songs-from-the-second-floor/rate/"
                          data-mark-as-watched-action="/film/songs-from-the-second-floor/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/songs-from-the-second-floor/mark-as-not-watched/"
                          data-film-link="/film/songs-from-the-second-floor/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/sm/upload/vf/f8/qt/by/vBNHPEVXMeDmhRiqTW17TTEkX62-0-70-0-105-crop.jpg?k=e003793848"
                              width="70"
                              height="105"
                              alt="Songs from the Second Floor"
                              srcset="https://a.ltrbxd.com/resized/sm/upload/vf/f8/qt/by/vBNHPEVXMeDmhRiqTW17TTEkX62-0-140-0-210-crop.jpg?k=4b18d9206b 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                Songs from the Second Floor (2000)
                              </span>
                            </span>
                          </div>
                        </li>{" "}
                        <li
                          className="react-component poster film-poster film-poster-50598 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="50598"
                          data-film-name="Secret Sunshine"
                          data-poster-url="/film/secret-sunshine/image-150/"
                          data-film-release-year="2007"
                          data-new-list-with-film-action="/list/new/with/secret-sunshine/"
                          data-remove-from-watchlist-action="/film/secret-sunshine/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/secret-sunshine/add-to-watchlist/"
                          data-rate-action="/film/secret-sunshine/rate/"
                          data-mark-as-watched-action="/film/secret-sunshine/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/secret-sunshine/mark-as-not-watched/"
                          data-film-link="/film/secret-sunshine/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/film-poster/5/0/5/9/8/50598-secret-sunshine-0-70-0-105-crop.jpg?k=aebb45717f"
                              width="70"
                              height="105"
                              alt="Secret Sunshine"
                              srcset="https://a.ltrbxd.com/resized/film-poster/5/0/5/9/8/50598-secret-sunshine-0-140-0-210-crop.jpg?k=661bcd5da3 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                Secret Sunshine (2007)
                              </span>
                            </span>
                          </div>
                        </li>{" "}
                        <li
                          className="react-component poster film-poster film-poster-47527 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="47527"
                          data-film-name="The Headless Woman"
                          data-poster-url="/film/the-headless-woman/image-150/"
                          data-film-release-year="2008"
                          data-new-list-with-film-action="/list/new/with/the-headless-woman/"
                          data-remove-from-watchlist-action="/film/the-headless-woman/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/the-headless-woman/add-to-watchlist/"
                          data-rate-action="/film/the-headless-woman/rate/"
                          data-mark-as-watched-action="/film/the-headless-woman/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/the-headless-woman/mark-as-not-watched/"
                          data-film-link="/film/the-headless-woman/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/film-poster/4/7/5/2/7/47527-the-headless-woman-0-70-0-105-crop.jpg?k=2be03db87b"
                              width="70"
                              height="105"
                              alt="The Headless Woman"
                              srcset="https://a.ltrbxd.com/resized/film-poster/4/7/5/2/7/47527-the-headless-woman-0-140-0-210-crop.jpg?k=d5ba8544ca 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                The Headless Woman (2008)
                              </span>
                            </span>
                          </div>
                        </li>{" "}
                        <li
                          className="react-component poster film-poster film-poster-44466 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="44466"
                          data-film-name="A Serious Man"
                          data-poster-url="/film/a-serious-man/image-150/"
                          data-film-release-year="2009"
                          data-new-list-with-film-action="/list/new/with/a-serious-man/"
                          data-remove-from-watchlist-action="/film/a-serious-man/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/a-serious-man/add-to-watchlist/"
                          data-rate-action="/film/a-serious-man/rate/"
                          data-mark-as-watched-action="/film/a-serious-man/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/a-serious-man/mark-as-not-watched/"
                          data-film-link="/film/a-serious-man/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/sm/upload/2u/48/o1/04/kCl9WXR7LOqDTEU3XUX8ssUETQR-0-70-0-105-crop.jpg?k=648c7e9c44"
                              width="70"
                              height="105"
                              alt="A Serious Man"
                              srcset="https://a.ltrbxd.com/resized/sm/upload/2u/48/o1/04/kCl9WXR7LOqDTEU3XUX8ssUETQR-0-140-0-210-crop.jpg?k=94a8fa470d 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                A Serious Man (2009)
                              </span>
                            </span>
                          </div>
                        </li>{" "}
                        <li
                          className="react-component poster film-poster film-poster-52504 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="52504"
                          data-film-name="Silence"
                          data-poster-url="/film/silence/image-150/"
                          data-film-release-year="2016"
                          data-new-list-with-film-action="/list/new/with/silence/"
                          data-remove-from-watchlist-action="/film/silence/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/silence/add-to-watchlist/"
                          data-rate-action="/film/silence/rate/"
                          data-mark-as-watched-action="/film/silence/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/silence/mark-as-not-watched/"
                          data-film-link="/film/silence/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/film-poster/5/2/5/0/4/52504-silence-0-70-0-105-crop.jpg?k=7d8451bf81"
                              width="70"
                              height="105"
                              alt="Silence"
                              srcset="https://a.ltrbxd.com/resized/film-poster/5/2/5/0/4/52504-silence-0-140-0-210-crop.jpg?k=615677073a 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                Silence (2016)
                              </span>
                            </span>
                          </div>
                        </li>{" "}
                      </ul>{" "}
                      <span className="overlay"></span>{" "}
                    </a>
                    <div className="film-list-summary">
                      {" "}
                      <h2 className="title-2 prettify">
                        {" "}
                        <a href="/mgamber/list/ari-asters-favorite-films/">
                          Ari Aster’s favorite films from contemporary directors
                        </a>{" "}
                      </h2>
                      <div className="attribution-block">
                        {" "}
                        <a
                          className="avatar -a16"
                          href="/mgamber/"
                          data-original-title=""
                        >
                          {" "}
                          <img
                            src="https://secure.gravatar.com/avatar/bd4febf71fa72b1050682760f43b7708?rating=PG&amp;size=32&amp;border=&amp;default=https%3A%2F%2Fs.ltrbxd.com%2Fstatic%2Fimg%2Favatar32.09445e73.png"
                            alt="Amber Mitchell"
                            width="16"
                            height="16"
                          />{" "}
                        </a>{" "}
                        <p className="attribution">
                          {" "}
                          <strong className="name">
                            <a href="/mgamber/">Amber Mitchell</a>
                          </strong>{" "}
                          <small className="value">61&nbsp;films</small>{" "}
                          <span className="content-metadata">
                            {" "}
                            <a
                              href="/mgamber/list/ari-asters-favorite-films/likes/"
                              className="has-icon icon-16 icon-like"
                            >
                              <span className="icon"></span>736
                            </a>{" "}
                            <a
                              href="/mgamber/list/ari-asters-favorite-films/#comments"
                              className="has-icon icon-16 icon-comment"
                            >
                              <span className="icon"></span> 14{" "}
                            </a>{" "}
                          </span>{" "}
                        </p>
                      </div>{" "}
                      <div
                        className="body-text -prose"
                        data-more="/mgamber/list/ari-asters-favorite-films/"
                      >
                        {" "}
                        <p>
                          Per a question posed to Ari Aster in his{" "}
                          <a
                            href="https://www.reddit.com/r/movies/comments/cbxc8v/hi_im_ari_aster_writerdirector_of_midsommar_ama/"
                            rel="nofollow"
                          >
                            Reddit AMA
                          </a>{" "}
                          by u/0achBCR, “Who are some of your favorite
                          contemporary…
                        </p>
                      </div>{" "}
                    </div>
                  </section>

                  <section
                    className="list -overlapped -summary "
                    data-film-list-id="60923"
                    data-person="pileofcrowns"
                  >
                    <a
                      href="/pileofcrowns/list/harvard-film-phd-program-narrative-films/"
                      className="list-link"
                    >
                      {" "}
                      <ul className="poster-list -p70 -overlapped">
                        {" "}
                        <li
                          className="react-component poster film-poster film-poster-51891 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="51891"
                          data-film-name="The Arrival of a Train at La Ciotat"
                          data-poster-url="/film/the-arrival-of-a-train-at-la-ciotat/image-150/"
                          data-film-release-year="1896"
                          data-new-list-with-film-action="/list/new/with/the-arrival-of-a-train-at-la-ciotat/"
                          data-remove-from-watchlist-action="/film/the-arrival-of-a-train-at-la-ciotat/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/the-arrival-of-a-train-at-la-ciotat/add-to-watchlist/"
                          data-rate-action="/film/the-arrival-of-a-train-at-la-ciotat/rate/"
                          data-mark-as-watched-action="/film/the-arrival-of-a-train-at-la-ciotat/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/the-arrival-of-a-train-at-la-ciotat/mark-as-not-watched/"
                          data-film-link="/film/the-arrival-of-a-train-at-la-ciotat/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/sm/upload/99/ok/ww/39/iwxu3OVTNVy4wAQ8JbwsxYEW5Qr-0-70-0-105-crop.jpg?k=e94a50309d"
                              width="70"
                              height="105"
                              alt="The Arrival of a Train at La Ciotat"
                              srcset="https://a.ltrbxd.com/resized/sm/upload/99/ok/ww/39/iwxu3OVTNVy4wAQ8JbwsxYEW5Qr-0-140-0-210-crop.jpg?k=47e264821c 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                The Arrival of a Train at La Ciotat (1896)
                              </span>
                            </span>
                          </div>
                        </li>{" "}
                        <li
                          className="react-component poster film-poster film-poster-51378 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="51378"
                          data-film-name="Workers Leaving the Lumière Factory"
                          data-poster-url="/film/workers-leaving-the-lumiere-factory/image-150/"
                          data-film-release-year="1895"
                          data-new-list-with-film-action="/list/new/with/workers-leaving-the-lumiere-factory/"
                          data-remove-from-watchlist-action="/film/workers-leaving-the-lumiere-factory/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/workers-leaving-the-lumiere-factory/add-to-watchlist/"
                          data-rate-action="/film/workers-leaving-the-lumiere-factory/rate/"
                          data-mark-as-watched-action="/film/workers-leaving-the-lumiere-factory/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/workers-leaving-the-lumiere-factory/mark-as-not-watched/"
                          data-film-link="/film/workers-leaving-the-lumiere-factory/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/film-poster/5/1/3/7/8/51378-workers-leaving-the-lumiere-factory-0-70-0-105-crop.jpg?k=a95531635f"
                              width="70"
                              height="105"
                              alt="Workers Leaving the Lumière Factory"
                              srcset="https://a.ltrbxd.com/resized/film-poster/5/1/3/7/8/51378-workers-leaving-the-lumiere-factory-0-140-0-210-crop.jpg?k=2f5812aab3 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                Workers Leaving the Lumière Factory (1895)
                              </span>
                            </span>
                          </div>
                        </li>{" "}
                        <li
                          className="react-component poster film-poster film-poster-68556 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="68556"
                          data-film-name="The Sprinkler Sprinkled"
                          data-poster-url="/film/the-sprinkler-sprinkled/image-150/"
                          data-film-release-year="1895"
                          data-new-list-with-film-action="/list/new/with/the-sprinkler-sprinkled/"
                          data-remove-from-watchlist-action="/film/the-sprinkler-sprinkled/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/the-sprinkler-sprinkled/add-to-watchlist/"
                          data-rate-action="/film/the-sprinkler-sprinkled/rate/"
                          data-mark-as-watched-action="/film/the-sprinkler-sprinkled/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/the-sprinkler-sprinkled/mark-as-not-watched/"
                          data-film-link="/film/the-sprinkler-sprinkled/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/film-poster/6/8/5/5/6/68556-the-sprinkler-sprinkled-0-70-0-105-crop.jpg?k=5c255ad3e3"
                              width="70"
                              height="105"
                              alt="The Sprinkler Sprinkled"
                              srcset="https://a.ltrbxd.com/resized/film-poster/6/8/5/5/6/68556-the-sprinkler-sprinkled-0-140-0-210-crop.jpg?k=c293b7a36b 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                The Sprinkler Sprinkled (1895)
                              </span>
                            </span>
                          </div>
                        </li>{" "}
                        <li
                          className="react-component poster film-poster film-poster-96141 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="96141"
                          data-film-name="Baby's Meal"
                          data-poster-url="/film/babys-meal/image-150/"
                          data-film-release-year="1895"
                          data-new-list-with-film-action="/list/new/with/babys-meal/"
                          data-remove-from-watchlist-action="/film/babys-meal/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/babys-meal/add-to-watchlist/"
                          data-rate-action="/film/babys-meal/rate/"
                          data-mark-as-watched-action="/film/babys-meal/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/babys-meal/mark-as-not-watched/"
                          data-film-link="/film/babys-meal/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/film-poster/9/6/1/4/1/96141-baby-s-meal-0-70-0-105-crop.jpg?k=6c7e6758fb"
                              width="70"
                              height="105"
                              alt="Baby's Meal"
                              srcset="https://a.ltrbxd.com/resized/film-poster/9/6/1/4/1/96141-baby-s-meal-0-140-0-210-crop.jpg?k=e7c9d2dbdd 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                Baby's Meal (1895)
                              </span>
                            </span>
                          </div>
                        </li>{" "}
                        <li
                          className="react-component poster film-poster film-poster-84614 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="84614"
                          data-film-name="The Vanishing Lady"
                          data-poster-url="/film/the-vanishing-lady-1896/image-150/"
                          data-film-release-year="1896"
                          data-new-list-with-film-action="/list/new/with/the-vanishing-lady-1896/"
                          data-remove-from-watchlist-action="/film/the-vanishing-lady-1896/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/the-vanishing-lady-1896/add-to-watchlist/"
                          data-rate-action="/film/the-vanishing-lady-1896/rate/"
                          data-mark-as-watched-action="/film/the-vanishing-lady-1896/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/the-vanishing-lady-1896/mark-as-not-watched/"
                          data-film-link="/film/the-vanishing-lady-1896/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/film-poster/8/4/6/1/4/84614-the-vanishing-lady-0-70-0-105-crop.jpg?k=778189019c"
                              width="70"
                              height="105"
                              alt="The Vanishing Lady"
                              srcset="https://a.ltrbxd.com/resized/film-poster/8/4/6/1/4/84614-the-vanishing-lady-0-140-0-210-crop.jpg?k=c4dd076a99 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                The Vanishing Lady (1896)
                              </span>
                            </span>
                          </div>
                        </li>{" "}
                      </ul>{" "}
                      <span className="overlay"></span>{" "}
                    </a>
                    <div className="film-list-summary">
                      {" "}
                      <h2 className="title-2 prettify">
                        {" "}
                        <a href="/pileofcrowns/list/harvard-film-phd-program-narrative-films/">
                          Harvard Film PhD Program: Narrative Films
                        </a>{" "}
                      </h2>
                      <div className="attribution-block">
                        {" "}
                        <a
                          className="avatar -a16"
                          href="/pileofcrowns/"
                          data-original-title=""
                        >
                          {" "}
                          <img
                            src="https://secure.gravatar.com/avatar/0624dcb389c0dc676b4ebe633eff082d?rating=PG&amp;size=32&amp;border=&amp;default=https%3A%2F%2Fs.ltrbxd.com%2Fstatic%2Fimg%2Favatar32.09445e73.png"
                            alt="pileofcrowns"
                            width="16"
                            height="16"
                          />{" "}
                        </a>{" "}
                        <p className="attribution">
                          {" "}
                          <strong className="name">
                            <a href="/pileofcrowns/">pileofcrowns</a>
                          </strong>{" "}
                          <small className="value">343&nbsp;films</small>{" "}
                          <span className="content-metadata">
                            {" "}
                            <a
                              href="/pileofcrowns/list/harvard-film-phd-program-narrative-films/likes/"
                              className="has-icon icon-16 icon-like"
                            >
                              <span className="icon"></span>4,779
                            </a>{" "}
                            <a
                              href="/pileofcrowns/list/harvard-film-phd-program-narrative-films/#comments"
                              className="has-icon icon-16 icon-comment"
                            >
                              <span className="icon"></span> 14{" "}
                            </a>{" "}
                          </span>{" "}
                        </p>
                      </div>
                      <div
                        className="body-text -prose"
                        data-more="/pileofcrowns/list/harvard-film-phd-program-narrative-films/"
                      >
                        {" "}
                        <p>
                          This is a suggested viewing list of narrative films
                          for the Film and Visual Studies PhD offered by Harvard
                          University.…
                        </p>
                      </div>{" "}
                    </div>
                  </section>

                  <section
                    className="list -overlapped -summary "
                    data-film-list-id="18947915"
                    data-person="Slig001"
                  >
                    <a
                      href="/slig001/list/stray-cat-rock/"
                      className="list-link"
                    >
                      {" "}
                      <ul className="poster-list -p70 -overlapped">
                        {" "}
                        <li
                          className="react-component poster film-poster film-poster-248 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="248"
                          data-film-name="Stray Cat Rock: Machine Animal"
                          data-poster-url="/film/stray-cat-rock-machine-animal/image-150/"
                          data-film-release-year="1970"
                          data-new-list-with-film-action="/list/new/with/stray-cat-rock-machine-animal/"
                          data-remove-from-watchlist-action="/film/stray-cat-rock-machine-animal/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/stray-cat-rock-machine-animal/add-to-watchlist/"
                          data-rate-action="/film/stray-cat-rock-machine-animal/rate/"
                          data-mark-as-watched-action="/film/stray-cat-rock-machine-animal/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/stray-cat-rock-machine-animal/mark-as-not-watched/"
                          data-film-link="/film/stray-cat-rock-machine-animal/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/film-poster/2/4/8/248-stray-cat-rock-machine-animal-0-70-0-105-crop.jpg?k=1228845676"
                              width="70"
                              height="105"
                              alt="Stray Cat Rock: Machine Animal"
                              srcset="https://a.ltrbxd.com/resized/film-poster/2/4/8/248-stray-cat-rock-machine-animal-0-140-0-210-crop.jpg?k=e1738ccda2 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                Stray Cat Rock: Machine Animal (1970)
                              </span>
                            </span>
                          </div>
                        </li>
                        <li
                          className="react-component poster film-poster film-poster-246 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="246"
                          data-film-name="Stray Cat Rock: Wild Jumbo"
                          data-poster-url="/film/stray-cat-rock-wild-jumbo/image-150/"
                          data-film-release-year="1970"
                          data-new-list-with-film-action="/list/new/with/stray-cat-rock-wild-jumbo/"
                          data-remove-from-watchlist-action="/film/stray-cat-rock-wild-jumbo/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/stray-cat-rock-wild-jumbo/add-to-watchlist/"
                          data-rate-action="/film/stray-cat-rock-wild-jumbo/rate/"
                          data-mark-as-watched-action="/film/stray-cat-rock-wild-jumbo/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/stray-cat-rock-wild-jumbo/mark-as-not-watched/"
                          data-film-link="/film/stray-cat-rock-wild-jumbo/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/film-poster/2/4/6/246-stray-cat-rock-wild-jumbo-0-70-0-105-crop.jpg?k=373c39d721"
                              width="70"
                              height="105"
                              alt="Stray Cat Rock: Wild Jumbo"
                              srcset="https://a.ltrbxd.com/resized/film-poster/2/4/6/246-stray-cat-rock-wild-jumbo-0-140-0-210-crop.jpg?k=0321d1d085 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                Stray Cat Rock: Wild Jumbo (1970)
                              </span>
                            </span>
                          </div>
                        </li>
                        <li
                          className="react-component poster film-poster film-poster-383 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="383"
                          data-film-name="Stray Cat Rock: Delinquent Girl Boss"
                          data-poster-url="/film/stray-cat-rock-delinquent-girl-boss/image-150/"
                          data-film-release-year="1970"
                          data-new-list-with-film-action="/list/new/with/stray-cat-rock-delinquent-girl-boss/"
                          data-remove-from-watchlist-action="/film/stray-cat-rock-delinquent-girl-boss/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/stray-cat-rock-delinquent-girl-boss/add-to-watchlist/"
                          data-rate-action="/film/stray-cat-rock-delinquent-girl-boss/rate/"
                          data-mark-as-watched-action="/film/stray-cat-rock-delinquent-girl-boss/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/stray-cat-rock-delinquent-girl-boss/mark-as-not-watched/"
                          data-film-link="/film/stray-cat-rock-delinquent-girl-boss/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/film-poster/3/8/3/383-stray-cat-rock-delinquent-girl-boss-0-70-0-105-crop.jpg?k=30a628aeef"
                              width="70"
                              height="105"
                              alt="Stray Cat Rock: Delinquent Girl Boss"
                              srcset="https://a.ltrbxd.com/resized/film-poster/3/8/3/383-stray-cat-rock-delinquent-girl-boss-0-140-0-210-crop.jpg?k=f21fc27528 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                Stray Cat Rock: Delinquent Girl Boss (1970)
                              </span>
                            </span>
                          </div>
                        </li>
                        <li
                          className="react-component poster film-poster film-poster-315 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="315"
                          data-film-name="Stray Cat Rock: Sex Hunter"
                          data-poster-url="/film/stray-cat-rock-sex-hunter/image-150/"
                          data-film-release-year="1970"
                          data-new-list-with-film-action="/list/new/with/stray-cat-rock-sex-hunter/"
                          data-remove-from-watchlist-action="/film/stray-cat-rock-sex-hunter/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/stray-cat-rock-sex-hunter/add-to-watchlist/"
                          data-rate-action="/film/stray-cat-rock-sex-hunter/rate/"
                          data-mark-as-watched-action="/film/stray-cat-rock-sex-hunter/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/stray-cat-rock-sex-hunter/mark-as-not-watched/"
                          data-film-link="/film/stray-cat-rock-sex-hunter/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/film-poster/3/1/5/315-stray-cat-rock-sex-hunter-0-70-0-105-crop.jpg?k=30a628aeef"
                              width="70"
                              height="105"
                              alt="Stray Cat Rock: Sex Hunter"
                              srcset="https://a.ltrbxd.com/resized/film-poster/3/1/5/315-stray-cat-rock-sex-hunter-0-140-0-210-crop.jpg?k=cdde440710 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                Stray Cat Rock: Sex Hunter (1970)
                              </span>
                            </span>
                          </div>
                        </li>
                        <li
                          className="react-component poster film-poster film-poster-94248 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="94248"
                          data-film-name="Stray Cat Rock: Beat '71"
                          data-poster-url="/film/stray-cat-rock-beat-71/image-150/"
                          data-film-release-year="1971"
                          data-new-list-with-film-action="/list/new/with/stray-cat-rock-beat-71/"
                          data-remove-from-watchlist-action="/film/stray-cat-rock-beat-71/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/stray-cat-rock-beat-71/add-to-watchlist/"
                          data-rate-action="/film/stray-cat-rock-beat-71/rate/"
                          data-mark-as-watched-action="/film/stray-cat-rock-beat-71/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/stray-cat-rock-beat-71/mark-as-not-watched/"
                          data-film-link="/film/stray-cat-rock-beat-71/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/film-poster/9/4/2/4/8/94248-stray-cat-rock-beat-71-0-70-0-105-crop.jpg?k=1f91fd7279"
                              width="70"
                              height="105"
                              alt="Stray Cat Rock: Beat '71"
                              srcset="https://a.ltrbxd.com/resized/film-poster/9/4/2/4/8/94248-stray-cat-rock-beat-71-0-140-0-210-crop.jpg?k=944761ca6e 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                Stray Cat Rock: Beat '71 (1971)
                              </span>
                            </span>
                          </div>
                        </li>{" "}
                      </ul>
                      <span className="overlay"></span>{" "}
                    </a>

                    <div className="film-list-summary">
                      {" "}
                      <h2 className="title-2 prettify">
                        {" "}
                        <a href="/slig001/list/stray-cat-rock/">
                          Stray Cat Rock
                        </a>{" "}
                      </h2>
                      <div className="attribution-block">
                        <a
                          className="avatar -a16"
                          href="/slig001/"
                          data-original-title=""
                        >
                          <img
                            src="https://secure.gravatar.com/avatar/d71a8367ca14bc720c2ea9d7a20fc347?rating=PG&amp;size=32&amp;border=&amp;default=https%3A%2F%2Fs.ltrbxd.com%2Fstatic%2Fimg%2Favatar32.09445e73.png"
                            alt="Slig001"
                            width="16"
                            height="16"
                          />{" "}
                        </a>
                        <p className="attribution">
                          {" "}
                          <strong className="name">
                            <a href="/slig001/">Slig001</a>
                          </strong>{" "}
                          <small className="value">5&nbsp;films</small>
                          <span className="content-metadata">
                            {" "}
                            <a
                              href="/slig001/list/stray-cat-rock/likes/"
                              className="has-icon icon-16 icon-like"
                            >
                              <span className="icon"></span>4
                            </a>
                          </span>{" "}
                        </p>
                      </div>
                      <div className="body-text -prose">
                        {" "}
                        <p>Ranked in order of preference......</p>
                      </div>
                    </div>
                  </section>

                  <section
                    className="list -overlapped -summary "
                    data-film-list-id="18085692"
                    data-person="_Sydney"
                  >
                    <a href="/_sydney/list/favourites-1/" className="list-link">
                      {" "}
                      <ul className="poster-list -p70 -overlapped">
                        <li
                          className="react-component poster film-poster film-poster-49390 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="49390"
                          data-film-name="Pride &amp; Prejudice"
                          data-poster-url="/film/pride-prejudice/image-150/"
                          data-film-release-year="2005"
                          data-new-list-with-film-action="/list/new/with/pride-prejudice/"
                          data-remove-from-watchlist-action="/film/pride-prejudice/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/pride-prejudice/add-to-watchlist/"
                          data-rate-action="/film/pride-prejudice/rate/"
                          data-mark-as-watched-action="/film/pride-prejudice/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/pride-prejudice/mark-as-not-watched/"
                          data-film-link="/film/pride-prejudice/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/sm/upload/nq/jo/26/tn/dAC0hkYmz5ZOCHURZCyj9isPMPd-0-70-0-105-crop.jpg?k=b774978eb3"
                              width="70"
                              height="105"
                              alt="Pride &amp; Prejudice"
                              srcset="https://a.ltrbxd.com/resized/sm/upload/nq/jo/26/tn/dAC0hkYmz5ZOCHURZCyj9isPMPd-0-140-0-210-crop.jpg?k=f082f98cd5 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                Pride &amp; Prejudice (2005)
                              </span>
                            </span>
                          </div>
                        </li>
                        <li
                          className="react-component poster film-poster film-poster-216086 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="216086"
                          data-film-name="The Handmaiden"
                          data-poster-url="/film/the-handmaiden/image-150/"
                          data-film-release-year="2016"
                          data-new-list-with-film-action="/list/new/with/the-handmaiden/"
                          data-remove-from-watchlist-action="/film/the-handmaiden/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/the-handmaiden/add-to-watchlist/"
                          data-rate-action="/film/the-handmaiden/rate/"
                          data-mark-as-watched-action="/film/the-handmaiden/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/the-handmaiden/mark-as-not-watched/"
                          data-film-link="/film/the-handmaiden/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/sm/upload/pc/n6/pz/mi/wvzfK5QR6dGLwND8MCzWjsQWG4Q-0-70-0-105-crop.jpg?k=52da592cd7"
                              width="70"
                              height="105"
                              alt="The Handmaiden"
                              srcset="https://a.ltrbxd.com/resized/sm/upload/pc/n6/pz/mi/wvzfK5QR6dGLwND8MCzWjsQWG4Q-0-140-0-210-crop.jpg?k=cc529a511e 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                The Handmaiden (2016)
                              </span>
                            </span>
                          </div>
                        </li>
                        <li
                          className="react-component poster film-poster film-poster-51970 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="51970"
                          data-film-name="Before Sunset"
                          data-poster-url="/film/before-sunset/image-150/"
                          data-film-release-year="2004"
                          data-new-list-with-film-action="/list/new/with/before-sunset/"
                          data-remove-from-watchlist-action="/film/before-sunset/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/before-sunset/add-to-watchlist/"
                          data-rate-action="/film/before-sunset/rate/"
                          data-mark-as-watched-action="/film/before-sunset/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/before-sunset/mark-as-not-watched/"
                          data-film-link="/film/before-sunset/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/film-poster/5/1/9/7/0/51970-before-sunset-0-70-0-105-crop.jpg?k=0eafde04ba"
                              width="70"
                              height="105"
                              alt="Before Sunset"
                              srcset="https://a.ltrbxd.com/resized/film-poster/5/1/9/7/0/51970-before-sunset-0-140-0-210-crop.jpg?k=05ede05c86 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                Before Sunset (2004)
                              </span>
                            </span>
                          </div>
                        </li>
                        <li
                          className="react-component poster film-poster film-poster-51552 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="51552"
                          data-film-name="Rear Window"
                          data-poster-url="/film/rear-window/image-150/"
                          data-film-release-year="1954"
                          data-new-list-with-film-action="/list/new/with/rear-window/"
                          data-remove-from-watchlist-action="/film/rear-window/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/rear-window/add-to-watchlist/"
                          data-rate-action="/film/rear-window/rate/"
                          data-mark-as-watched-action="/film/rear-window/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/rear-window/mark-as-not-watched/"
                          data-film-link="/film/rear-window/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/film-poster/5/1/5/5/2/51552-rear-window-0-70-0-105-crop.jpg?k=a08fd745a8"
                              width="70"
                              height="105"
                              alt="Rear Window"
                              srcset="https://a.ltrbxd.com/resized/film-poster/5/1/5/5/2/51552-rear-window-0-140-0-210-crop.jpg?k=42639168aa 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                Rear Window (1954)
                              </span>
                            </span>
                          </div>
                        </li>
                        <li
                          className="react-component poster film-poster film-poster-50949 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="50949"
                          data-film-name="It's a Wonderful Life"
                          data-poster-url="/film/its-a-wonderful-life/image-150/"
                          data-film-release-year="1946"
                          data-new-list-with-film-action="/list/new/with/its-a-wonderful-life/"
                          data-remove-from-watchlist-action="/film/its-a-wonderful-life/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/its-a-wonderful-life/add-to-watchlist/"
                          data-rate-action="/film/its-a-wonderful-life/rate/"
                          data-mark-as-watched-action="/film/its-a-wonderful-life/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/its-a-wonderful-life/mark-as-not-watched/"
                          data-film-link="/film/its-a-wonderful-life/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/film-poster/5/0/9/4/9/50949-it-s-a-wonderful-life-0-70-0-105-crop.jpg?k=d39cc6c916"
                              width="70"
                              height="105"
                              alt="It's a Wonderful Life"
                              srcset="https://a.ltrbxd.com/resized/film-poster/5/0/9/4/9/50949-it-s-a-wonderful-life-0-140-0-210-crop.jpg?k=8a66567cc7 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                It's a Wonderful Life (1946)
                              </span>
                            </span>
                          </div>
                        </li>
                      </ul>
                      <span className="overlay"></span>{" "}
                    </a>

                    <div className="film-list-summary">
                      {" "}
                      <h2 className="title-2 prettify">
                        {" "}
                        <a href="/_sydney/list/favourites-1/">
                          Favourites
                        </a>{" "}
                      </h2>
                      <div className="attribution-block">
                        {" "}
                        <a
                          className="avatar -a16"
                          href="/_sydney/"
                          data-original-title=""
                        >
                          <img
                            src="https://a.ltrbxd.com/resized/avatar/upload/1/6/0/8/3/7/8/shard/avtr-0-32-0-32-crop.jpg?k=999ac29be2"
                            alt="Sydney🌻"
                            width="16"
                            height="16"
                          />{" "}
                        </a>{" "}
                        <p className="attribution">
                          <strong className="name">
                            <a href="/_sydney/">Sydney🌻</a>
                          </strong>{" "}
                          <small className="value">43&nbsp;films</small>{" "}
                          <span className="content-metadata">
                            {" "}
                            <a
                              href="/_sydney/list/favourites-1/likes/"
                              className="has-icon icon-16 icon-like"
                            >
                              <span className="icon"></span>16
                            </a>{" "}
                          </span>{" "}
                        </p>
                      </div>
                      <div className="body-text -prose">
                        {" "}
                        <p>
                          So what you can gather from this list is that I AM A
                          CHILD
                        </p>
                      </div>
                    </div>
                  </section>

                  <section
                    className="list -overlapped -summary "
                    data-film-list-id="18962372"
                    data-person="matthewcutchen"
                  >
                    <a
                      href="/matthewcutchen/list/films-that-i-stumbled-upon-while-uploading/"
                      className="list-link"
                    >
                      <ul className="poster-list -p70 -overlapped">
                        <li
                          className="react-component poster film-poster film-poster-650236 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="650236"
                          data-film-name="Laundry Night"
                          data-poster-url="/film/laundry-night/image-150/"
                          data-film-release-year=""
                          data-new-list-with-film-action="/list/new/with/laundry-night/"
                          data-remove-from-watchlist-action="/film/laundry-night/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/laundry-night/add-to-watchlist/"
                          data-rate-action="/film/laundry-night/rate/"
                          data-mark-as-watched-action="/film/laundry-night/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/laundry-night/mark-as-not-watched/"
                          data-film-link="/film/laundry-night/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/film-poster/6/5/0/2/3/6/650236-laundry-night-0-70-0-105-crop.jpg?k=c6f6195574"
                              width="70"
                              height="105"
                              alt="Laundry Night"
                              srcset="https://a.ltrbxd.com/resized/film-poster/6/5/0/2/3/6/650236-laundry-night-0-140-0-210-crop.jpg?k=500f97d017 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">Laundry Night</span>
                            </span>
                          </div>
                        </li>
                        <li className="listitem poster -placeholder"></li>
                        <li className="listitem poster -placeholder"></li>
                        <li className="listitem poster -placeholder"></li>{" "}
                        <li className="listitem poster -placeholder"></li>{" "}
                      </ul>
                      <span className="overlay"></span>{" "}
                    </a>
                    <div className="film-list-summary">
                      <h2 className="title-2 prettify">
                        <a href="/matthewcutchen/list/films-that-i-stumbled-upon-while-uploading/">
                          films that i stumbled upon while uploading my short
                          film “NIGHT LAUNDRY” that, turns out, also find doing
                          laundry at night kinda creepy…
                        </a>{" "}
                      </h2>
                      <div className="attribution-block">
                        {" "}
                        <a
                          className="avatar -a16"
                          href="/matthewcutchen/"
                          data-original-title=""
                        >
                          <img
                            src="https://a.ltrbxd.com/resized/avatar/upload/1/4/2/7/8/6/0/shard/avtr-0-32-0-32-crop.jpg?k=535bafe07d"
                            alt="matthewcutchen"
                            width="16"
                            height="16"
                          />{" "}
                        </a>
                        <p className="attribution">
                          <strong className="name">
                            <a href="/matthewcutchen/">matthewcutchen</a>
                          </strong>
                          <small className="value">1&nbsp;film</small>
                          <span className="content-metadata">
                            {" "}
                            <a
                              href="/matthewcutchen/list/films-that-i-stumbled-upon-while-uploading/likes/"
                              className="has-icon icon-16 icon-like"
                            >
                              <span className="icon"></span>3
                            </a>{" "}
                          </span>{" "}
                        </p>
                      </div>
                    </div>
                  </section>
                </section>
              </div>
              <aside className="sidebar">
                <section id="crew-picks" className="section">
                  <h2 className="section-heading">Crew picks</h2>
                  <div className="featured-list">
                    <section
                      className="list -overlapped -stacked list-stacked-narrow -ellipsis-230"
                      data-film-list-id="18562138"
                      data-person="crew"
                    >
                      <a
                        href="/crew/list/top-25-highest-rated-for-first-half-of-2021/"
                        className="list-link"
                      >
                        <div className="list-link-stacked clear">
                          <ul className="poster-list -overlapped -p70">
                            <li
                              className="react-component poster film-poster film-poster-550733 listitem"
                              data-component-className="globals.comps.FilmPosterComponent"
                              data-film-id="550733"
                              data-film-name="Cleaners"
                              data-poster-url="/film/cleaners-2019/image-150/"
                              data-film-release-year="2019"
                              data-new-list-with-film-action="/list/new/with/cleaners-2019/"
                              data-remove-from-watchlist-action="/film/cleaners-2019/remove-from-watchlist/"
                              data-add-to-watchlist-action="/film/cleaners-2019/add-to-watchlist/"
                              data-rate-action="/film/cleaners-2019/rate/"
                              data-mark-as-watched-action="/film/cleaners-2019/mark-as-watched/"
                              data-mark-as-not-watched-action="/film/cleaners-2019/mark-as-not-watched/"
                              data-film-link="/film/cleaners-2019/"
                            >
                              <div>
                                <img
                                  src="https://a.ltrbxd.com/resized/film-poster/5/5/0/7/3/3/550733-cleaners-0-70-0-105-crop.jpg?k=201c475cbd"
                                  width="70"
                                  height="105"
                                  alt="Cleaners"
                                  srcset="https://a.ltrbxd.com/resized/film-poster/5/5/0/7/3/3/550733-cleaners-0-140-0-210-crop.jpg?k=57b0ba55bf 2x"
                                  className="image"
                                />
                                <span className="frame">
                                  <span className="frame-title">
                                    Cleaners (2019)
                                  </span>
                                </span>
                              </div>
                            </li>

                            <li
                              className="react-component poster film-poster film-poster-482842 listitem"
                              data-component-className="globals.comps.FilmPosterComponent"
                              data-film-id="482842"
                              data-film-name="Ode to Nothing"
                              data-poster-url="/film/ode-to-nothing/image-150/"
                              data-film-release-year="2018"
                              data-new-list-with-film-action="/list/new/with/ode-to-nothing/"
                              data-remove-from-watchlist-action="/film/ode-to-nothing/remove-from-watchlist/"
                              data-add-to-watchlist-action="/film/ode-to-nothing/add-to-watchlist/"
                              data-rate-action="/film/ode-to-nothing/rate/"
                              data-mark-as-watched-action="/film/ode-to-nothing/mark-as-watched/"
                              data-mark-as-not-watched-action="/film/ode-to-nothing/mark-as-not-watched/"
                              data-film-link="/film/ode-to-nothing/"
                            >
                              <div>
                                <img
                                  src="https://a.ltrbxd.com/resized/film-poster/4/8/2/8/4/2/482842-ode-to-nothing-0-70-0-105-crop.jpg?k=b1ef6c01e8"
                                  width="70"
                                  height="105"
                                  alt="Ode to Nothing"
                                  srcset="https://a.ltrbxd.com/resized/film-poster/4/8/2/8/4/2/482842-ode-to-nothing-0-140-0-210-crop.jpg?k=def36c1ed0 2x"
                                  className="image"
                                />
                                <span className="frame">
                                  <span className="frame-title">
                                    Ode to Nothing (2018)
                                  </span>
                                </span>
                              </div>
                            </li>

                            <li
                              className="react-component poster film-poster film-poster-511342 listitem"
                              data-component-className="globals.comps.FilmPosterComponent"
                              data-film-id="511342"
                              data-film-name="Judas and the Black Messiah"
                              data-poster-url="/film/judas-and-the-black-messiah/image-150/"
                              data-film-release-year="2021"
                              data-new-list-with-film-action="/list/new/with/judas-and-the-black-messiah/"
                              data-remove-from-watchlist-action="/film/judas-and-the-black-messiah/remove-from-watchlist/"
                              data-add-to-watchlist-action="/film/judas-and-the-black-messiah/add-to-watchlist/"
                              data-rate-action="/film/judas-and-the-black-messiah/rate/"
                              data-mark-as-watched-action="/film/judas-and-the-black-messiah/mark-as-watched/"
                              data-mark-as-not-watched-action="/film/judas-and-the-black-messiah/mark-as-not-watched/"
                              data-film-link="/film/judas-and-the-black-messiah/"
                            >
                              <div>
                                <img
                                  src="https://a.ltrbxd.com/resized/film-poster/5/1/1/3/4/2/511342-judas-and-the-black-messiah-0-70-0-105-crop.jpg?k=1f3649c59e"
                                  width="70"
                                  height="105"
                                  alt="Judas and the Black Messiah"
                                  srcset="https://a.ltrbxd.com/resized/film-poster/5/1/1/3/4/2/511342-judas-and-the-black-messiah-0-140-0-210-crop.jpg?k=d281757eea 2x"
                                  className="image"
                                />
                                <span className="frame">
                                  <span className="frame-title">
                                    Judas and the Black Messiah (2021)
                                  </span>
                                </span>
                              </div>
                            </li>

                            <li
                              className="react-component poster film-poster film-poster-662825 listitem"
                              data-component-className="globals.comps.FilmPosterComponent"
                              data-film-id="662825"
                              data-film-name="My First Summer"
                              data-poster-url="/film/my-first-summer/image-150/"
                              data-film-release-year="2020"
                              data-new-list-with-film-action="/list/new/with/my-first-summer/"
                              data-remove-from-watchlist-action="/film/my-first-summer/remove-from-watchlist/"
                              data-add-to-watchlist-action="/film/my-first-summer/add-to-watchlist/"
                              data-rate-action="/film/my-first-summer/rate/"
                              data-mark-as-watched-action="/film/my-first-summer/mark-as-watched/"
                              data-mark-as-not-watched-action="/film/my-first-summer/mark-as-not-watched/"
                              data-film-link="/film/my-first-summer/"
                            >
                              <div>
                                <img
                                  src="https://a.ltrbxd.com/resized/film-poster/6/6/2/8/2/5/662825-my-first-summer-0-70-0-105-crop.jpg?k=3b484f783f"
                                  width="70"
                                  height="105"
                                  alt="My First Summer"
                                  srcset="https://a.ltrbxd.com/resized/film-poster/6/6/2/8/2/5/662825-my-first-summer-0-140-0-210-crop.jpg?k=f1d6b78bd4 2x"
                                  className="image"
                                />
                                <span className="frame">
                                  <span className="frame-title">
                                    My First Summer (2020)
                                  </span>
                                </span>
                              </div>
                            </li>

                            <li
                              className="react-component poster film-poster film-poster-704387 listitem"
                              data-component-className="globals.comps.FilmPosterComponent"
                              data-film-id="704387"
                              data-film-name="The Great Indian Kitchen"
                              data-poster-url="/film/the-great-indian-kitchen/image-150/"
                              data-film-release-year="2021"
                              data-new-list-with-film-action="/list/new/with/the-great-indian-kitchen/"
                              data-remove-from-watchlist-action="/film/the-great-indian-kitchen/remove-from-watchlist/"
                              data-add-to-watchlist-action="/film/the-great-indian-kitchen/add-to-watchlist/"
                              data-rate-action="/film/the-great-indian-kitchen/rate/"
                              data-mark-as-watched-action="/film/the-great-indian-kitchen/mark-as-watched/"
                              data-mark-as-not-watched-action="/film/the-great-indian-kitchen/mark-as-not-watched/"
                              data-film-link="/film/the-great-indian-kitchen/"
                            >
                              <div>
                                <img
                                  src="https://a.ltrbxd.com/resized/film-poster/7/0/4/3/8/7/704387-the-great-indian-kitchen-0-70-0-105-crop.jpg?k=eb8622416f"
                                  width="70"
                                  height="105"
                                  alt="The Great Indian Kitchen"
                                  srcset="https://a.ltrbxd.com/resized/film-poster/7/0/4/3/8/7/704387-the-great-indian-kitchen-0-140-0-210-crop.jpg?k=67dc974187 2x"
                                  className="image"
                                />
                                <span className="frame">
                                  <span className="frame-title">
                                    The Great Indian Kitchen (2021)
                                  </span>
                                </span>
                              </div>
                            </li>
                          </ul>
                        </div>
                        <span className="overlay"></span>
                      </a>

                      <h3 className="title-3 prettify">
                        {" "}
                        <a href="/crew/list/top-25-highest-rated-for-first-half-of-2021/">
                          Top 25 Highest Rated for first half of 2021
                        </a>{" "}
                      </h3>

                      <div className="attribution-block">
                        <a
                          className="avatar -a16"
                          href="/crew/"
                          data-original-title=""
                        >
                          {" "}
                          <img
                            src="https://vinzator.com/movieProject/son-resim/cine1.jpg"
                            alt="vinzator"
                            width="16"
                            height="16"
                          />{" "}
                        </a>
                        <p className="attribution">
                          <strong className="name">
                            <a href="/crew/">vinzator</a>
                          </strong>
                          <small className="value">25&nbsp;films</small>
                        </p>
                      </div>
                    </section>

                    <section
                      className="list -overlapped -stacked list-stacked-narrow -ellipsis-230"
                      data-film-list-id="17450723"
                      data-person="NePerfectionist"
                    >
                      <a
                        href="/neperfectionist/list/74th-cannes-film-festival-2021/"
                        className="list-link"
                      >
                        <div className="list-link-stacked clear">
                          <ul className="poster-list -overlapped -p70">
                            <li
                              className="react-component poster film-poster film-poster-556553 listitem"
                              data-component-className="globals.comps.FilmPosterComponent"
                              data-film-id="556553"
                              data-film-name="Titane"
                              data-poster-url="/film/titane/image-150/"
                              data-film-release-year="2021"
                              data-new-list-with-film-action="/list/new/with/titane/"
                              data-remove-from-watchlist-action="/film/titane/remove-from-watchlist/"
                              data-add-to-watchlist-action="/film/titane/add-to-watchlist/"
                              data-rate-action="/film/titane/rate/"
                              data-mark-as-watched-action="/film/titane/mark-as-watched/"
                              data-mark-as-not-watched-action="/film/titane/mark-as-not-watched/"
                              data-film-link="/film/titane/"
                            >
                              <div>
                                <img
                                  src="https://a.ltrbxd.com/resized/film-poster/5/5/6/5/5/3/556553-titane-0-70-0-105-crop.jpg?k=21e476d4a8"
                                  width="70"
                                  height="105"
                                  alt="Titane"
                                  srcset="https://a.ltrbxd.com/resized/film-poster/5/5/6/5/5/3/556553-titane-0-140-0-210-crop.jpg?k=a2c7c3fb8e 2x"
                                  className="image"
                                />
                                <span className="frame">
                                  <span className="frame-title">
                                    Titane (2021)
                                  </span>
                                </span>
                              </div>
                            </li>

                            <li
                              className="react-component poster film-poster film-poster-516048 listitem"
                              data-component-className="globals.comps.FilmPosterComponent"
                              data-film-id="516048"
                              data-film-name="Compartment No. 6"
                              data-poster-url="/film/compartment-no-6/image-150/"
                              data-film-release-year="2021"
                              data-new-list-with-film-action="/list/new/with/compartment-no-6/"
                              data-remove-from-watchlist-action="/film/compartment-no-6/remove-from-watchlist/"
                              data-add-to-watchlist-action="/film/compartment-no-6/add-to-watchlist/"
                              data-rate-action="/film/compartment-no-6/rate/"
                              data-mark-as-watched-action="/film/compartment-no-6/mark-as-watched/"
                              data-mark-as-not-watched-action="/film/compartment-no-6/mark-as-not-watched/"
                              data-film-link="/film/compartment-no-6/"
                            >
                              <div>
                                <img
                                  src="https://a.ltrbxd.com/resized/film-poster/5/1/6/0/4/8/516048-compartment-no-6-0-70-0-105-crop.jpg?k=3ffa22c851"
                                  width="70"
                                  height="105"
                                  alt="Compartment No. 6"
                                  srcset="https://a.ltrbxd.com/resized/film-poster/5/1/6/0/4/8/516048-compartment-no-6-0-140-0-210-crop.jpg?k=7e7bb8e6e7 2x"
                                  className="image"
                                />
                                <span className="frame">
                                  <span className="frame-title">
                                    Compartment No. 6 (2021)
                                  </span>
                                </span>
                              </div>
                            </li>

                            <li
                              className="react-component poster film-poster film-poster-596809 listitem"
                              data-component-className="globals.comps.FilmPosterComponent"
                              data-film-id="596809"
                              data-film-name="A Hero"
                              data-poster-url="/film/a-hero/image-150/"
                              data-film-release-year="2021"
                              data-new-list-with-film-action="/list/new/with/a-hero/"
                              data-remove-from-watchlist-action="/film/a-hero/remove-from-watchlist/"
                              data-add-to-watchlist-action="/film/a-hero/add-to-watchlist/"
                              data-rate-action="/film/a-hero/rate/"
                              data-mark-as-watched-action="/film/a-hero/mark-as-watched/"
                              data-mark-as-not-watched-action="/film/a-hero/mark-as-not-watched/"
                              data-film-link="/film/a-hero/"
                            >
                              <div>
                                <img
                                  src="https://a.ltrbxd.com/resized/film-poster/5/9/6/8/0/9/596809-a-hero-0-70-0-105-crop.jpg?k=fcefdb90f6"
                                  width="70"
                                  height="105"
                                  alt="A Hero"
                                  srcset="https://a.ltrbxd.com/resized/film-poster/5/9/6/8/0/9/596809-a-hero-0-140-0-210-crop.jpg?k=2de1bdd386 2x"
                                  className="image"
                                />
                                <span className="frame">
                                  <span className="frame-title">
                                    A Hero (2021)
                                  </span>
                                </span>
                              </div>
                            </li>

                            <li
                              className="react-component poster film-poster film-poster-357826 listitem"
                              data-component-className="globals.comps.FilmPosterComponent"
                              data-film-id="357826"
                              data-film-name="Annette"
                              data-poster-url="/film/annette/image-150/"
                              data-film-release-year="2021"
                              data-new-list-with-film-action="/list/new/with/annette/"
                              data-remove-from-watchlist-action="/film/annette/remove-from-watchlist/"
                              data-add-to-watchlist-action="/film/annette/add-to-watchlist/"
                              data-rate-action="/film/annette/rate/"
                              data-mark-as-watched-action="/film/annette/mark-as-watched/"
                              data-mark-as-not-watched-action="/film/annette/mark-as-not-watched/"
                              data-film-link="/film/annette/"
                            >
                              <div>
                                <img
                                  src="https://a.ltrbxd.com/resized/film-poster/3/5/7/8/2/6/357826-annette-0-70-0-105-crop.jpg?k=54c00c23af"
                                  width="70"
                                  height="105"
                                  alt="Annette"
                                  srcset="https://a.ltrbxd.com/resized/film-poster/3/5/7/8/2/6/357826-annette-0-140-0-210-crop.jpg?k=717df211e1 2x"
                                  className="image"
                                />
                                <span className="frame">
                                  <span className="frame-title">
                                    Annette (2021)
                                  </span>
                                </span>
                              </div>
                            </li>

                            <li
                              className="react-component poster film-poster film-poster-679291 listitem"
                              data-component-className="globals.comps.FilmPosterComponent"
                              data-film-id="679291"
                              data-film-name="Drive My Car"
                              data-poster-url="/film/drive-my-car/image-150/"
                              data-film-release-year="2021"
                              data-new-list-with-film-action="/list/new/with/drive-my-car/"
                              data-remove-from-watchlist-action="/film/drive-my-car/remove-from-watchlist/"
                              data-add-to-watchlist-action="/film/drive-my-car/add-to-watchlist/"
                              data-rate-action="/film/drive-my-car/rate/"
                              data-mark-as-watched-action="/film/drive-my-car/mark-as-watched/"
                              data-mark-as-not-watched-action="/film/drive-my-car/mark-as-not-watched/"
                              data-film-link="/film/drive-my-car/"
                            >
                              <div>
                                <img
                                  src="https://a.ltrbxd.com/resized/film-poster/6/7/9/2/9/1/679291-drive-my-car-0-70-0-105-crop.jpg?k=b76043753d"
                                  width="70"
                                  height="105"
                                  alt="Drive My Car"
                                  srcset="https://a.ltrbxd.com/resized/film-poster/6/7/9/2/9/1/679291-drive-my-car-0-140-0-210-crop.jpg?k=2c345e79e1 2x"
                                  className="image"
                                />
                                <span className="frame">
                                  <span className="frame-title">
                                    Drive My Car (2021)
                                  </span>
                                </span>
                              </div>
                            </li>
                          </ul>
                        </div>
                        <span className="overlay"></span>
                      </a>

                      <h3 className="title-3 prettify">
                        {" "}
                        <a href="/neperfectionist/list/74th-cannes-film-festival-2021/">
                          74th Cannes Film Festival (2021)
                        </a>{" "}
                      </h3>

                      <div className="attribution-block">
                        <a
                          className="avatar -a16"
                          href="/neperfectionist/"
                          data-original-title=""
                        >
                          {" "}
                          <img
                            src="https://a.ltrbxd.com/resized/avatar/twitter/7/6/3/6/8/8/shard/http___pbs.twimg.com_profile_images_1171585031548080129_tuVtSGhW-0-32-0-32-crop.jpg?k=44a0a67938"
                            alt="Denis Eremeev"
                            width="16"
                            height="16"
                          />{" "}
                        </a>

                        <p className="attribution">
                          <strong className="name">
                            <a href="/neperfectionist/">Denis Eremeev</a>
                          </strong>

                          <small className="value">240&nbsp;films</small>
                        </p>
                      </div>
                    </section>

                    <section
                      className="list -overlapped -stacked list-stacked-narrow -ellipsis-230"
                      data-film-list-id="8458877"
                      data-person="kurumaisu"
                    >
                      <a
                        href="/kurumaisu/list/disabled-life-on-film/"
                        className="list-link"
                      >
                        <div className="list-link-stacked clear">
                          <ul className="poster-list -overlapped -p70">
                            <li
                              className="react-component poster film-poster film-poster-85164 listitem"
                              data-component-className="globals.comps.FilmPosterComponent"
                              data-film-id="85164"
                              data-film-name="...And Your Name Is Jonah"
                              data-poster-url="/film/and-your-name-is-jonah/image-150/"
                              data-film-release-year="1979"
                              data-new-list-with-film-action="/list/new/with/and-your-name-is-jonah/"
                              data-remove-from-watchlist-action="/film/and-your-name-is-jonah/remove-from-watchlist/"
                              data-add-to-watchlist-action="/film/and-your-name-is-jonah/add-to-watchlist/"
                              data-rate-action="/film/and-your-name-is-jonah/rate/"
                              data-mark-as-watched-action="/film/and-your-name-is-jonah/mark-as-watched/"
                              data-mark-as-not-watched-action="/film/and-your-name-is-jonah/mark-as-not-watched/"
                              data-film-link="/film/and-your-name-is-jonah/"
                            >
                              <div>
                                <img
                                  src="https://a.ltrbxd.com/resized/film-poster/8/5/1/6/4/85164--and-your-name-is-jonah-0-70-0-105-crop.jpg?k=f882496c1f"
                                  width="70"
                                  height="105"
                                  alt="...And Your Name Is Jonah"
                                  srcset="https://a.ltrbxd.com/resized/film-poster/8/5/1/6/4/85164--and-your-name-is-jonah-0-140-0-210-crop.jpg?k=07e3c24fcb 2x"
                                  className="image"
                                />
                                <span className="frame">
                                  <span className="frame-title">
                                    ...And Your Name Is Jonah (1979)
                                  </span>
                                </span>
                              </div>
                            </li>

                            <li
                              className="react-component poster film-poster film-poster-337341 listitem"
                              data-component-className="globals.comps.FilmPosterComponent"
                              data-film-id="337341"
                              data-film-name="100 Meters"
                              data-poster-url="/film/100-meters/image-150/"
                              data-film-release-year="2016"
                              data-new-list-with-film-action="/list/new/with/100-meters/"
                              data-remove-from-watchlist-action="/film/100-meters/remove-from-watchlist/"
                              data-add-to-watchlist-action="/film/100-meters/add-to-watchlist/"
                              data-rate-action="/film/100-meters/rate/"
                              data-mark-as-watched-action="/film/100-meters/mark-as-watched/"
                              data-mark-as-not-watched-action="/film/100-meters/mark-as-not-watched/"
                              data-film-link="/film/100-meters/"
                            >
                              <div>
                                <img
                                  src="https://a.ltrbxd.com/resized/film-poster/3/3/7/3/4/1/337341-100-meters-0-70-0-105-crop.jpg?k=3ec07f72ce"
                                  width="70"
                                  height="105"
                                  alt="100 Meters"
                                  srcset="https://a.ltrbxd.com/resized/film-poster/3/3/7/3/4/1/337341-100-meters-0-140-0-210-crop.jpg?k=0d9aa37915 2x"
                                  className="image"
                                />
                                <span className="frame">
                                  <span className="frame-title">
                                    100 Meters (2016)
                                  </span>
                                </span>
                              </div>
                            </li>

                            <li
                              className="react-component poster film-poster film-poster-405546 listitem"
                              data-component-className="globals.comps.FilmPosterComponent"
                              data-film-id="405546"
                              data-film-name="22 July"
                              data-poster-url="/film/22-july/image-150/"
                              data-film-release-year="2018"
                              data-new-list-with-film-action="/list/new/with/22-july/"
                              data-remove-from-watchlist-action="/film/22-july/remove-from-watchlist/"
                              data-add-to-watchlist-action="/film/22-july/add-to-watchlist/"
                              data-rate-action="/film/22-july/rate/"
                              data-mark-as-watched-action="/film/22-july/mark-as-watched/"
                              data-mark-as-not-watched-action="/film/22-july/mark-as-not-watched/"
                              data-film-link="/film/22-july/"
                            >
                              <div>
                                <img
                                  src="https://a.ltrbxd.com/resized/film-poster/4/0/5/5/4/6/405546-22-july-0-70-0-105-crop.jpg?k=1730b337ef"
                                  width="70"
                                  height="105"
                                  alt="22 July"
                                  srcset="https://a.ltrbxd.com/resized/film-poster/4/0/5/5/4/6/405546-22-july-0-140-0-210-crop.jpg?k=1730b337ef 2x"
                                  className="image"
                                />
                                <span className="frame">
                                  <span className="frame-title">
                                    22 July (2018)
                                  </span>
                                </span>
                              </div>
                            </li>

                            <li
                              className="react-component poster film-poster film-poster-222936 listitem"
                              data-component-className="globals.comps.FilmPosterComponent"
                              data-film-id="222936"
                              data-film-name="23 Blast"
                              data-poster-url="/film/23-blast/image-150/"
                              data-film-release-year="2014"
                              data-new-list-with-film-action="/list/new/with/23-blast/"
                              data-remove-from-watchlist-action="/film/23-blast/remove-from-watchlist/"
                              data-add-to-watchlist-action="/film/23-blast/add-to-watchlist/"
                              data-rate-action="/film/23-blast/rate/"
                              data-mark-as-watched-action="/film/23-blast/mark-as-watched/"
                              data-mark-as-not-watched-action="/film/23-blast/mark-as-not-watched/"
                              data-film-link="/film/23-blast/"
                            >
                              <div>
                                <img
                                  src="https://a.ltrbxd.com/resized/film-poster/2/2/2/9/3/6/222936-23-blast-0-70-0-105-crop.jpg?k=b6f956610f"
                                  width="70"
                                  height="105"
                                  alt="23 Blast"
                                  srcset="https://a.ltrbxd.com/resized/film-poster/2/2/2/9/3/6/222936-23-blast-0-140-0-210-crop.jpg?k=30068a11b6 2x"
                                  className="image"
                                />
                                <span className="frame">
                                  <span className="frame-title">
                                    23 Blast (2014)
                                  </span>
                                </span>
                              </div>
                            </li>

                            <li
                              className="react-component poster film-poster film-poster-58299 listitem"
                              data-component-className="globals.comps.FilmPosterComponent"
                              data-film-id="58299"
                              data-film-name="23 Paces to Baker Street"
                              data-poster-url="/film/23-paces-to-baker-street/image-150/"
                              data-film-release-year="1956"
                              data-new-list-with-film-action="/list/new/with/23-paces-to-baker-street/"
                              data-remove-from-watchlist-action="/film/23-paces-to-baker-street/remove-from-watchlist/"
                              data-add-to-watchlist-action="/film/23-paces-to-baker-street/add-to-watchlist/"
                              data-rate-action="/film/23-paces-to-baker-street/rate/"
                              data-mark-as-watched-action="/film/23-paces-to-baker-street/mark-as-watched/"
                              data-mark-as-not-watched-action="/film/23-paces-to-baker-street/mark-as-not-watched/"
                              data-film-link="/film/23-paces-to-baker-street/"
                            >
                              <div>
                                <img
                                  src="https://a.ltrbxd.com/resized/film-poster/5/8/2/9/9/58299-23-paces-to-baker-street-0-70-0-105-crop.jpg?k=f77796c733"
                                  width="70"
                                  height="105"
                                  alt="23 Paces to Baker Street"
                                  srcset="https://a.ltrbxd.com/resized/film-poster/5/8/2/9/9/58299-23-paces-to-baker-street-0-140-0-210-crop.jpg?k=c8c73c2d8a 2x"
                                  className="image"
                                />
                                <span className="frame">
                                  <span className="frame-title">
                                    23 Paces to Baker Street (1956)
                                  </span>
                                </span>
                              </div>
                            </li>
                          </ul>
                        </div>
                        <span className="overlay"></span>
                      </a>

                      <h3 className="title-3 prettify">
                        {" "}
                        <a href="/kurumaisu/list/disabled-life-on-film/">
                          Disabled Life on Film
                        </a>{" "}
                      </h3>

                      <div className="attribution-block">
                        <a
                          className="avatar -a16"
                          href="/kurumaisu/"
                          data-original-title=""
                        >
                          {" "}
                          <img
                            src="https://a.ltrbxd.com/resized/avatar/twitter/2/0/1/0/6/4/shard/http___pbs.twimg.com_profile_images_727181946158235649_Jdan8lbB-0-32-0-32-crop.jpg?k=7f701741e6"
                            alt="Brian Koukol ♿"
                            width="16"
                            height="16"
                          />{" "}
                        </a>

                        <p className="attribution">
                          <strong className="name">
                            <a href="/kurumaisu/">Brian Koukol ♿</a>
                          </strong>
                          <small className="value">1,003&nbsp;films</small>
                        </p>
                      </div>
                    </section>

                    <section
                      className="list -overlapped -stacked list-stacked-narrow -ellipsis-230"
                      data-film-list-id="18601090"
                      data-person="lancestlaurent"
                    >
                      <a
                        href="/lancestlaurent/list/oh-shit-matt-damons-in-this/"
                        className="list-link"
                      >
                        <div className="list-link-stacked clear">
                          <ul className="poster-list -overlapped -p70">
                            <li
                              className="react-component poster film-poster film-poster-50387 listitem"
                              data-component-className="globals.comps.FilmPosterComponent"
                              data-film-id="50387"
                              data-film-name="Chasing Amy"
                              data-poster-url="/film/chasing-amy/image-150/"
                              data-film-release-year="1997"
                              data-new-list-with-film-action="/list/new/with/chasing-amy/"
                              data-remove-from-watchlist-action="/film/chasing-amy/remove-from-watchlist/"
                              data-add-to-watchlist-action="/film/chasing-amy/add-to-watchlist/"
                              data-rate-action="/film/chasing-amy/rate/"
                              data-mark-as-watched-action="/film/chasing-amy/mark-as-watched/"
                              data-mark-as-not-watched-action="/film/chasing-amy/mark-as-not-watched/"
                              data-film-link="/film/chasing-amy/"
                            >
                              <div>
                                <img
                                  src="https://a.ltrbxd.com/resized/film-poster/5/0/3/8/7/50387-chasing-amy-0-70-0-105-crop.jpg?k=ccbfc7a4aa"
                                  width="70"
                                  height="105"
                                  alt="Chasing Amy"
                                  srcset="https://a.ltrbxd.com/resized/film-poster/5/0/3/8/7/50387-chasing-amy-0-140-0-210-crop.jpg?k=23ddeca690 2x"
                                  className="image"
                                />
                                <span className="frame">
                                  <span className="frame-title">
                                    Chasing Amy (1997)
                                  </span>
                                </span>
                              </div>
                            </li>

                            <li
                              className="react-component poster film-poster film-poster-47544 listitem"
                              data-component-className="globals.comps.FilmPosterComponent"
                              data-film-id="47544"
                              data-film-name="Che: Part Two"
                              data-poster-url="/film/che-part-two/image-150/"
                              data-film-release-year="2008"
                              data-new-list-with-film-action="/list/new/with/che-part-two/"
                              data-remove-from-watchlist-action="/film/che-part-two/remove-from-watchlist/"
                              data-add-to-watchlist-action="/film/che-part-two/add-to-watchlist/"
                              data-rate-action="/film/che-part-two/rate/"
                              data-mark-as-watched-action="/film/che-part-two/mark-as-watched/"
                              data-mark-as-not-watched-action="/film/che-part-two/mark-as-not-watched/"
                              data-film-link="/film/che-part-two/"
                            >
                              <div>
                                <img
                                  src="https://a.ltrbxd.com/resized/sm/upload/ro/pp/41/2a/che-2-0-70-0-105-crop.jpg?k=1a619ffe5f"
                                  width="70"
                                  height="105"
                                  alt="Che: Part Two"
                                  srcset="https://a.ltrbxd.com/resized/sm/upload/ro/pp/41/2a/che-2-0-140-0-210-crop.jpg?k=877fb29834 2x"
                                  className="image"
                                />
                                <span className="frame">
                                  <span className="frame-title">
                                    Che: Part Two (2008)
                                  </span>
                                </span>
                              </div>
                            </li>

                            <li
                              className="react-component poster film-poster film-poster-49081 listitem"
                              data-component-className="globals.comps.FilmPosterComponent"
                              data-film-id="49081"
                              data-film-name="Confessions of a Dangerous Mind"
                              data-poster-url="/film/confessions-of-a-dangerous-mind/image-150/"
                              data-film-release-year="2002"
                              data-new-list-with-film-action="/list/new/with/confessions-of-a-dangerous-mind/"
                              data-remove-from-watchlist-action="/film/confessions-of-a-dangerous-mind/remove-from-watchlist/"
                              data-add-to-watchlist-action="/film/confessions-of-a-dangerous-mind/add-to-watchlist/"
                              data-rate-action="/film/confessions-of-a-dangerous-mind/rate/"
                              data-mark-as-watched-action="/film/confessions-of-a-dangerous-mind/mark-as-watched/"
                              data-mark-as-not-watched-action="/film/confessions-of-a-dangerous-mind/mark-as-not-watched/"
                              data-film-link="/film/confessions-of-a-dangerous-mind/"
                            >
                              <div>
                                <img
                                  src="https://a.ltrbxd.com/resized/sm/upload/wa/he/ph/5s/o3Im9nPLAgtlw1j2LtpMebAotSe-0-70-0-105-crop.jpg?k=90374bdd60"
                                  width="70"
                                  height="105"
                                  alt="Confessions of a Dangerous Mind"
                                  srcset="https://a.ltrbxd.com/resized/sm/upload/wa/he/ph/5s/o3Im9nPLAgtlw1j2LtpMebAotSe-0-140-0-210-crop.jpg?k=e9bf4c0495 2x"
                                  className="image"
                                />
                                <span className="frame">
                                  <span className="frame-title">
                                    Confessions of a Dangerous Mind (2002)
                                  </span>
                                </span>
                              </div>
                            </li>
                            <li
                              className="react-component poster film-poster film-poster-318195 listitem"
                              data-component-className="globals.comps.FilmPosterComponent"
                              data-film-id="318195"
                              data-film-name="Deadpool 2"
                              data-poster-url="/film/deadpool-2/image-150/"
                              data-film-release-year="2018"
                              data-new-list-with-film-action="/list/new/with/deadpool-2/"
                              data-remove-from-watchlist-action="/film/deadpool-2/remove-from-watchlist/"
                              data-add-to-watchlist-action="/film/deadpool-2/add-to-watchlist/"
                              data-rate-action="/film/deadpool-2/rate/"
                              data-mark-as-watched-action="/film/deadpool-2/mark-as-watched/"
                              data-mark-as-not-watched-action="/film/deadpool-2/mark-as-not-watched/"
                              data-film-link="/film/deadpool-2/"
                            >
                              <div>
                                <img
                                  src="https://a.ltrbxd.com/resized/film-poster/3/1/8/1/9/5/318195-deadpool-2-0-70-0-105-crop.jpg?k=6f80d30527"
                                  width="70"
                                  height="105"
                                  alt="Deadpool 2"
                                  srcset="https://a.ltrbxd.com/resized/film-poster/3/1/8/1/9/5/318195-deadpool-2-0-140-0-210-crop.jpg?k=6f80d30527 2x"
                                  className="image"
                                />
                                <span className="frame">
                                  <span className="frame-title">
                                    Deadpool 2 (2018)
                                  </span>
                                </span>
                              </div>
                            </li>

                            <li
                              className="react-component poster film-poster film-poster-47243 listitem"
                              data-component-className="globals.comps.FilmPosterComponent"
                              data-film-id="47243"
                              data-film-name="EuroTrip"
                              data-poster-url="/film/eurotrip/image-150/"
                              data-film-release-year="2004"
                              data-new-list-with-film-action="/list/new/with/eurotrip/"
                              data-remove-from-watchlist-action="/film/eurotrip/remove-from-watchlist/"
                              data-add-to-watchlist-action="/film/eurotrip/add-to-watchlist/"
                              data-rate-action="/film/eurotrip/rate/"
                              data-mark-as-watched-action="/film/eurotrip/mark-as-watched/"
                              data-mark-as-not-watched-action="/film/eurotrip/mark-as-not-watched/"
                              data-film-link="/film/eurotrip/"
                            >
                              <div>
                                <img
                                  src="https://a.ltrbxd.com/resized/film-poster/4/7/2/4/3/47243-eurotrip-0-70-0-105-crop.jpg?k=6bb2f7ffdd"
                                  width="70"
                                  height="105"
                                  alt="EuroTrip"
                                  srcset="https://a.ltrbxd.com/resized/film-poster/4/7/2/4/3/47243-eurotrip-0-140-0-210-crop.jpg?k=02a0da800e 2x"
                                  className="image"
                                />
                                <span className="frame">
                                  <span className="frame-title">
                                    EuroTrip (2004)
                                  </span>
                                </span>
                              </div>
                            </li>
                          </ul>
                        </div>
                        <span className="overlay"></span>
                      </a>

                      <h3 className="title-3 prettify">
                        {" "}
                        <a href="/lancestlaurent/list/oh-shit-matt-damons-in-this/">
                          “Oh shit, Matt Damon’s in this?”
                        </a>{" "}
                      </h3>

                      <div className="attribution-block">
                        <a
                          className="avatar -a16"
                          href="/lancestlaurent/"
                          data-original-title=""
                        >
                          {" "}
                          <img
                            src="https://a.ltrbxd.com/resized/avatar/twitter/6/1/1/1/1/shard/http___pbs.twimg.com_profile_images_1361494416863731714_cEyMVD1Y-0-32-0-32-crop.jpg?k=43a6c2e8c3"
                            alt="Lance St. Laurent"
                            width="16"
                            height="16"
                          />{" "}
                        </a>

                        <p className="attribution">
                          <strong className="name">
                            <a href="/lancestlaurent/">Lance St. Laurent</a>
                          </strong>
                          <small className="value">16&nbsp;films</small>
                        </p>
                      </div>
                    </section>

                    <section
                      className="list -overlapped -stacked list-stacked-narrow -ellipsis-230"
                      data-film-list-id="18555793"
                      data-person="mh83"
                    >
                      <a
                        href="/mh83/list/films-mentioned-in-quentin-tarantinos-once/"
                        className="list-link"
                      >
                        <div className="list-link-stacked clear">
                          <ul className="poster-list -overlapped -p70">
                            <li
                              className="react-component poster film-poster film-poster-17114 listitem"
                              data-component-className="globals.comps.FilmPosterComponent"
                              data-film-id="17114"
                              data-film-name="Battle of the Coral Sea"
                              data-poster-url="/film/battle-of-the-coral-sea/image-150/"
                              data-film-release-year="1959"
                              data-new-list-with-film-action="/list/new/with/battle-of-the-coral-sea/"
                              data-remove-from-watchlist-action="/film/battle-of-the-coral-sea/remove-from-watchlist/"
                              data-add-to-watchlist-action="/film/battle-of-the-coral-sea/add-to-watchlist/"
                              data-rate-action="/film/battle-of-the-coral-sea/rate/"
                              data-mark-as-watched-action="/film/battle-of-the-coral-sea/mark-as-watched/"
                              data-mark-as-not-watched-action="/film/battle-of-the-coral-sea/mark-as-not-watched/"
                              data-film-link="/film/battle-of-the-coral-sea/"
                            >
                              <div>
                                <img
                                  src="https://a.ltrbxd.com/resized/film-poster/1/7/1/1/4/17114-battle-of-the-coral-sea-0-70-0-105-crop.jpg?k=bfd0ade550"
                                  width="70"
                                  height="105"
                                  alt="Battle of the Coral Sea"
                                  srcset="https://a.ltrbxd.com/resized/film-poster/1/7/1/1/4/17114-battle-of-the-coral-sea-0-140-0-210-crop.jpg?k=24f946a475 2x"
                                  className="image"
                                />
                                <span className="frame">
                                  <span className="frame-title">
                                    Battle of the Coral Sea (1959)
                                  </span>
                                </span>
                              </div>
                            </li>

                            <li
                              className="react-component poster film-poster film-poster-22026 listitem"
                              data-component-className="globals.comps.FilmPosterComponent"
                              data-film-id="22026"
                              data-film-name="Gidget"
                              data-poster-url="/film/gidget/image-150/"
                              data-film-release-year="1959"
                              data-new-list-with-film-action="/list/new/with/gidget/"
                              data-remove-from-watchlist-action="/film/gidget/remove-from-watchlist/"
                              data-add-to-watchlist-action="/film/gidget/add-to-watchlist/"
                              data-rate-action="/film/gidget/rate/"
                              data-mark-as-watched-action="/film/gidget/mark-as-watched/"
                              data-mark-as-not-watched-action="/film/gidget/mark-as-not-watched/"
                              data-film-link="/film/gidget/"
                            >
                              <div>
                                <img
                                  src="https://a.ltrbxd.com/resized/film-poster/2/2/0/2/6/22026-gidget-0-70-0-105-crop.jpg?k=d5b6d81ecd"
                                  width="70"
                                  height="105"
                                  alt="Gidget"
                                  srcset="https://a.ltrbxd.com/resized/film-poster/2/2/0/2/6/22026-gidget-0-140-0-210-crop.jpg?k=869cefe2be 2x"
                                  className="image"
                                />
                                <span className="frame">
                                  <span className="frame-title">
                                    Gidget (1959)
                                  </span>
                                </span>
                              </div>
                            </li>
                            <li
                              className="react-component poster film-poster film-poster-51215 listitem"
                              data-component-className="globals.comps.FilmPosterComponent"
                              data-film-id="51215"
                              data-film-name="For a Few Dollars More"
                              data-poster-url="/film/for-a-few-dollars-more/image-150/"
                              data-film-release-year="1965"
                              data-new-list-with-film-action="/list/new/with/for-a-few-dollars-more/"
                              data-remove-from-watchlist-action="/film/for-a-few-dollars-more/remove-from-watchlist/"
                              data-add-to-watchlist-action="/film/for-a-few-dollars-more/add-to-watchlist/"
                              data-rate-action="/film/for-a-few-dollars-more/rate/"
                              data-mark-as-watched-action="/film/for-a-few-dollars-more/mark-as-watched/"
                              data-mark-as-not-watched-action="/film/for-a-few-dollars-more/mark-as-not-watched/"
                              data-film-link="/film/for-a-few-dollars-more/"
                            >
                              <div>
                                <img
                                  src="https://a.ltrbxd.com/resized/sm/upload/bt/gp/10/ue/for-a-few-dollars-more-0-70-0-105-crop.jpg?k=d673e00c89"
                                  width="70"
                                  height="105"
                                  alt="For a Few Dollars More"
                                  srcset="https://a.ltrbxd.com/resized/sm/upload/bt/gp/10/ue/for-a-few-dollars-more-0-140-0-210-crop.jpg?k=4abd7bc3b6 2x"
                                  className="image"
                                />
                                <span className="frame">
                                  <span className="frame-title">
                                    For a Few Dollars More (1965)
                                  </span>
                                </span>
                              </div>
                            </li>

                            <li
                              className="react-component poster film-poster film-poster-51174 listitem"
                              data-component-className="globals.comps.FilmPosterComponent"
                              data-film-id="51174"
                              data-film-name="Stagecoach"
                              data-poster-url="/film/stagecoach/image-150/"
                              data-film-release-year="1939"
                              data-new-list-with-film-action="/list/new/with/stagecoach/"
                              data-remove-from-watchlist-action="/film/stagecoach/remove-from-watchlist/"
                              data-add-to-watchlist-action="/film/stagecoach/add-to-watchlist/"
                              data-rate-action="/film/stagecoach/rate/"
                              data-mark-as-watched-action="/film/stagecoach/mark-as-watched/"
                              data-mark-as-not-watched-action="/film/stagecoach/mark-as-not-watched/"
                              data-film-link="/film/stagecoach/"
                            >
                              <div>
                                <img
                                  src="https://a.ltrbxd.com/resized/film-poster/5/1/1/7/4/51174-stagecoach-0-70-0-105-crop.jpg?k=29a4df9797"
                                  width="70"
                                  height="105"
                                  alt="Stagecoach"
                                  srcset="https://a.ltrbxd.com/resized/film-poster/5/1/1/7/4/51174-stagecoach-0-140-0-210-crop.jpg?k=95101eb7d0 2x"
                                  className="image"
                                />
                                <span className="frame">
                                  <span className="frame-title">
                                    Stagecoach (1939)
                                  </span>
                                </span>
                              </div>
                            </li>

                            <li
                              className="react-component poster film-poster film-poster-45199 listitem"
                              data-component-className="globals.comps.FilmPosterComponent"
                              data-film-id="45199"
                              data-film-name="Invasion of the Body Snatchers"
                              data-poster-url="/film/invasion-of-the-body-snatchers/image-150/"
                              data-film-release-year="1956"
                              data-new-list-with-film-action="/list/new/with/invasion-of-the-body-snatchers/"
                              data-remove-from-watchlist-action="/film/invasion-of-the-body-snatchers/remove-from-watchlist/"
                              data-add-to-watchlist-action="/film/invasion-of-the-body-snatchers/add-to-watchlist/"
                              data-rate-action="/film/invasion-of-the-body-snatchers/rate/"
                              data-mark-as-watched-action="/film/invasion-of-the-body-snatchers/mark-as-watched/"
                              data-mark-as-not-watched-action="/film/invasion-of-the-body-snatchers/mark-as-not-watched/"
                              data-film-link="/film/invasion-of-the-body-snatchers/"
                            >
                              <div>
                                <img
                                  src="https://a.ltrbxd.com/resized/film-poster/4/5/1/9/9/45199-invasion-of-the-body-snatchers-0-70-0-105-crop.jpg?k=b642a44a75"
                                  width="70"
                                  height="105"
                                  alt="Invasion of the Body Snatchers"
                                  srcset="https://a.ltrbxd.com/resized/film-poster/4/5/1/9/9/45199-invasion-of-the-body-snatchers-0-140-0-210-crop.jpg?k=0b207db03b 2x"
                                  className="image"
                                />
                                <span className="frame">
                                  <span className="frame-title">
                                    Invasion of the Body Snatchers (1956)
                                  </span>
                                </span>
                              </div>
                            </li>
                          </ul>
                        </div>
                        <span className="overlay"></span>
                      </a>

                      <h3 className="title-3 prettify">
                        {" "}
                        <a href="/mh83/list/films-mentioned-in-quentin-tarantinos-once/">
                          Films Mentioned In Quentin Tarantino’s Once Upon A
                          Time In Hollywood Novel
                        </a>{" "}
                      </h3>

                      <div className="attribution-block">
                        <a
                          className="avatar -a16"
                          href="/mh83/"
                          data-original-title=""
                        >
                          {" "}
                          <img
                            src="https://a.ltrbxd.com/resized/avatar/twitter/2/1/2/3/0/1/6/shard/http___pbs.twimg.com_profile_images_1192572856246427648_pB15TVhd-0-32-0-32-crop.jpg?k=a7fd2f9526"
                            alt="Meesh"
                            width="16"
                            height="16"
                          />{" "}
                        </a>

                        <p className="attribution">
                          <strong className="name">
                            <a href="/mh83/">Meesh</a>
                          </strong>

                          <small className="value">143&nbsp;films</small>
                        </p>
                      </div>
                    </section>
                  </div>
                </section>
                <section className="section">
                  <h2 className="section-heading">Popular tags</h2>

                  <ul className="tags">
                    <li>
                      <a href="/tag/ranked/lists/">ranked</a>
                    </li>

                    <li>
                      <a href="/tag/director/lists/">director</a>
                    </li>

                    <li>
                      <a href="/tag/allstats/lists/">allstats</a>
                    </li>

                    <li>
                      <a href="/tag/top-10/lists/">top-10</a>
                    </li>

                    <li>
                      <a href="/tag/horror/lists/">horror</a>
                    </li>

                    <li>
                      <a href="/tag/mexico/lists/">mexico</a>
                    </li>

                    <li>
                      <a href="/tag/watchlist/lists/">watchlist</a>
                    </li>

                    <li>
                      <a href="/tag/2021/lists/">2021</a>
                    </li>

                    <li>
                      <a href="/tag/directors/lists/">directors</a>
                    </li>

                    <li>
                      <a href="/tag/cannes/lists/">cannes</a>
                    </li>

                    <li>
                      <a href="/tag/ranking/lists/">ranking</a>
                    </li>

                    <li>
                      <a href="/tag/topstats/lists/">topstats</a>
                    </li>

                    <li>
                      <a href="/tag/yir2021/lists/">yir2021</a>
                    </li>

                    <li>
                      <a href="/tag/favorites/lists/">favorites</a>
                    </li>

                    <li>
                      <a href="/tag/directors-ranked/lists/">
                        directors-ranked
                      </a>
                    </li>

                    <li>
                      <a href="/tag/movies/lists/">movies</a>
                    </li>

                    <li>
                      <a href="/tag/marvel/lists/">marvel</a>
                    </li>

                    <li>
                      <a href="/tag/mcu/lists/">mcu</a>
                    </li>

                    <li>
                      <a href="/tag/films/lists/">films</a>
                    </li>

                    <li>
                      <a href="/tag/list/lists/">list</a>
                    </li>

                    <li>
                      <a href="/tag/animation/lists/">animation</a>
                    </li>

                    <li>
                      <a href="/tag/top2021/lists/">top2021</a>
                    </li>

                    <li>
                      <a href="/tag/director-rankings/lists/">
                        director-rankings
                      </a>
                    </li>

                    <li>
                      <a href="/tag/other-people-s-lists/lists/">
                        other-people-s-lists
                      </a>
                    </li>

                    <li>
                      <a href="/tag/vibes/lists/">vibes</a>
                    </li>

                    <li>
                      <a href="/tag/disney/lists/">disney</a>
                    </li>

                    <li>
                      <a href="/tag/year-rankings/lists/">year-rankings</a>
                    </li>

                    <li>
                      <a href="/tag/top/lists/">top</a>
                    </li>

                    <li>
                      <a href="/tag/criterion/lists/">criterion</a>
                    </li>

                    <li>
                      <a href="/tag/scavenger-hunt/lists/">scavenger-hunt</a>
                    </li>

                    <li>
                      <a href="/tag/comedy/lists/">comedy</a>
                    </li>

                    <li>
                      <a href="/tag/best/lists/">best</a>
                    </li>

                    <li>
                      <a href="/tag/owned/lists/">owned</a>
                    </li>

                    <li>
                      <a href="/tag/franchise/lists/">franchise</a>
                    </li>

                    <li>
                      <a href="/tag/action/lists/">action</a>
                    </li>

                    <li>
                      <a href="/tag/thriller/lists/">thriller</a>
                    </li>

                    <li>
                      <a href="/tag/private-ownership/lists/">
                        private-ownership
                      </a>
                    </li>

                    <li>
                      <a href="/tag/vinzator/lists/">vinzator</a>
                    </li>

                    <li>
                      <a href="/tag/metrics/lists/">metrics</a>
                    </li>

                    <li>
                      <a href="/tag/genre/lists/">genre</a>
                    </li>

                    <li>
                      <a href="/tag/scavenger-hunt-77/lists/">
                        scavenger-hunt-77
                      </a>
                    </li>

                    <li>
                      <a href="/tag/year/lists/">year</a>
                    </li>

                    <li>
                      <a href="/tag/own/lists/">own</a>
                    </li>

                    <li>
                      <a href="/tag/anime/lists/">anime</a>
                    </li>

                    <li>
                      <a href="/tag/watchlists/lists/">watchlists</a>
                    </li>

                    <li>
                      <a href="/tag/shares/lists/">shares</a>
                    </li>

                    <li>
                      <a href="/tag/drama/lists/">drama</a>
                    </li>

                    <li>
                      <a href="/tag/romance/lists/">romance</a>
                    </li>

                    <li>
                      <a href="/tag/completed-collections/lists/">
                        completed-collections
                      </a>
                    </li>

                    <li>
                      <a href="/tag/2010s/lists/">2010s</a>
                    </li>
                  </ul>
                </section>
              </aside>
            </div>
            <section className="section">
              <h2 className="section-heading -spaced">
                <a href="/showdown/">Recent Showdowns</a>
              </h2>
              <a href="/showdown/" className="all-link">
                More
              </a>
              <div className="teaser-grid -singlerow">
                <section className="content-teaser -stacked">
                  <div className="teaser-media">
                    <a className="image" href="/showdown/fear-street/">
                      <img
                        src="https://a.ltrbxd.com/resized/sm/upload/qb/ek/6f/db/i-know-what-you-did-last-summer_8c7ff214-310-310-174-174-crop-fill.jpg?k=76c193d104"
                        srcset="https://a.ltrbxd.com/resized/sm/upload/qb/ek/6f/db/i-know-what-you-did-last-summer_8c7ff214-310-310-174-174-crop-fill.jpg?k=76c193d104 310w, https://a.ltrbxd.com/resized/sm/upload/qb/ek/6f/db/i-know-what-you-did-last-summer_8c7ff214-620-620-348-348-crop-fill.jpg?k=76c193d104 620w"
                        width="310"
                        height="174"
                        alt=""
                      />
                    </a>
                  </div>
                  <div className="body-text">
                    <h3 className="title-2">
                      <a href="/showdown/fear-street/">Fear Street</a>
                    </h3>
                    <h4 className="body-text">Best nineties slasher films</h4>
                  </div>
                </section>

                <section className="content-teaser -stacked">
                  <div className="teaser-media">
                    <a className="image" href="/showdown/knocked-up/">
                      <img
                        src="https://a.ltrbxd.com/resized/sm/upload/n1/7e/nn/9r/false-positive-310-310-174-174-crop-fill.jpg?k=3a25b0ad50"
                        srcset="https://a.ltrbxd.com/resized/sm/upload/n1/7e/nn/9r/false-positive-310-310-174-174-crop-fill.jpg?k=3a25b0ad50 310w, https://a.ltrbxd.com/resized/sm/upload/n1/7e/nn/9r/false-positive-620-620-348-348-crop-fill.jpg?k=442900b296 620w"
                        width="310"
                        height="174"
                        alt=""
                      />
                    </a>
                  </div>
                  <div className="body-text">
                    <h3 className="title-2">
                      <a href="/showdown/knocked-up/">Knocked Up</a>
                    </h3>
                    <h4 className="body-text">Best films about babies</h4>
                  </div>
                </section>

                <section className="content-teaser -stacked">
                  <div className="teaser-media">
                    <a className="image" href="/showdown/all-the-right-moves/">
                      <img
                        src="https://a.ltrbxd.com/resized/sm/upload/pe/a2/h5/wn/band-wagon-310-310-174-174-crop-fill.jpg?k=784e5e316f"
                        srcset="https://a.ltrbxd.com/resized/sm/upload/pe/a2/h5/wn/band-wagon-310-310-174-174-crop-fill.jpg?k=784e5e316f 310w, https://a.ltrbxd.com/resized/sm/upload/pe/a2/h5/wn/band-wagon-620-620-348-348-crop-fill.jpg?k=07fd5253b8 620w"
                        width="310"
                        height="174"
                        alt=""
                      />
                    </a>
                  </div>
                  <div className="body-text">
                    <h3 className="title-2">
                      <a href="/showdown/all-the-right-moves/">
                        All the Right Moves
                      </a>
                    </h3>
                    <h4 className="body-text">Best dancing in film</h4>
                  </div>
                </section>
              </div>
            </section>
            <section id="crew-lists" className="section">
              <h2 className="section-heading -spaced">Crew lists</h2>
              <a href="/crew/lists/" className="all-link">
                More
              </a>
              <div className="list-grid -singlerow">
                {/* <!-- user will always be null in prod due to varnish --> */}
                <section
                  className="list -overlapped -stacked list -overlapped -stacked"
                  data-film-list-id="18940551"
                  data-person="crew"
                >
                  <a
                    href="/crew/list/showdown-fear-street/"
                    className="list-link"
                  >
                    <div className="list-link-stacked clear">
                      <ul className="poster-list -overlapped -p70">
                        <li
                          className="react-component poster film-poster film-poster-49455 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="49455"
                          data-film-name="Scream"
                          data-poster-url="/film/scream/image-150/"
                          data-film-release-year="1996"
                          data-new-list-with-film-action="/list/new/with/scream/"
                          data-remove-from-watchlist-action="/film/scream/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/scream/add-to-watchlist/"
                          data-rate-action="/film/scream/rate/"
                          data-mark-as-watched-action="/film/scream/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/scream/mark-as-not-watched/"
                          data-film-link="/film/scream/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/film-poster/4/9/4/5/5/49455-scream-0-70-0-105-crop.jpg?k=534b854dff"
                              width="70"
                              height="105"
                              alt="Scream"
                              srcset="https://a.ltrbxd.com/resized/film-poster/4/9/4/5/5/49455-scream-0-140-0-210-crop.jpg?k=534b854dff 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">Scream (1996)</span>
                            </span>
                          </div>
                        </li>

                        <li
                          className="react-component poster film-poster film-poster-47071 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="47071"
                          data-film-name="Candyman"
                          data-poster-url="/film/candyman/image-150/"
                          data-film-release-year="1992"
                          data-new-list-with-film-action="/list/new/with/candyman/"
                          data-remove-from-watchlist-action="/film/candyman/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/candyman/add-to-watchlist/"
                          data-rate-action="/film/candyman/rate/"
                          data-mark-as-watched-action="/film/candyman/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/candyman/mark-as-not-watched/"
                          data-film-link="/film/candyman/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/sm/upload/hs/ok/6b/1z/w5YQqrwzreHfa7RmXCB7rpLLxbe-0-70-0-105-crop.jpg?k=e7c4d29c44"
                              width="70"
                              height="105"
                              alt="Candyman"
                              srcset="https://a.ltrbxd.com/resized/sm/upload/hs/ok/6b/1z/w5YQqrwzreHfa7RmXCB7rpLLxbe-0-140-0-210-crop.jpg?k=32ead6eed0 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                Candyman (1992)
                              </span>
                            </span>
                          </div>
                        </li>

                        <li
                          className="react-component poster film-poster film-poster-49454 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="49454"
                          data-film-name="Scream 2"
                          data-poster-url="/film/scream-2/image-150/"
                          data-film-release-year="1997"
                          data-new-list-with-film-action="/list/new/with/scream-2/"
                          data-remove-from-watchlist-action="/film/scream-2/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/scream-2/add-to-watchlist/"
                          data-rate-action="/film/scream-2/rate/"
                          data-mark-as-watched-action="/film/scream-2/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/scream-2/mark-as-not-watched/"
                          data-film-link="/film/scream-2/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/sm/upload/ju/sr/4r/t3/c5AyWNWooMGkJXlqLwmPQCjUwHt-0-70-0-105-crop.jpg?k=9a2342af1a"
                              width="70"
                              height="105"
                              alt="Scream 2"
                              srcset="https://a.ltrbxd.com/resized/sm/upload/ju/sr/4r/t3/c5AyWNWooMGkJXlqLwmPQCjUwHt-0-140-0-210-crop.jpg?k=d858e4f4d1 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                Scream 2 (1997)
                              </span>
                            </span>
                          </div>
                        </li>

                        <li
                          className="react-component poster film-poster film-poster-49638 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="49638"
                          data-film-name="I Know What You Did Last Summer"
                          data-poster-url="/film/i-know-what-you-did-last-summer/image-150/"
                          data-film-release-year="1997"
                          data-new-list-with-film-action="/list/new/with/i-know-what-you-did-last-summer/"
                          data-remove-from-watchlist-action="/film/i-know-what-you-did-last-summer/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/i-know-what-you-did-last-summer/add-to-watchlist/"
                          data-rate-action="/film/i-know-what-you-did-last-summer/rate/"
                          data-mark-as-watched-action="/film/i-know-what-you-did-last-summer/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/i-know-what-you-did-last-summer/mark-as-not-watched/"
                          data-film-link="/film/i-know-what-you-did-last-summer/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/film-poster/4/9/6/3/8/49638-i-know-what-you-did-last-summer-0-70-0-105-crop.jpg?k=fa8679a2ec"
                              width="70"
                              height="105"
                              alt="I Know What You Did Last Summer"
                              srcset="https://a.ltrbxd.com/resized/film-poster/4/9/6/3/8/49638-i-know-what-you-did-last-summer-0-140-0-210-crop.jpg?k=ee3b2f6506 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                I Know What You Did Last Summer (1997)
                              </span>
                            </span>
                          </div>
                        </li>

                        <li
                          className="react-component poster film-poster film-poster-45154 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="45154"
                          data-film-name="New Nightmare"
                          data-poster-url="/film/new-nightmare/image-150/"
                          data-film-release-year="1994"
                          data-new-list-with-film-action="/list/new/with/new-nightmare/"
                          data-remove-from-watchlist-action="/film/new-nightmare/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/new-nightmare/add-to-watchlist/"
                          data-rate-action="/film/new-nightmare/rate/"
                          data-mark-as-watched-action="/film/new-nightmare/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/new-nightmare/mark-as-not-watched/"
                          data-film-link="/film/new-nightmare/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/film-poster/4/5/1/5/4/45154-new-nightmare-0-70-0-105-crop.jpg?k=b173bfec5b"
                              width="70"
                              height="105"
                              alt="New Nightmare"
                              srcset="https://a.ltrbxd.com/resized/film-poster/4/5/1/5/4/45154-new-nightmare-0-140-0-210-crop.jpg?k=5c02c28b40 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                New Nightmare (1994)
                              </span>
                            </span>
                          </div>
                        </li>
                      </ul>
                    </div>
                    <span className="overlay"></span>
                  </a>

                  <h3 className="title-3 prettify">
                    {" "}
                    <a href="/crew/list/showdown-fear-street/">
                      Showdown: Fear Street
                    </a>{" "}
                  </h3>
                </section>

                <section
                  className="list -overlapped -stacked list -overlapped -stacked"
                  data-film-list-id="18937428"
                  data-person="crew"
                >
                  <a
                    href="/crew/list/the-films-that-influenced-augustine-frizzells/"
                    className="list-link"
                  >
                    <div className="list-link-stacked clear">
                      <ul className="poster-list -overlapped -p70">
                        <li
                          className="react-component poster film-poster film-poster-51309 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="51309"
                          data-film-name="In the Mood for Love"
                          data-poster-url="/film/in-the-mood-for-love/image-150/"
                          data-film-release-year="2000"
                          data-new-list-with-film-action="/list/new/with/in-the-mood-for-love/"
                          data-remove-from-watchlist-action="/film/in-the-mood-for-love/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/in-the-mood-for-love/add-to-watchlist/"
                          data-rate-action="/film/in-the-mood-for-love/rate/"
                          data-mark-as-watched-action="/film/in-the-mood-for-love/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/in-the-mood-for-love/mark-as-not-watched/"
                          data-film-link="/film/in-the-mood-for-love/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/sm/upload/g1/7l/2j/qk/tSRdvZY1waXrTeMqeLBmq9IRs08-0-70-0-105-crop.jpg?k=05b42f4fe0"
                              width="70"
                              height="105"
                              alt="In the Mood for Love"
                              srcset="https://a.ltrbxd.com/resized/sm/upload/g1/7l/2j/qk/tSRdvZY1waXrTeMqeLBmq9IRs08-0-140-0-210-crop.jpg?k=bf92a7c99a 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                In the Mood for Love (2000)
                              </span>
                            </span>
                          </div>
                        </li>

                        <li
                          className="react-component poster film-poster film-poster-51301 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="51301"
                          data-film-name="Brief Encounter"
                          data-poster-url="/film/brief-encounter/image-150/"
                          data-film-release-year="1945"
                          data-new-list-with-film-action="/list/new/with/brief-encounter/"
                          data-remove-from-watchlist-action="/film/brief-encounter/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/brief-encounter/add-to-watchlist/"
                          data-rate-action="/film/brief-encounter/rate/"
                          data-mark-as-watched-action="/film/brief-encounter/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/brief-encounter/mark-as-not-watched/"
                          data-film-link="/film/brief-encounter/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/film-poster/5/1/3/0/1/51301-brief-encounter-0-70-0-105-crop.jpg?k=5006b10e65"
                              width="70"
                              height="105"
                              alt="Brief Encounter"
                              srcset="https://a.ltrbxd.com/resized/film-poster/5/1/3/0/1/51301-brief-encounter-0-140-0-210-crop.jpg?k=f7c4365696 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                Brief Encounter (1945)
                              </span>
                            </span>
                          </div>
                        </li>

                        <li
                          className="react-component poster film-poster film-poster-335384 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="335384"
                          data-film-name="Phantom Thread"
                          data-poster-url="/film/phantom-thread/image-150/"
                          data-film-release-year="2017"
                          data-new-list-with-film-action="/list/new/with/phantom-thread/"
                          data-remove-from-watchlist-action="/film/phantom-thread/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/phantom-thread/add-to-watchlist/"
                          data-rate-action="/film/phantom-thread/rate/"
                          data-mark-as-watched-action="/film/phantom-thread/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/phantom-thread/mark-as-not-watched/"
                          data-film-link="/film/phantom-thread/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/film-poster/3/3/5/3/8/4/335384-phantom-thread-0-70-0-105-crop.jpg?k=8e58a6b114"
                              width="70"
                              height="105"
                              alt="Phantom Thread"
                              srcset="https://a.ltrbxd.com/resized/film-poster/3/3/5/3/8/4/335384-phantom-thread-0-140-0-210-crop.jpg?k=4e747cb463 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                Phantom Thread (2017)
                              </span>
                            </span>
                          </div>
                        </li>

                        <li
                          className="react-component poster film-poster film-poster-51601 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="51601"
                          data-film-name="Notting Hill"
                          data-poster-url="/film/notting-hill/image-150/"
                          data-film-release-year="1999"
                          data-new-list-with-film-action="/list/new/with/notting-hill/"
                          data-remove-from-watchlist-action="/film/notting-hill/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/notting-hill/add-to-watchlist/"
                          data-rate-action="/film/notting-hill/rate/"
                          data-mark-as-watched-action="/film/notting-hill/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/notting-hill/mark-as-not-watched/"
                          data-film-link="/film/notting-hill/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/sm/upload/pa/ej/k3/ft/notting-hill-0-70-0-105-crop.jpg?k=1f4b471e5e"
                              width="70"
                              height="105"
                              alt="Notting Hill"
                              srcset="https://a.ltrbxd.com/resized/sm/upload/pa/ej/k3/ft/notting-hill-0-140-0-210-crop.jpg?k=7f9324a805 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                Notting Hill (1999)
                              </span>
                            </span>
                          </div>
                        </li>

                        <li
                          className="react-component poster film-poster film-poster-50671 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="50671"
                          data-film-name="Bonjour Tristesse"
                          data-poster-url="/film/bonjour-tristesse/image-150/"
                          data-film-release-year="1958"
                          data-new-list-with-film-action="/list/new/with/bonjour-tristesse/"
                          data-remove-from-watchlist-action="/film/bonjour-tristesse/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/bonjour-tristesse/add-to-watchlist/"
                          data-rate-action="/film/bonjour-tristesse/rate/"
                          data-mark-as-watched-action="/film/bonjour-tristesse/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/bonjour-tristesse/mark-as-not-watched/"
                          data-film-link="/film/bonjour-tristesse/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/film-poster/5/0/6/7/1/50671-bonjour-tristesse-0-70-0-105-crop.jpg?k=6eb57166a7"
                              width="70"
                              height="105"
                              alt="Bonjour Tristesse"
                              srcset="https://a.ltrbxd.com/resized/film-poster/5/0/6/7/1/50671-bonjour-tristesse-0-140-0-210-crop.jpg?k=da770980ff 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                Bonjour Tristesse (1958)
                              </span>
                            </span>
                          </div>
                        </li>
                      </ul>
                    </div>
                    <span className="overlay"></span>
                  </a>

                  <h3 className="title-3 prettify">
                    {" "}
                    <a href="/crew/list/the-films-that-influenced-augustine-frizzells/">
                      The Films that Influenced Augustine Frizzell’s ‘The Last
                      Letter From Your Lover’
                    </a>{" "}
                  </h3>
                </section>

                <section
                  className="list -overlapped -stacked list -overlapped -stacked"
                  data-film-list-id="18889293"
                  data-person="crew"
                >
                  <a
                    href="/crew/list/the-vinzator-show-brian-formos-four-favorites/"
                    className="list-link"
                  >
                    <div className="list-link-stacked clear">
                      <ul className="poster-list -overlapped -p70">
                        <li
                          className="react-component poster film-poster film-poster-51717 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="51717"
                          data-film-name="Eyes Wide Shut"
                          data-poster-url="/film/eyes-wide-shut/image-150/"
                          data-film-release-year="1999"
                          data-new-list-with-film-action="/list/new/with/eyes-wide-shut/"
                          data-remove-from-watchlist-action="/film/eyes-wide-shut/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/eyes-wide-shut/add-to-watchlist/"
                          data-rate-action="/film/eyes-wide-shut/rate/"
                          data-mark-as-watched-action="/film/eyes-wide-shut/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/eyes-wide-shut/mark-as-not-watched/"
                          data-film-link="/film/eyes-wide-shut/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/sm/upload/td/om/t8/dh/c8X6UIbzbhBBuyuHRrzVzaCMbkZ-0-70-0-105-crop.jpg?k=999b40c36d"
                              width="70"
                              height="105"
                              alt="Eyes Wide Shut"
                              srcset="https://a.ltrbxd.com/resized/sm/upload/td/om/t8/dh/c8X6UIbzbhBBuyuHRrzVzaCMbkZ-0-140-0-210-crop.jpg?k=669a2354b0 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                Eyes Wide Shut (1999)
                              </span>
                            </span>
                          </div>
                        </li>

                        <li
                          className="react-component poster film-poster film-poster-47671 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="47671"
                          data-film-name="Master and Commander: The Far Side of the World"
                          data-poster-url="/film/master-and-commander-the-far-side-of-the-world/image-150/"
                          data-film-release-year="2003"
                          data-new-list-with-film-action="/list/new/with/master-and-commander-the-far-side-of-the-world/"
                          data-remove-from-watchlist-action="/film/master-and-commander-the-far-side-of-the-world/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/master-and-commander-the-far-side-of-the-world/add-to-watchlist/"
                          data-rate-action="/film/master-and-commander-the-far-side-of-the-world/rate/"
                          data-mark-as-watched-action="/film/master-and-commander-the-far-side-of-the-world/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/master-and-commander-the-far-side-of-the-world/mark-as-not-watched/"
                          data-film-link="/film/master-and-commander-the-far-side-of-the-world/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/sm/upload/du/jf/g4/jt/4o4JyEQldHQiqJn0BBRFppDmI65-0-70-0-105-crop.jpg?k=371e708a1f"
                              width="70"
                              height="105"
                              alt="Master and Commander: The Far Side of the World"
                              srcset="https://a.ltrbxd.com/resized/sm/upload/du/jf/g4/jt/4o4JyEQldHQiqJn0BBRFppDmI65-0-140-0-210-crop.jpg?k=cebc9245ad 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                Master and Commander: The Far Side of the World
                                (2003)
                              </span>
                            </span>
                          </div>
                        </li>

                        <li
                          className="react-component poster film-poster film-poster-47044 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="47044"
                          data-film-name="Darkman"
                          data-poster-url="/film/darkman/image-150/"
                          data-film-release-year="1990"
                          data-new-list-with-film-action="/list/new/with/darkman/"
                          data-remove-from-watchlist-action="/film/darkman/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/darkman/add-to-watchlist/"
                          data-rate-action="/film/darkman/rate/"
                          data-mark-as-watched-action="/film/darkman/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/darkman/mark-as-not-watched/"
                          data-film-link="/film/darkman/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/film-poster/4/7/0/4/4/47044-darkman-0-70-0-105-crop.jpg?k=b8722a8cbe"
                              width="70"
                              height="105"
                              alt="Darkman"
                              srcset="https://a.ltrbxd.com/resized/film-poster/4/7/0/4/4/47044-darkman-0-140-0-210-crop.jpg?k=5f7b0e85fa 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                Darkman (1990)
                              </span>
                            </span>
                          </div>
                        </li>

                        <li
                          className="react-component poster film-poster film-poster-3519 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="3519"
                          data-film-name="The Skin I Live In"
                          data-poster-url="/film/the-skin-i-live-in/image-150/"
                          data-film-release-year="2011"
                          data-new-list-with-film-action="/list/new/with/the-skin-i-live-in/"
                          data-remove-from-watchlist-action="/film/the-skin-i-live-in/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/the-skin-i-live-in/add-to-watchlist/"
                          data-rate-action="/film/the-skin-i-live-in/rate/"
                          data-mark-as-watched-action="/film/the-skin-i-live-in/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/the-skin-i-live-in/mark-as-not-watched/"
                          data-film-link="/film/the-skin-i-live-in/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/sm/upload/jc/zx/ej/uw/iFIgRIhz3CdWDuKBqEDURV4a4Ly-0-70-0-105-crop.jpg?k=c3e748f2f3"
                              width="70"
                              height="105"
                              alt="The Skin I Live In"
                              srcset="https://a.ltrbxd.com/resized/sm/upload/jc/zx/ej/uw/iFIgRIhz3CdWDuKBqEDURV4a4Ly-0-140-0-210-crop.jpg?k=fdae7a4985 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                The Skin I Live In (2011)
                              </span>
                            </span>
                          </div>
                        </li>
                        <li
                          className="react-component poster film-poster film-poster-556553 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="556553"
                          data-film-name="Titane"
                          data-poster-url="/film/titane/image-150/"
                          data-film-release-year="2021"
                          data-new-list-with-film-action="/list/new/with/titane/"
                          data-remove-from-watchlist-action="/film/titane/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/titane/add-to-watchlist/"
                          data-rate-action="/film/titane/rate/"
                          data-mark-as-watched-action="/film/titane/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/titane/mark-as-not-watched/"
                          data-film-link="/film/titane/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/film-poster/5/5/6/5/5/3/556553-titane-0-70-0-105-crop.jpg?k=21e476d4a8"
                              width="70"
                              height="105"
                              alt="Titane"
                              srcset="https://a.ltrbxd.com/resized/film-poster/5/5/6/5/5/3/556553-titane-0-140-0-210-crop.jpg?k=a2c7c3fb8e 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">Titane (2021)</span>
                            </span>
                          </div>
                        </li>
                      </ul>
                    </div>
                    <span className="overlay"></span>
                  </a>

                  <h3 className="title-3 prettify">
                    {" "}
                    <a href="/crew/list/the-vinzator-show-brian-formos-four-favorites/">
                      The cinetrail Show: Brian Formo’s Four Favorites
                    </a>{" "}
                  </h3>
                </section>
              </div>
            </section>

            <section id="top-lists" className="section">
              <h2 className="section-heading -spaced">All-time lists</h2>
              <div className="list-grid -singlerow -twoup">
                <section
                  className="list -overlapped -stacked "
                  data-film-list-id="207314"
                  data-person="dave"
                >
                  <a
                    href="/dave/list/official-top-250-narrative-feature-films/"
                    className="list-link"
                  >
                    <div className="list-link-stacked clear">
                      <ul className="poster-list -overlapped -p70">
                        <li
                          className="react-component poster film-poster film-poster-426406 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="426406"
                          data-film-name="Parasite"
                          data-poster-url="/film/parasite-2019/image-150/"
                          data-film-release-year="2019"
                          data-new-list-with-film-action="/list/new/with/parasite-2019/"
                          data-remove-from-watchlist-action="/film/parasite-2019/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/parasite-2019/add-to-watchlist/"
                          data-rate-action="/film/parasite-2019/rate/"
                          data-mark-as-watched-action="/film/parasite-2019/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/parasite-2019/mark-as-not-watched/"
                          data-film-link="/film/parasite-2019/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/film-poster/4/2/6/4/0/6/426406-parasite-0-70-0-105-crop.jpg?k=6a36270820"
                              width="70"
                              height="105"
                              alt="Parasite"
                              srcset="https://a.ltrbxd.com/resized/film-poster/4/2/6/4/0/6/426406-parasite-0-140-0-210-crop.jpg?k=2d9ea1c1b9 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                Parasite (2019)
                              </span>
                            </span>
                          </div>
                        </li>

                        <li
                          className="react-component poster film-poster film-poster-36192 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="36192"
                          data-film-name="Come and See"
                          data-poster-url="/film/come-and-see/image-150/"
                          data-film-release-year="1985"
                          data-new-list-with-film-action="/list/new/with/come-and-see/"
                          data-remove-from-watchlist-action="/film/come-and-see/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/come-and-see/add-to-watchlist/"
                          data-rate-action="/film/come-and-see/rate/"
                          data-mark-as-watched-action="/film/come-and-see/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/come-and-see/mark-as-not-watched/"
                          data-film-link="/film/come-and-see/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/film-poster/3/6/1/9/2/36192-come-and-see-0-70-0-105-crop.jpg?k=9c0b5900f7"
                              width="70"
                              height="105"
                              alt="Come and See"
                              srcset="https://a.ltrbxd.com/resized/film-poster/3/6/1/9/2/36192-come-and-see-0-140-0-210-crop.jpg?k=252f0e3120 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                Come and See (1985)
                              </span>
                            </span>
                          </div>
                        </li>

                        <li
                          className="react-component poster film-poster film-poster-43015 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="43015"
                          data-film-name="Harakiri"
                          data-poster-url="/film/harakiri/image-150/"
                          data-film-release-year="1962"
                          data-new-list-with-film-action="/list/new/with/harakiri/"
                          data-remove-from-watchlist-action="/film/harakiri/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/harakiri/add-to-watchlist/"
                          data-rate-action="/film/harakiri/rate/"
                          data-mark-as-watched-action="/film/harakiri/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/harakiri/mark-as-not-watched/"
                          data-film-link="/film/harakiri/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/sm/upload/uq/lq/di/e9/99EyyBq5dXEvY37jF7EyERhQcFe-0-70-0-105-crop.jpg?k=334117e49e"
                              width="70"
                              height="105"
                              alt="Harakiri"
                              srcset="https://a.ltrbxd.com/resized/sm/upload/uq/lq/di/e9/99EyyBq5dXEvY37jF7EyERhQcFe-0-140-0-210-crop.jpg?k=429ffd690b 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                Harakiri (1962)
                              </span>
                            </span>
                          </div>
                        </li>

                        <li
                          className="react-component poster film-poster film-poster-51818 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="51818"
                          data-film-name="The Godfather"
                          data-poster-url="/film/the-godfather/image-150/"
                          data-film-release-year="1972"
                          data-new-list-with-film-action="/list/new/with/the-godfather/"
                          data-remove-from-watchlist-action="/film/the-godfather/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/the-godfather/add-to-watchlist/"
                          data-rate-action="/film/the-godfather/rate/"
                          data-mark-as-watched-action="/film/the-godfather/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/the-godfather/mark-as-not-watched/"
                          data-film-link="/film/the-godfather/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/film-poster/5/1/8/1/8/51818-the-godfather-0-70-0-105-crop.jpg?k=2454993409"
                              width="70"
                              height="105"
                              alt="The Godfather"
                              srcset="https://a.ltrbxd.com/resized/film-poster/5/1/8/1/8/51818-the-godfather-0-140-0-210-crop.jpg?k=4459fa02b7 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                The Godfather (1972)
                              </span>
                            </span>
                          </div>
                        </li>

                        <li
                          className="react-component poster film-poster film-poster-51816 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="51816"
                          data-film-name="The Godfather: Part II"
                          data-poster-url="/film/the-godfather-part-ii/image-150/"
                          data-film-release-year="1974"
                          data-new-list-with-film-action="/list/new/with/the-godfather-part-ii/"
                          data-remove-from-watchlist-action="/film/the-godfather-part-ii/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/the-godfather-part-ii/add-to-watchlist/"
                          data-rate-action="/film/the-godfather-part-ii/rate/"
                          data-mark-as-watched-action="/film/the-godfather-part-ii/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/the-godfather-part-ii/mark-as-not-watched/"
                          data-film-link="/film/the-godfather-part-ii/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/film-poster/5/1/8/1/6/51816-the-godfather-part-ii-0-70-0-105-crop.jpg?k=08ea341368"
                              width="70"
                              height="105"
                              alt="The Godfather: Part II"
                              srcset="https://a.ltrbxd.com/resized/film-poster/5/1/8/1/6/51816-the-godfather-part-ii-0-140-0-210-crop.jpg?k=d13f9a71c8 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                The Godfather: Part II (1974)
                              </span>
                            </span>
                          </div>
                        </li>

                        <li
                          className="react-component poster film-poster film-poster-51716 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="51716"
                          data-film-name="Seven Samurai"
                          data-poster-url="/film/seven-samurai/image-150/"
                          data-film-release-year="1954"
                          data-new-list-with-film-action="/list/new/with/seven-samurai/"
                          data-remove-from-watchlist-action="/film/seven-samurai/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/seven-samurai/add-to-watchlist/"
                          data-rate-action="/film/seven-samurai/rate/"
                          data-mark-as-watched-action="/film/seven-samurai/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/seven-samurai/mark-as-not-watched/"
                          data-film-link="/film/seven-samurai/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/sm/upload/ji/5q/0k/rv/v6xrz4fr92KY1oNC3HsEvrsvR1n-0-70-0-105-crop.jpg?k=cfed3e0759"
                              width="70"
                              height="105"
                              alt="Seven Samurai"
                              srcset="https://a.ltrbxd.com/resized/sm/upload/ji/5q/0k/rv/v6xrz4fr92KY1oNC3HsEvrsvR1n-0-140-0-210-crop.jpg?k=9a8338b01b 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                Seven Samurai (1954)
                              </span>
                            </span>
                          </div>
                        </li>

                        <li
                          className="react-component poster film-poster film-poster-51700 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="51700"
                          data-film-name="12 Angry Men"
                          data-poster-url="/film/12-angry-men/image-150/"
                          data-film-release-year="1957"
                          data-new-list-with-film-action="/list/new/with/12-angry-men/"
                          data-remove-from-watchlist-action="/film/12-angry-men/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/12-angry-men/add-to-watchlist/"
                          data-rate-action="/film/12-angry-men/rate/"
                          data-mark-as-watched-action="/film/12-angry-men/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/12-angry-men/mark-as-not-watched/"
                          data-film-link="/film/12-angry-men/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/film-poster/5/1/7/0/0/51700-12-angry-men-0-70-0-105-crop.jpg?k=ee4cb0ccb6"
                              width="70"
                              height="105"
                              alt="12 Angry Men"
                              srcset="https://a.ltrbxd.com/resized/film-poster/5/1/7/0/0/51700-12-angry-men-0-140-0-210-crop.jpg?k=ee4cb0ccb6 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                12 Angry Men (1957)
                              </span>
                            </span>
                          </div>
                        </li>

                        <li
                          className="react-component poster film-poster film-poster-24788 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="24788"
                          data-film-name="A Dog's Will"
                          data-poster-url="/film/a-dogs-will/image-150/"
                          data-film-release-year="2000"
                          data-new-list-with-film-action="/list/new/with/a-dogs-will/"
                          data-remove-from-watchlist-action="/film/a-dogs-will/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/a-dogs-will/add-to-watchlist/"
                          data-rate-action="/film/a-dogs-will/rate/"
                          data-mark-as-watched-action="/film/a-dogs-will/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/a-dogs-will/mark-as-not-watched/"
                          data-film-link="/film/a-dogs-will/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/film-poster/2/4/7/8/8/24788-a-dog-s-will-0-70-0-105-crop.jpg?k=5620218a49"
                              width="70"
                              height="105"
                              alt="A Dog's Will"
                              srcset="https://a.ltrbxd.com/resized/film-poster/2/4/7/8/8/24788-a-dog-s-will-0-140-0-210-crop.jpg?k=dd4fea54a6 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                A Dog's Will (2000)
                              </span>
                            </span>
                          </div>
                        </li>

                        <li
                          className="react-component poster film-poster film-poster-29108 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="29108"
                          data-film-name="The Human Condition III: A Soldier's Prayer"
                          data-poster-url="/film/the-human-condition-iii-a-soldiers-prayer/image-150/"
                          data-film-release-year="1961"
                          data-new-list-with-film-action="/list/new/with/the-human-condition-iii-a-soldiers-prayer/"
                          data-remove-from-watchlist-action="/film/the-human-condition-iii-a-soldiers-prayer/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/the-human-condition-iii-a-soldiers-prayer/add-to-watchlist/"
                          data-rate-action="/film/the-human-condition-iii-a-soldiers-prayer/rate/"
                          data-mark-as-watched-action="/film/the-human-condition-iii-a-soldiers-prayer/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/the-human-condition-iii-a-soldiers-prayer/mark-as-not-watched/"
                          data-film-link="/film/the-human-condition-iii-a-soldiers-prayer/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/film-poster/2/9/1/0/8/29108-the-human-condition-iii-a-soldier-s-prayer-0-70-0-105-crop.jpg?k=1254c64152"
                              width="70"
                              height="105"
                              alt="The Human Condition III: A Soldier's Prayer"
                              srcset="https://a.ltrbxd.com/resized/film-poster/2/9/1/0/8/29108-the-human-condition-iii-a-soldier-s-prayer-0-140-0-210-crop.jpg?k=febd1e1bc4 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                The Human Condition III: A Soldier's Prayer
                                (1961)
                              </span>
                            </span>
                          </div>
                        </li>

                        <li
                          className="react-component poster film-poster film-poster-51921 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="51921"
                          data-film-name="Spirited Away"
                          data-poster-url="/film/spirited-away/image-150/"
                          data-film-release-year="2001"
                          data-new-list-with-film-action="/list/new/with/spirited-away/"
                          data-remove-from-watchlist-action="/film/spirited-away/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/spirited-away/add-to-watchlist/"
                          data-rate-action="/film/spirited-away/rate/"
                          data-mark-as-watched-action="/film/spirited-away/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/spirited-away/mark-as-not-watched/"
                          data-film-link="/film/spirited-away/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/film-poster/5/1/9/2/1/51921-spirited-away-0-70-0-105-crop.jpg?k=0d860878b3"
                              width="70"
                              height="105"
                              alt="Spirited Away"
                              srcset="https://a.ltrbxd.com/resized/film-poster/5/1/9/2/1/51921-spirited-away-0-140-0-210-crop.jpg?k=98ed0e36f3 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                Spirited Away (2001)
                              </span>
                            </span>
                          </div>
                        </li>
                      </ul>
                    </div>
                    <span className="overlay"></span>
                  </a>

                  <h2 className="title-3 prettify">
                    {" "}
                    <a href="/dave/list/official-top-250-narrative-feature-films/">
                      Official Top 250 Narrative Feature Films
                    </a>{" "}
                  </h2>

                  <div className="attribution-block">
                    <a
                      className="avatar -a16"
                      href="/dave/"
                      data-original-title=""
                    >
                      {" "}
                      <img
                        src="https://a.ltrbxd.com/resized/avatar/twitter/1/9/1/9/shard/http___pbs.twimg.com_profile_images_1608928766_46690_151677418184854_100000277911529_384912_1233529_n-0-32-0-32-crop.jpg?k=ed5c7154c7"
                        alt="Dave Vis"
                        width="16"
                        height="16"
                      />{" "}
                    </a>

                    <p className="attribution">
                      Created by{" "}
                      <strong className="name">
                        <a href="/dave/">Dave Vis</a>
                      </strong>
                      <time
                        datetime="2013-11-08T10:38:22Z"
                        className="timeago timeago-complete"
                        title="7y"
                      >
                        7y
                      </time>
                    </p>
                  </div>
                </section>

                <section
                  className="list -overlapped -stacked "
                  data-film-list-id="2742178"
                  data-person="jack"
                >
                  <a
                    href="/jack/list/official-top-250-documentary-films/"
                    className="list-link"
                  >
                    <div className="list-link-stacked clear">
                      <ul className="poster-list -overlapped -p70">
                        <li
                          className="react-component poster film-poster film-poster-72964 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="72964"
                          data-film-name="Twenty Years Later"
                          data-poster-url="/film/twenty-years-later/image-150/"
                          data-film-release-year="1984"
                          data-new-list-with-film-action="/list/new/with/twenty-years-later/"
                          data-remove-from-watchlist-action="/film/twenty-years-later/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/twenty-years-later/add-to-watchlist/"
                          data-rate-action="/film/twenty-years-later/rate/"
                          data-mark-as-watched-action="/film/twenty-years-later/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/twenty-years-later/mark-as-not-watched/"
                          data-film-link="/film/twenty-years-later/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/film-poster/7/2/9/6/4/72964-twenty-years-later-0-70-0-105-crop.jpg?k=42c19ccff7"
                              width="70"
                              height="105"
                              alt="Twenty Years Later"
                              srcset="https://a.ltrbxd.com/resized/film-poster/7/2/9/6/4/72964-twenty-years-later-0-140-0-210-crop.jpg?k=6bc908c75b 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                Twenty Years Later (1984)
                              </span>
                            </span>
                          </div>
                        </li>

                        <li
                          className="react-component poster film-poster film-poster-37004 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="37004"
                          data-film-name="Stop Making Sense"
                          data-poster-url="/film/stop-making-sense/image-150/"
                          data-film-release-year="1984"
                          data-new-list-with-film-action="/list/new/with/stop-making-sense/"
                          data-remove-from-watchlist-action="/film/stop-making-sense/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/stop-making-sense/add-to-watchlist/"
                          data-rate-action="/film/stop-making-sense/rate/"
                          data-mark-as-watched-action="/film/stop-making-sense/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/stop-making-sense/mark-as-not-watched/"
                          data-film-link="/film/stop-making-sense/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/film-poster/3/7/0/0/4/37004-stop-making-sense-0-70-0-105-crop.jpg?k=2bd1d8d205"
                              width="70"
                              height="105"
                              alt="Stop Making Sense"
                              srcset="https://a.ltrbxd.com/resized/film-poster/3/7/0/0/4/37004-stop-making-sense-0-140-0-210-crop.jpg?k=7b0a77ffa2 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                Stop Making Sense (1984)
                              </span>
                            </span>
                          </div>
                        </li>

                        <li
                          className="react-component poster film-poster film-poster-101559 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="101559"
                          data-film-name="As I Was Moving Ahead Occasionally I Saw Brief Glimpses of Beauty"
                          data-poster-url="/film/as-i-was-moving-ahead-occasionally-i-saw-brief-glimpses-of-beauty/image-150/"
                          data-film-release-year="2000"
                          data-new-list-with-film-action="/list/new/with/as-i-was-moving-ahead-occasionally-i-saw-brief-glimpses-of-beauty/"
                          data-remove-from-watchlist-action="/film/as-i-was-moving-ahead-occasionally-i-saw-brief-glimpses-of-beauty/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/as-i-was-moving-ahead-occasionally-i-saw-brief-glimpses-of-beauty/add-to-watchlist/"
                          data-rate-action="/film/as-i-was-moving-ahead-occasionally-i-saw-brief-glimpses-of-beauty/rate/"
                          data-mark-as-watched-action="/film/as-i-was-moving-ahead-occasionally-i-saw-brief-glimpses-of-beauty/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/as-i-was-moving-ahead-occasionally-i-saw-brief-glimpses-of-beauty/mark-as-not-watched/"
                          data-film-link="/film/as-i-was-moving-ahead-occasionally-i-saw-brief-glimpses-of-beauty/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/sm/upload/g8/ih/3s/1y/as-i-was-moving-0-70-0-105-crop.jpg?k=ca1bb4c1d7"
                              width="70"
                              height="105"
                              alt="As I Was Moving Ahead Occasionally I Saw Brief Glimpses of Beauty"
                              srcset="https://a.ltrbxd.com/resized/sm/upload/g8/ih/3s/1y/as-i-was-moving-0-140-0-210-crop.jpg?k=a0bedfea05 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                As I Was Moving Ahead Occasionally I Saw Brief
                                Glimpses of Beauty (2000)
                              </span>
                            </span>
                          </div>
                        </li>

                        <li
                          className="react-component poster film-poster film-poster-23019 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="23019"
                          data-film-name="Shoah"
                          data-poster-url="/film/shoah/image-150/"
                          data-film-release-year="1985"
                          data-new-list-with-film-action="/list/new/with/shoah/"
                          data-remove-from-watchlist-action="/film/shoah/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/shoah/add-to-watchlist/"
                          data-rate-action="/film/shoah/rate/"
                          data-mark-as-watched-action="/film/shoah/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/shoah/mark-as-not-watched/"
                          data-film-link="/film/shoah/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/film-poster/2/3/0/1/9/23019-shoah-0-70-0-105-crop.jpg?k=6f6e2bc170"
                              width="70"
                              height="105"
                              alt="Shoah"
                              srcset="https://a.ltrbxd.com/resized/film-poster/2/3/0/1/9/23019-shoah-0-140-0-210-crop.jpg?k=b93cf6f46b 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">Shoah (1985)</span>
                            </span>
                          </div>
                        </li>

                        <li
                          className="react-component poster film-poster film-poster-72963 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="72963"
                          data-film-name="Playing"
                          data-poster-url="/film/playing/image-150/"
                          data-film-release-year="2007"
                          data-new-list-with-film-action="/list/new/with/playing/"
                          data-remove-from-watchlist-action="/film/playing/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/playing/add-to-watchlist/"
                          data-rate-action="/film/playing/rate/"
                          data-mark-as-watched-action="/film/playing/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/playing/mark-as-not-watched/"
                          data-film-link="/film/playing/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/film-poster/7/2/9/6/3/72963-playing-0-70-0-105-crop.jpg?k=3be509bb04"
                              width="70"
                              height="105"
                              alt="Playing"
                              srcset="https://a.ltrbxd.com/resized/film-poster/7/2/9/6/3/72963-playing-0-140-0-210-crop.jpg?k=b2417d7abe 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                Playing (2007)
                              </span>
                            </span>
                          </div>
                        </li>

                        <li
                          className="react-component poster film-poster film-poster-312736 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="312736"
                          data-film-name="O.J.: Made in America"
                          data-poster-url="/film/oj-made-in-america/image-150/"
                          data-film-release-year="2016"
                          data-new-list-with-film-action="/list/new/with/oj-made-in-america/"
                          data-remove-from-watchlist-action="/film/oj-made-in-america/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/oj-made-in-america/add-to-watchlist/"
                          data-rate-action="/film/oj-made-in-america/rate/"
                          data-mark-as-watched-action="/film/oj-made-in-america/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/oj-made-in-america/mark-as-not-watched/"
                          data-film-link="/film/oj-made-in-america/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/sm/upload/h9/c5/7p/b3/eG0WtPOqYTYGo6nRynqN2CQRoel-0-70-0-105-crop.jpg?k=c7e0c7741c"
                              width="70"
                              height="105"
                              alt="O.J.: Made in America"
                              srcset="https://a.ltrbxd.com/resized/sm/upload/h9/c5/7p/b3/eG0WtPOqYTYGo6nRynqN2CQRoel-0-140-0-210-crop.jpg?k=182d2fd0d7 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                O.J.: Made in America (2016)
                              </span>
                            </span>
                          </div>
                        </li>

                        <li
                          className="react-component poster film-poster film-poster-416786 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="416786"
                          data-film-name="Nathan for You: Finding Frances"
                          data-poster-url="/film/nathan-for-you-finding-frances/image-150/"
                          data-film-release-year="2017"
                          data-new-list-with-film-action="/list/new/with/nathan-for-you-finding-frances/"
                          data-remove-from-watchlist-action="/film/nathan-for-you-finding-frances/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/nathan-for-you-finding-frances/add-to-watchlist/"
                          data-rate-action="/film/nathan-for-you-finding-frances/rate/"
                          data-mark-as-watched-action="/film/nathan-for-you-finding-frances/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/nathan-for-you-finding-frances/mark-as-not-watched/"
                          data-film-link="/film/nathan-for-you-finding-frances/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/film-poster/4/1/6/7/8/6/416786-nathan-for-you-finding-frances-0-70-0-105-crop.jpg?k=5bc1cfd5fc"
                              width="70"
                              height="105"
                              alt="Nathan for You: Finding Frances"
                              srcset="https://a.ltrbxd.com/resized/film-poster/4/1/6/7/8/6/416786-nathan-for-you-finding-frances-0-140-0-210-crop.jpg?k=e495846d5e 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                Nathan for You: Finding Frances (2017)
                              </span>
                            </span>
                          </div>
                        </li>

                        <li
                          className="react-component poster film-poster film-poster-31355 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="31355"
                          data-film-name="Paris Is Burning"
                          data-poster-url="/film/paris-is-burning/image-150/"
                          data-film-release-year="1990"
                          data-new-list-with-film-action="/list/new/with/paris-is-burning/"
                          data-remove-from-watchlist-action="/film/paris-is-burning/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/paris-is-burning/add-to-watchlist/"
                          data-rate-action="/film/paris-is-burning/rate/"
                          data-mark-as-watched-action="/film/paris-is-burning/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/paris-is-burning/mark-as-not-watched/"
                          data-film-link="/film/paris-is-burning/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/film-poster/3/1/3/5/5/31355-paris-is-burning-0-70-0-105-crop.jpg?k=755028ba3b"
                              width="70"
                              height="105"
                              alt="Paris Is Burning"
                              srcset="https://a.ltrbxd.com/resized/film-poster/3/1/3/5/5/31355-paris-is-burning-0-140-0-210-crop.jpg?k=7d739b2263 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                Paris Is Burning (1990)
                              </span>
                            </span>
                          </div>
                        </li>

                        <li
                          className="react-component poster film-poster film-poster-6434 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="6434"
                          data-film-name="Master, a Building in Copacabana"
                          data-poster-url="/film/master-a-building-in-copacabana/image-150/"
                          data-film-release-year="2002"
                          data-new-list-with-film-action="/list/new/with/master-a-building-in-copacabana/"
                          data-remove-from-watchlist-action="/film/master-a-building-in-copacabana/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/master-a-building-in-copacabana/add-to-watchlist/"
                          data-rate-action="/film/master-a-building-in-copacabana/rate/"
                          data-mark-as-watched-action="/film/master-a-building-in-copacabana/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/master-a-building-in-copacabana/mark-as-not-watched/"
                          data-film-link="/film/master-a-building-in-copacabana/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/film-poster/6/4/3/4/6434-master-a-building-in-copacabana-0-70-0-105-crop.jpg?k=64f5369782"
                              width="70"
                              height="105"
                              alt="Master, a Building in Copacabana"
                              srcset="https://a.ltrbxd.com/resized/film-poster/6/4/3/4/6434-master-a-building-in-copacabana-0-140-0-210-crop.jpg?k=98b608293d 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                Master, a Building in Copacabana (2002)
                              </span>
                            </span>
                          </div>
                        </li>

                        <li
                          className="react-component poster film-poster film-poster-72944 listitem"
                          data-component-className="globals.comps.FilmPosterComponent"
                          data-film-id="72944"
                          data-film-name="Tie Xi Qu: West of the Tracks"
                          data-poster-url="/film/tie-xi-qu-west-of-the-tracks/image-150/"
                          data-film-release-year="2002"
                          data-new-list-with-film-action="/list/new/with/tie-xi-qu-west-of-the-tracks/"
                          data-remove-from-watchlist-action="/film/tie-xi-qu-west-of-the-tracks/remove-from-watchlist/"
                          data-add-to-watchlist-action="/film/tie-xi-qu-west-of-the-tracks/add-to-watchlist/"
                          data-rate-action="/film/tie-xi-qu-west-of-the-tracks/rate/"
                          data-mark-as-watched-action="/film/tie-xi-qu-west-of-the-tracks/mark-as-watched/"
                          data-mark-as-not-watched-action="/film/tie-xi-qu-west-of-the-tracks/mark-as-not-watched/"
                          data-film-link="/film/tie-xi-qu-west-of-the-tracks/"
                        >
                          <div>
                            <img
                              src="https://a.ltrbxd.com/resized/film-poster/7/2/9/4/4/72944-tie-xi-qu-west-of-the-tracks-0-70-0-105-crop.jpg?k=bd95e9c00d"
                              width="70"
                              height="105"
                              alt="Tie Xi Qu: West of the Tracks"
                              srcset="https://a.ltrbxd.com/resized/film-poster/7/2/9/4/4/72944-tie-xi-qu-west-of-the-tracks-0-140-0-210-crop.jpg?k=d98ca89fd5 2x"
                              className="image"
                            />
                            <span className="frame">
                              <span className="frame-title">
                                Tie Xi Qu: West of the Tracks (2002)
                              </span>
                            </span>
                          </div>
                        </li>
                      </ul>
                    </div>
                    <span className="overlay"></span>
                  </a>

                  <h2 className="title-3 prettify">
                    {" "}
                    <a href="/jack/list/official-top-250-documentary-films/">
                      Official Top 250 Documentary Films
                    </a>{" "}
                  </h2>

                  <div className="attribution-block">
                    <a
                      className="avatar -a16"
                      href="/jack/"
                      data-original-title=""
                    >
                      {" "}
                      <img
                        src="https://a.ltrbxd.com/resized/avatar/upload/3/0/5/2/8/shard/avtr-0-32-0-32-crop.jpg?k=90b3020119"
                        alt="Jack Moulton"
                        width="16"
                        height="16"
                      />{" "}
                    </a>

                    <p className="attribution">
                      Created by{" "}
                      <strong className="name">
                        <a href="/jack/">Jack Moulton</a>
                      </strong>
                      <time
                        datetime="2018-06-27T06:38:16Z"
                        className="timeago timeago-complete"
                        title="3y"
                      >
                        3y
                      </time>
                    </p>
                  </div>
                </section>
              </div>
            </section>
          </div>
        </div>
      </div>
    </div>
  );
}
