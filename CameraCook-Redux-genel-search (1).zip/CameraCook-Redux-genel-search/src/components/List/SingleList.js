import React, { useState } from "react";
import { Link } from "react-router-dom";

const SingleList = ({
  movieIds,
  name,
  description,
  userId,
  _id,
  listLikesCount,
  commentIds,
}) => {
  const [showMore, setShowMore] = useState(false);
  const { firstname, mediaId } = userId[0];

  return (
    <section className="list -overlapped -stacked ">
      <Link to={`/list-card/${_id}`} className="list-link">
        <div className="list-link-stacked clear">
          <ul className="poster-list -overlapped -p150">
            {movieIds?.map(
              ({ _id, image_path, backdrop_path, tmdb_id, original_title }) => (
                <li className="react-component poster film-poster film-poster-9952 listitem" key={_id}>
                  <div>
                    <img
                      src={`https://image.tmdb.org/t/p/w185/${image_path}`}
                      width="150"
                      height="225"
                      alt={original_title}
                      // srcset={`https://image.tmdb.org/t/p/original/${backdrop_path}`}
                      className="image"
                    />
                    <span className="frame">
                      <span className="frame-title">{original_title}</span>
                    </span>
                  </div>
                </li>
              )
            )}
          </ul>
        </div>
        <span className="overlay"></span>
      </Link>

      <h2 className="title-2 prettify">
        {description.length < 30 ? (
          <Link to="/list-card/">{description}</Link>
        ) : (
          <>
            <Link to="/list-card/">
              {showMore ? description : description.slice(0, 30)}
            </Link>
            {(!showMore && (
              <p
                className="section-heading-list-all"
                onClick={() => setShowMore(true)}
              >
                show more ...
              </p>
            )) || (
              <p
                className="section-heading-list-all"
                onClick={() => setShowMore(false)}
              >
                show less ...
              </p>
            )}
          </>
        )}
      </h2>

      <div className="attribution-block">
        <Link className="avatar -a16" to={`/member-card/${userId[0]._id}`}>
          <img src={mediaId[0].url} alt={firstname} width="16" height="16" />{" "}
        </Link>
        <p className="attribution">
          <strong className="name">
            <Link to={`/member-card/${userId[0]._id}`}>{firstname}</Link>
          </strong>

          <span className="content-metadata">
            <span className="has-icon icon-16 icon-like">
              <span className="fas fa-heart"></span> {listLikesCount}
            </span>

            <span className="has-icon icon-16 icon-comment">
              <span className="fas fa-comment-alt"></span> {commentIds.length}
            </span>
          </span>
        </p>
      </div>
    </section>
  );
};

export default SingleList;
