import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { getAllLists } from "../../actions/list";
import "./List.css";
import SingleList from "./SingleList";

export default function List1() {
  const dispatch = useDispatch();
  const { allLists } = useSelector((state) => state.allLists);
  useEffect(() => {
    dispatch(getAllLists());
  }, []);
  return (
    <div>
      <div className="lists-page main-nav-lists logged-out">
        <div id="content" className="site-body">
          <div className="content-wrap">
            <h1 className="title-hero">
              <span className="mob-hide">Collect, curate, and share. </span>
              Lists are the perfect way to group films.
            </h1>
            <p className="create-your-own">
              <a href="/List/add-new-list" className="text-slug">
                Start your own list
              </a>
            </p>

            <section id="popular-lists" className="section list-set">
              <h2 className="section-heading under-line-1 -spaced listAll">
                <a href="/ListAll">Popular this week</a>
              </h2>
              <a href="/ListAll" className="all-link">
                More1
              </a>
              {allLists
                ?.filter((movies) => movies.movieIds.length > 0)
                ?.map((list) => (
                  <SingleList key={list._id} {...list} />
                ))}

           
            </section>

       



          </div>
        </div>
      </div>
    </div>
  );
}
