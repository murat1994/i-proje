import React, { useEffect, useState } from "react";
 import "../newMoviesSection/popularMoviesTop/popularMoviesTop.css";
import "../newMoviesSection/popularMoviesTop/popular-films.css";
import "../newMoviesSection/popularMoviesTop/PopularMoviesNew.css";
import "../pages/movie/CounterShare.css";
import "remixicon/fonts/remixicon.css";

import { Link } from "react-router-dom";
import { useSelector } from "react-redux";

const ListCardNew = () => {
  const [images, setImages] = useState([]);
  const { popularMovies } = useSelector((state) => state.popularMovies);

  useEffect(() => {
    setImages(popularMovies);
  }, [popularMovies]);

  return (
    <div id="content" className="site-body">
     <div className="container">  
     <div className="header">
     <header className="popular-top-movies-header under-line sub-menu">
            <li className="menu-item iq-up-view-all ">
              <Link to="/Movie">POPULAR FILMS THIS WEEK</Link>
            </li> 
            <li className="menu-item">  <Link to="/MoviesAll">ALL MOVIES</Link> </li>

           
          </header>
        </div>

    <div className="movie-grid"> 
   


   

   
    {images.map(({ image, original_title, id }) => (
               <div className="movie-card">
               <div className="overlay"></div>
                  <div>
                    <img id="movie_popular"
                      src={image}   style={{
                      width:"14.375rem",
                      height:"21.563rem" 
                       }}
                      alt={original_title}
                      className="popular-movies-image-top"
                    />
                  <Link
                      to={`/movie/${id}`}
                      className="frame"
                      title={original_title}
                    >
                      <span className="frame-title">{original_title}</span>
                      <span className="overlay"></span>
                    </Link>
                  </div>
                  <div className="inner-card-controls">
                <button className="ctrl-btn"> <i className="fa-fw far fa-eye"></i> </button>
                <button className="ctrl-btn"><i className="fa-fw fas fa-times"></i></button>
      </div>   
      </div>              
            ))}
            
        </div>
    </div>
    </div>
  );
};

export default ListCardNew;
