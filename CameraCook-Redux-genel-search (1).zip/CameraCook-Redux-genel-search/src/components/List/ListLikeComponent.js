import React,{ useEffect, useState} from "react";
import { Link } from "react-router-dom";
import { useSelector } from "react-redux";
import axios from "axios";
import { API_BASE }  from "../../actions/api_base";

const ListLikeComponent = (props) => {
  const [likeClicked, setLikeClicked] = useState(false)

  const { user } = useSelector(
    (state) => state?.auth
  );

  useEffect(()=>{
    axios.post(`${API_BASE}listlikes/filter`,{
      query: {
        userId: user.id,
        listId : props.listId
      }
    })
    .then(res=>{
      console.log(res.data)
      if(res.data.response.length > 0){
        setLikeClicked(true)
      }
    })
    .catch(err=>console.log(err))
  },[])

  const ListLikeFunc = () => {
    axios.post(`${API_BASE}listlikes`, {
        userId: user.id,
        listId : props.listId
    })
    .then(res=>{
      console.log(res.data)
      setLikeClicked(!likeClicked)
    })
    .catch(err=>console.log(err))
  }


  //onClick={(event)=>{ListLikeFunc();event.stopPropagation()}}
  console.log(props)
  return (
    <section id="userpanel" className="actions-panel">
      <ul>
      {likeClicked ? 
        <li className="like-link-target react-component" style={{backgroundColor:"#458032"}} onClick={ListLikeFunc}>
          <span className="like-link" style={{color:"black"}}>
            
              <span className="fas fa-heart" style={{color:"rgb(81, 225, 30)"}} onClick={ListLikeFunc}></span>&nbsp;Like this list?
                
                &nbsp;
                
                {props.singleList.listLikesCount}
                
              </span> 
          
        </li> :
              <li className="like-link-target react-component" onClick={ListLikeFunc}>
              <span className="like-link">
                
                  <span className="fas fa-heart" onClick={ListLikeFunc}></span>&nbsp;Like this list?
                    
                    &nbsp;
                    
                      {props.singleList.listLikesCount}
                    
                  </span> 
              
            </li> 
        }


      </ul>
    </section>
  );
};

export default ListLikeComponent;
