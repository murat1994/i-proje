import React, { useEffect, useState } from "react";
import { Html5Entities } from 'html-entities';
import { useDispatch, useSelector } from "react-redux";
import { Link, useParams } from "react-router-dom";
import { getAllLists, getSingleList } from "../../actions/list";
import "./List.css";
import ListCommentComponent from "./ListCommentComponent";
import ListLikeComponent from "./ListLikeComponent";
import axios from "axios"
import ListCardNew from "./ListCardNew";
import MovieFilterSection from "../newMoviesSection/movieFilter/MovieFilterSection";   
import { API_BASE }  from "../../actions/api_base";

export default function ListCard() {
  const [allComments, setAllComments] = useState([]);
  const [editReviewClicked, setEditReviewClicked] = useState(false)
  const dispatch = useDispatch();
  const { id } = useParams();
  const { singleList, success, error, loading } = useSelector(
    (state) => state?.singleList
  );
  const { user } = useSelector(
    (state) => state?.auth
  );
  useEffect(() => {
    dispatch(getSingleList(id));
  }, []);

    
const GetAllComments = () => {
    axios.get(`${API_BASE}comments/list/${id}`)
    .then(res=>{
      console.log(res.data)
      setAllComments(res.data.response.reverse())
    })
    .catch(err=>console.log(err))
  }

  useEffect(() => {
    
    GetAllComments()
  }, [])

  const EditReview = (e) => {
      if(!editReviewClicked){
         console.log(e)     
              
        const targetInput = e.target.id + "59"
        e.target.parentElement.parentElement.nextElementSibling.id = targetInput
        // e.target.parentElement.parentElement.parentElement.parentElement.nextElementSibling.children[1].id = targetInput
        //e.target.parentElement.parentElement.style.height = "auto";
       
        e.target.parentElement.parentElement.nextElementSibling.contentEditable = true;
        e.target.parentElement.parentElement.nextElementSibling.style.border = "red solid 2px";
        e.target.parentElement.parentElement.nextElementSibling.style.backgroundColor = "#141414"
        e.target.parentElement.href = `#${targetInput}`
        setTimeout(() => {
          e.target.parentElement.parentElement.nextElementSibling.classList.add("reviewForUpdateParent")
        }, 200);

        setEditReviewClicked(true)
    }
  }

  const updateReview = (e)=> {
    console.log(e)
  
  const htmlEntities = new Html5Entities();
  const str = e.target.id
        

      if(e.target.innerText !== ""){
        axios.put(`${API_BASE}comments/${str.substring(0, str.length - 2)}`, {content: htmlEntities.decode(e.target.innerText)})
            .then(res=>{
                console.log(res.data);
                e.target.parentElement.style.height = "auto";
                e.target.classList.remove("reviewForUpdateParent")
                e.target.style.border = "none";
                e.target.contentEditable = false
                setTimeout(() => {
                    setEditReviewClicked(false)
                }, 1000);
                GetAllComments()
            })
            .catch(err=>console.log(err))
      } else {
        axios.delete(`${API_BASE}comments/${str.substring(0, str.length - 2)}`)
        .then(res=>{
            console.log(res.data)
            // e.target.parentElement.style.height = "110px"
            e.target.style.border = "none";
            e.target.contentEditable = false;
            setTimeout(() => {
                setEditReviewClicked(false)
            }, 1000);
            GetAllComments()
        })
        .catch(err=>console.log(err))        
      } 
  }

  const RemoveReview = (e) => {
    if(!editReviewClicked){
      axios.delete(`${API_BASE}comments/${e.target.id}`)
    .then(res=>{
      console.log(res.data)
      GetAllComments()
    })
    .catch(err=>console.log(err))
    }
    
  }



  if (success && !loading) {
    console.log(singleList[0]);
    const {
      movieIds,
      userId,
      name,
      description,
      tags,
    } = singleList[0];
    
    return (
      <div >
        {/* <MovieFilterSection />
        <ListCardNew /> */}
        
          <div className=" List-Body">
          
          <div style={{align:"center"}}><div id="adbox">
          <div class="adbox1"> 
          <header className="page-header-list under-line-1 ">
                  <div className="person-summary -inline">
                    <Link
                      className="avatar -a24"
                      to={`/member-card/${userId[0]?._id}`}
                    >
                      <img
                        src={`${userId[0]?.mediaId[0].url}`}
                        alt={`${userId[0]?.firstname}`}
                        width="24"
                        height="24"
                      />{" "}
                    </Link>
                    <h1 className="title-4">
                      <small className="context">List bbby</small>
                      <Link
                        to={`/member-card/${userId[0]?._id}`} 
                        className="name"
                      >
                        <span className="List-owner" itemprop="name">{userId[0]?.firstname}</span>
                      </Link>
                    </h1>
                    <h1 className=" list-title-1 prettify" itemprop="title">
                    {name}
                  </h1>
                  <p id="list-description">{description}</p>
                  </div>

                  <div className="clear"></div>
                </header> 
          </div> 
          <div class="adbox2"> 
               <ListLikeComponent listId={id} singleList={singleList[0]}/>
               

<section className="section">
<h3 className="section-heading under-line-1">Tagged</h3>
<ul className="tags">
{(tags?.length > 0 &&
tags?.map((el) => (
<li>
<Link to="/list">{el}</Link>
</li>
))) || (
<li>
<Link>There is no any tags</Link>
</li>
)}


</ul>
</section> 
          </div> 
         <div class="clear"/></div>
         </div>



         
            <div >
              <section >
               

                
                <div className=" list-title-intro ">
                 
                  


                  <div
                    className="body-text -prose -hero clear collapsible-text"
                    data-full-text-url="#list-notes"
                  >
                   
            <ul id="list-movie-names">
                    <p >
                      {movieIds.map(({ original_title }) => (
                        <Link
                         key={original_title}
                        //  to= {original_title}
                          className="text-slug tooltip starring "
            data-original-title={original_title}
            >
              {original_title}
                        </Link>
                      ))}
                    </p>
            </ul>
                  </div>
                </div>
                
                {/* <ul className=" poster-list -p125 -grid film-list"> */}
                <ul className="wrapper movie-grid">
                  {movieIds.map(
                    ({ image_path, tmdb_id, original_title, release_date }) => (
                      <li className="poster-container film-not-watched">
                        <div className="react-component poster film-poster film-poster-51347 linked-film-poster removed-from-watchlist">
                          <div className="lits-card-paket">
                            <img
                              src={`https://image.tmdb.org/t/p/w185/${image_path}`}
                              style={{
                                width:"14.375rem",
                                height:"21.563rem" 
                                 }}
                              alt={`${original_title}`}
                              className="image"
                              id="movie_popular"
                            />
                            <Link
                              to={`/movie/${tmdb_id}`}
                              className="frame has-menu"
                            >
                              <span className="frame-title">
                                {original_title} ({release_date?.split("-")[0]})
                              </span>
                              <span className="overlay"></span>
                              <span
                                className="overlay-actions js-film-options -w125"
                                style={{ display: "none" }}
                              >
                             
                                
                                <span className="replace menu-link icon"></span>
                              </span>
                            </Link>
                         

             <div className="inner-card-controls">
                <button className="ctrl-btn"><i className="fa-fw far fa-eye"></i> </button>              
                <button className="ctrl-btn"><i className="fa-fw fas fa-heart"></i></button>
                <button className="ctrl-btn"><i className="fa-fw fas fa-clock"></i></button>
             </div>   
             </div>

                        </div>
                      </li>
                    )  )}
                </ul>

                <div
                  id="comments"
                  className="clear -with-subscription comments-panel js-comments-panel"
                >
                  

                  <div className="body">
                    

                    <div
                      id="comment-form"
                      className="composition comment-composition"
                    >
                      <ListCommentComponent GetAllComments={GetAllComments}/>
                    </div>
                    <div className="clear"></div>
                  </div>
                  <div id="comments" className="clear -with-subscription comments-panel js-comments-panel" data-url="/comments/" data-reports-url="/ajax/filmlist:1400388/reports/" data-report-url="/s/report/filmlist:1400388/">
                    <header className="header">
                      <h2 className="section-heading" data-comments-link="list/now-thats-a-poster/#comments">{allComments.length} Comments</h2>
                      
                             
                    </header>	
	
                    <div className="body">
                    <ul className="comment-list js-comment-list" data-commentable-type="list" data-owner="bratpitt" data-num-comments="25" data-comments-start="0" data-timestamp="1632426060769">

                      {allComments.map(comment=>{
                        return <li id="comment-2206199" className="comment" data-edit-url="/ajax/filmListComment:2206199/edit-comment/" data-delete-url="/ajax/filmListComment:2206199/delete-comment/" data-comment-id="2206199" data-person="BingoDinoDNA" data-creation-timestamp="1494561003431" data-timestamp="1494561003431" data-edit-window-expiry="33030561003431"> 
                        <div className="person-summary -small col-5 js-comment-person">
                           <a className="avatar -a24" href="/bingodinodna/" data-original-title="">
                              <img src={comment.userId[0].mediaId[0].url} alt="Robbie Newman" width="24" height="24"/> </a> 
                              <strong className="name">
                                
                                <a href={`/member-card/${comment.userId[0]._id}/`}>{comment.userId[0].firstname} {comment.userId[0].lastname}
                                </a>
                                <a href="#" className="block-or-report-flag popmenu-link has-icon icon-16 icon-report tooltip" 
                           data-popmenu-id="comment-2206199" 
                           data-popmenu-direction="e" 
                           data-original-title="Report">
                          <li className="fas fa-flag">{" Report"}</li>
                          
                          {/* <li className="block-or-report">Report</li> */}
                           </a> </strong>
                            <li>   <small id="date-comment" className="metadata"> 
                        <span className="comment-permalink">
                          <span className="time">
                            <time datetime="PTDHMS" className="timeago timeago-complete" title="created date">{comment?.createdAt}</time></span>
                             </span>                          
                        </small> </li>
                        <li>   <small id="date-comment" className="metadata"> 
                        <span className="comment-permalink">
                          <span className="time">
                            <time datetime="PTDHMS" className="timeago timeago-complete" title="updated date">{comment?.updatedAt}</time></span>
                             </span>                          
                        </small> </li>
                        </div> 
                        <div className="comment-body col-12 body-text -small collapsible-text" data-full-text-url="/s/full-text/filmListComment:2206199/" style={{paddingLeft:"0",position:"relative"}}> 
                        
                        <p style={{position:"relative"}}>
                        {comment.userId[0]._id === user.id ?
                                        <span style={{position: "absolute",right:"0"}}>
                                            <a><i className="fas fa-edit listReviewEdit" style={{cursor:"pointer", marginRight:"10px"}}  id={comment._id}  onClick={EditReview}></i></a>
                                            <i className="fas fa-trash listReviewRemove" id={comment._id} style={{cursor:"pointer"}} onClick={RemoveReview}></i>
                                        </span> : ""
                                    }
                      
                          <p className="reviewForUpdate" style={{padding: "20px"}} onBlur={updateReview}>
                         
                            {comment.content}
                         
                          </p>
                          
                         
                          </p> 
                          
                        </div> </li>
                      })}
                    </ul>	
                      
                    <p className="comments-disabled-message body-text -small">Only people the author follows may reply.</p>			
                    
                  </div>
                </div>

                </div>

                <div className="clear"></div>
              </section>
{/* 
              <aside className="box3 sidebar">
                <ListLikeComponent listId={id} singleList={singleList[0]}/>

                <section className="section">
                  <h3 className="section-heading">Tagged</h3>
                  <ul className="tags">
                    {(tags?.length > 0 &&
                      tags?.map((el) => (
                        <li>
                          <Link to="/list">{el}</Link>
                        </li>
                      ))) || (
                      <li>
                        <Link>There is no any tags</Link>
                      </li>
                    )}


                  </ul>
                </section>
              </aside> */}
            </div>
          </div>
         
        </div>
      
    );
  } else if (loading) {
    console.log(success, loading);
    return <h1>Loading.......</h1>;
  } else {
    console.log(success, loading, error);
    return <h1>There is something wrong</h1>;
  }
}
