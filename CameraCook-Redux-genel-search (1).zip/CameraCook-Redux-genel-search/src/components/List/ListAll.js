import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Link } from "react-router-dom";
import { getAllLists } from "../../actions/list";
import "./ListAll.css";

export default function ListAll() {
  const { allLists } = useSelector((state) => state.allLists);
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(getAllLists());
  }, []);

  return (
    <div>
      <div className="popular-lists lists logged-in">
        <div id="content" className="site-body">
          <div className="content-wrap">
            <div className="cols-2">
              <section className="section col-24 col-main">
                <div id="content-nav">
                  {" "}
                  <h2 className="section-heading">Popular Lists</h2>
                  <div className="sorting-selects"></div>
                  <div className="clear"></div>
                </div>
                <section className="list-set liked-lists list-set-wide">
                  {allLists?.map(
                    ({ _id, movieIds, listLikesCount, description, userId,commentIds }) => (
                      <section className="list -overlapped -summary " key={_id}>
                        <Link to={`/list-card/${_id}`} className="list-link">
                          <ul className="poster-list -p70 -overlapped">
                            {movieIds.map(
                              ({
                                _id,
                                genre,
                                image_path,
                                original_title,
                                release_date,
                              }, index) => (
                                index < 10 && <li className="react-component poster film-poster film-poster-34618 listitem" key={index}>
                                  <div>
                                    <img
                                      src={`https://image.tmdb.org/t/p/w185/${image_path}`}
                                      width="70"
                                      height="105"
                                      alt={original_title}
                                      className="image"
                                    />
                                    <span className="frame">
                                      <span className="frame-title">
                                        {original_title} (
                                        {release_date?.split(" ")[0]})
                                      </span>
                                    </span>
                                  </div>
                                </li>
                              )
                            )}
                          </ul>{" "}
                          <span className="overlay"></span>{" "}
                        </Link>
                        <div className="film-list-summary">
                          <div className="attribution-block" style={{width:"410px", textAlign:"left"}}>
                            {" "}
                            <Link
                              to={`/member-card/${userId[0]._id}`}
                              className="avatar -a16"
                            >
                              {" "}
                              <img
                                src={userId[0].mediaId[0].url}
                                alt={userId[0].firstname}
                                width="16"
                                height="16"
                              />{" "}
                            </Link>{" "}
                            <p className="attribution">
                              {" "}
                              <strong className="name">
                                <Link to={`/member-card/${userId[0]._id}`}>
                                  {userId[0].firstname}
                                </Link>
                              </strong>{" "}
                              <small className="value">
                                {movieIds.length} films{" "}
                              </small>{" "}
                              <span className="content-metadata">
                                {" "}
                                <span className="has-icon icon-16 icon-like">
                                  <i className="fas fa-heart"></i> {" "}
                                  {listLikesCount}
                                </span>{" "}
                                <span className="has-icon icon-16 icon-comment">
                                  <span className="fas fa-comment-alt"></span> {commentIds.length}{" "}
                                </span>{" "}
                              </span>{" "}
                            </p>
                          </div>
                          <div className="body-text -prose">
                            {" "}
                            <p>
                              {description}
                            </p>
                          </div>
                        </div>
                      </section>
                    )
                  )}
                </section>
              </section>
              <aside className="sidebar"></aside>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
