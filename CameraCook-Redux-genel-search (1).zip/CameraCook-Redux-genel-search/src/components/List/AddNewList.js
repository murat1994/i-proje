import axios from "axios";
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import "./AddNewList.css";
import { FaTrash } from "react-icons/fa";
import { useDispatch, useSelector } from "react-redux";
import { addMovie } from "../../actions/movie";
import { searchMovie } from "../../utils/searchMovie";
import { addList } from "../../actions/list";
export default function AddNewList() {
  const { id } = useSelector((state) => state.auth.user);
  const { error, success } = useSelector((state) => state.addList);
  const [movies, setMovies] = useState([]);
  const [keyTerm, setKeyTerm] = useState("");
  const [movieList, setMovieList] = useState({ movieIds: [], movies: [] });
  const { movie } = useSelector((state) => state.addMovie);
  const [fillAllBlanks, setFillAllBlanks] = useState("");
  const [clearMessage, setClearMessage] = useState(true);
  const dispatch = useDispatch();
  useEffect(() => {
    if (movie) {
      setMovieList({
        ...movieList,
        movies:
          (!movieList.movies.some((el) => el._id === movie._id) && [
            ...movieList.movies,
            movie,
          ]) ||
          movieList.movies,
        movieIds: [...new Set([...movieList.movieIds, movie._id])],
      });
      setKeyTerm("");
    }
  }, [movie]);
  useEffect(() => {
    if (keyTerm) {
      setFillAllBlanks("");
      searchMovie(keyTerm).then((res) => setMovies(res));
    }
  }, [keyTerm]);
  const handleClick = async (movieInfo) => {
    setMovies([]);
    dispatch(
      addMovie({
        ...movieInfo,
        tmdb_id: movieInfo.id.toString(),
      })
    );
  };
  const handleSubmit = async (e) => {
    const { name, description, movieIds } = movieList;
    if (name && description && movieIds.length > 0) {
      dispatch(addList(movieList));
      setClearMessage(true);
      setFillAllBlanks("");
      setTimeout(() => {
        setMovieList({ movieIds: [], movies: [], name: "", description: "" });
        setClearMessage(false);
      }, 3000);
    } else {
      setClearMessage(false);
      setFillAllBlanks("Please,fill all the blanks");
    }
  };

  return (
    <div>
      <div className="lists-new logged-in">
        <div id="content" className="site-body">
          <div className="content-wrap">
            <>
              <div className="cols-2 overflow film-list-editor-contents">
                <article className="section">
                  <header className="page-header">
                    <h1 className="title-hero js-film-list-editor-title">
                      New List
                    </h1>
                  </header>

                  <fieldset
                    id="film-list-main-details"
                    className="overflow list-sharing"
                  >
                    <div className="list-details-left">
                      <div className="form-row">
                        <label className="has-icon validated">
                          <span className="icon-1"> </span>Name of list
                        </label>
                        <input
                          type="text"
                          name="name"
                          className="field focus-ring"
                          placeholder="Create list name"
                          style={{ position: "relative", verticalAlign: "top" }}
                          value={movieList["name"] || ""}
                          onChange={(e) => {
                            setMovieList({
                              ...movieList,
                              [e.target.name]: e.target.value,
                            });
                          }}
                        />
                      </div>
                      <div className="form-row autocomplete-tags-data">
                        <label for="list-tags">Tags</label>

                        <div className="autocomplete-tags">
                          <div id="tag-container">
                            <span
                              className="twitter-typeahead"
                              style={{
                                position: "relative",
                                display: "inline-block",
                              }}
                            >
                              <input
                                type="text"
                                id="list-tags"
                                className="tag-input-field field tt-input"
                                name="listTags"
                                style={{
                                  position: "relative",
                                  verticalAlign: "top",
                                }}
                              />
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="list-details-right">
                      <div className="form-row">
                        <label>Description</label>
                        <p className="note -topnote allowed-html js-allowed-html">
                          <p>Show supported HTML</p>
                        </p>
                        <textarea
                          name="description"
                          className="textarea notes-field"
                          placeholder="write brief information "
                          value={movieList?.description}
                          onChange={(e) => {
                            setMovieList({
                              ...movieList,
                              [e.target.name]: e.target.value,
                            });
                          }}
                        ></textarea>
                      </div>
                    </div>
                  </fieldset>

                  <section
                    id="list-items-editor"
                    className="col-right overflow col-12 no-hover"
                  >
                    <div className="list-items-header-wrap">
                      <header className="list-items-header">
                        <div style={{ zIndex: "10000" }} className="wrap">
                          <fieldset className="film-list-item-search">
                            <label className="section-heading heading-no-border">
                              Add a film
                            </label>
                            <input
                              type="text"
                              className="field ac_input"
                              id="frm-list-film-name"
                              placeholder="Enter name tof film..."
                              onChange={(e) => setKeyTerm(e.target.value)}
                              value={keyTerm}
                            />
                          </fieldset>
                          <ul className="combo-search">
                            {movies.length > 0 &&
                              movies.map((movie) => (
                                <li
                                  className="under-line-1 channel-logo-2"
                                  style={{ cursor: "pointer" }}
                                  name="movieIds"
                                  onClick={(e) => handleClick(movie)}
                                  key={id}
                                >
                                  <p>{movie.original_title}</p>
                                  <span>
                                    ({movie?.release_date?.split("-")[0]})
                                  </span>
                                </li>
                              ))}
                          </ul>
                        </div>
                      </header>
                    </div>
                    <ul id="list-items" className="ui-sortable empty-list">
                      {movieList?.movies?.map((movie) => (
                        <li key={movie.id}>
                          <Link to={`/movie/${movie.tmdb_id}`}>
                            {movie?.backdrop_path && (
                              <img
                                width="35"
                                height="52"
                                src={`https://image.tmdb.org/t/p/w92/${movie?.backdrop_path}`}
                                alt={movie.original_title}
                              />
                            )}
                            <span>{movie.original_title} </span>
                          </Link>
                          <FaTrash
                            className="delete-button"
                            onClick={() => {
                              setMovieList({
                                ...movieList,
                                movies: movieList.movies.filter(
                                  ({ _id }) => _id !== movie._id
                                ),
                              });
                            }}
                          />{" "}
                        </li>
                      ))}
                      {movieList.movies.length === 0 && (
                        <li id="empty-list-placeholder">
                          <p>
                            <strong className="title-2">
                              Your list is empty.
                            </strong>
                            Add films using the field above, or from the links
                            on a film poster or page.
                          </p>
                        </li>
                      )}
                      <div id="list-edit-buttons" className="row buttons">
                        <button
                          id="list-edit-save"
                          className="button -action button-action right"
                          type="button"
                          onClick={handleSubmit}
                        >
                          Save
                        </button>
                        <button
                          id="list-edit-cancel"
                          className="button button-cancel right"
                          type="button"
                          disabled={
                            !(movieList?.name && movieList.movieIds.length > 0)
                          }
                          onClick={() => {
                            setMovieList({ movieIds: [] });
                          }}
                        >
                          Cancel
                        </button>
                      </div>
                      {fillAllBlanks && (
                        <p>
                          Please, fill all the blanks / You can't send empy list
                        </p>
                      )}

                      {clearMessage && success && <p>List has been created</p>}
                    </ul>
                    <div
                      id="list-items-colorbox-owner"
                      style={{ display: "none" }}
                      className="cboxElement"
                    ></div>
                  </section>

                  <div className="clear"></div>
                </article>
              </div>
              <div className="form-processing"></div>
            </>
          </div>
        </div>
      </div>
    </div>
  );
}
