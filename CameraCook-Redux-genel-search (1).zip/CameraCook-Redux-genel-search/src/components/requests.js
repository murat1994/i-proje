// const API_KEY = "xxx";

const requests = {
    fetchTvShows: `https://api.themoviedb.org/3/discover/tv?api_key=${process.env.REACT_APP_API_KEY}&with_networks=213`,
   
}

export default requests;