import React, { useState, useCallback} from 'react';
import {useDropzone} from 'react-dropzone';
import axios from 'axios';
import "../../components/css/photoUpload.css"
import { API_BASE }  from "../../actions/api_base";

//const resUrl="https://res.cloudinary.com/recipe-app-images/image/upload"
const url = `${API_BASE}users/`;

export default function MyDropzone(props) {
    //const [uploadedFiles, setUploadedFiles] = useState([])
    // const [isUploaded, setisUploaded] = useState(false);
    
  const onDrop = useCallback((acceptedFiles)=> {
      
        const formData = new FormData();
        formData.append("mediaId", acceptedFiles[0])
        
        console.log(props);
        
        // await fetch(url + props.memberId, {
        // method: "PUT",
        // body: {mediaId : formData}

        axios.put(url + props.memberId, formData)
            .then((response) => {
                console.log(response.data)
                props.ProfilePicture()
                
            })
            .catch(err=>console.log(err))

  }, [])

          // const onDrop = useCallback((acceptedFile)=> {
          //   const formData = new FormData();
          //   formData.append("mediaId", acceptedFile)
            
          //   console.log(formData);
          //   console.log(acceptedFile)

          //   axios.put(url + props.memberId,formData)
          //       .then((response) => {
          //           console.log(response.data)
          //           console.log(props.memberId) 
          //       })
          //       .catch(err=>console.log(err))
          // })
  
  const {getRootProps, getInputProps, isDragActive} = useDropzone({onDrop, accepts: "image/*", multiple: false})
  
  return (
    <div className={`${props.avatarComponent ? "addAvatarDiv": "null"}`}>
        <div {...getRootProps()}  className={`${props.avatarComponent ? "null": "dropzone"} ${isDragActive ? "activeDrop": "null"}`}>
        <input {...getInputProps()} />
        {
            isDragActive ?
            <p>Drop the files here ...</p> :
            props.avatarComponent ? <i className="fas fa-camera addAvatarIcon"></i>: <p>Drag 'n' drop your recipe image, or click to select files</p>
            
            
        }
        </div>    
    </div>
  )
}