import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import axios from "axios";
import { Link } from "react-router-dom";
import {useSelector } from "react-redux";
import { API_BASE }  from "../../actions/api_base";

export default function UserLikes(props) {
  const {memberId} = useParams()
  const [state, setstate] = useState([]);
  const [commentLikes, setCommentLikes] = useState([]);
  const [likedLists, setLikedLists] = useState([])
  const { user } = useSelector(
    (state) => state?.auth
  );
  const { language } = useSelector((state) => state.searchMovies);

  useEffect(() => {
    GetLikedComments();
    setstate(props.userLiked);
    GetLikedLists()
    //console.log(props)
  }, [memberId]);

  const GetLikedLists = () => {
    //console.log(props.listLikes)
    let promises = props.listLikes.map(listLikes => {
      return listLikes.listId !== null && axios.get(`${API_BASE}lists/${listLikes.listId._id}`)
        .then(res => {
          return res.data;
        })
    });

    Promise.all(promises)
      .then(results => {
        //console.log(results)
        //console.log(results.filter(like=>{return like!==false && like}))//created because of DB bugs
        setLikedLists(results.filter(like=>{return like!==false && like}).reverse())
        
      })
      .catch(e => {
        console.error(e);
      })
  }

  

  const GetLikedComments = () => {
    let promises = props.state.commentLikes.map(commentLikes => {
      return axios.get(`${API_BASE}comments/${commentLikes.commentId}`)
        .then(res => {
          return res.data;
        })
    });

    Promise.all(promises)
      .then(results => {
        //console.log(results)
        setCommentLikes(results.reverse())
      })
      .catch(e => {
        console.error(e);
      })
  }
  
  return (
    <div className="person-liked-overview" style={{ paddingTop: "1%" }}>
      <section id="liked-films" className="liked-column -films">
        <h2 className="section-heading">
          <span
            style={{color:"#ec165c"}}
            className="tooltip"
            data-original-title="463&nbsp;films"
          >
            {language === "EN" && "Films" || language === "TR" && "Filmler" || language === "DE" && "Filme"}
          </span>
        </h2>
        {/* <a href="/jay/likes/films/" className="all-link">
          All
        </a> */}
        <ul className="poster-list -p70 -grid">
          {state.map((movie) => {
            return (
              <li
                className="poster-container film-not-watched"
                key={movie.movieId[0]._id}
              >
                <div
                  className="react-component poster film-poster film-poster-488575 linked-film-poster removed-from-watchlist"
                  data-component-class="globals.comps.FilmPosterComponent"
                  data-film-id="488575"
                  data-film-name="El Camino: A Breaking Bad Movie"
                  data-poster-url="/film/el-camino-a-breaking-bad-movie/image-150/"
                  data-film-release-year="2019"
                  data-new-list-with-film-action="/list/new/with/el-camino-a-breaking-bad-movie/"
                  data-remove-from-watchlist-action="/film/el-camino-a-breaking-bad-movie/remove-from-watchlist/"
                  data-add-to-watchlist-action="/film/el-camino-a-breaking-bad-movie/add-to-watchlist/"
                  data-rate-action="/film/el-camino-a-breaking-bad-movie/rate/"
                  data-mark-as-watched-action="/film/el-camino-a-breaking-bad-movie/mark-as-watched/"
                  data-mark-as-not-watched-action="/film/el-camino-a-breaking-bad-movie/mark-as-not-watched/"
                  data-film-link="/film/el-camino-a-breaking-bad-movie/"
                  data-film-in-watchlist="false"
                >
                  <div>
                    <img
                      src={`https://image.tmdb.org/t/p/w92/${movie?.movieId[0]?.image_path}`}
                      width="70"
                      height="105"
                      alt="El Camino: A Breaking Bad Movie"
                      srcset="https://a.ltrbxd.com/resized/film-poster/4/8/8/5/7/5/488575-el-camino-a-breaking-bad-movie-0-140-0-210-crop.jpg?k=6c2d1c5705 2x"
                      className="image"
                    />
                    <Link
                      to={`/movie/${movie.movieId[0]?.tmdb_id}`}
                      className="frame has-menu"
                      data-original-title="El Camino: A Breaking Bad Movie (2019)"
                    >
                      <span className="frame-title">
                        El Camino: A Breaking Bad Movie (2019)
                      </span>
                      <span className="overlay"></span>
                      <span
                        className="overlay-actions js-film-options -w70"
                        style={{ display: "none" }}
                      >
                        <span
                          className="film-watch-link-target"
                          data-film-id="488575"
                        >
                          <span className="film-watch-link">
                            <span
                              className="has-icon icon-16 icon-watch ajax-click-action"
                              data-action="/film/el-camino-a-breaking-bad-movie/mark-as-watched/"
                            >
                              <span className="replace icon"></span>Seen this
                              film?
                            </span>
                          </span>
                        </span>
                        <span
                          className="like-link-target"
                          data-likeable-uid="film:488575"
                        >
                          <span className="like-link">
                            <span
                              className="has-icon icon-16 ajax-click-action  icon-like"
                              data-action="/s/film:488575/like/"
                              data-recaptcha-action="film_like"
                            >
                              <span className="icon"></span>Like this film?
                            </span>
                          </span>
                        </span>
                        <span className="replace menu-link icon"></span>
                      </span>
                    </Link>
                  </div>
                </div>
              </li>
            );
          })}
        </ul>
      </section>

      <section id="liked-reviews" className="liked-column -reviews">
        <h2 className="section-heading">
          <span
            style={{color:"#ec165c"}}
            className="tooltip"
            data-original-title="18,195&nbsp;reviews"
          >
            {language === "EN" && "Comments" || language === "TR" && "Yorumlar" || language === "DE" && "Kommentare"}
          </span>
        </h2>
        {/* <a href="/jay/likes/reviews/" className="all-link">
          All
        </a> */}
        <ul className="film-list likes-reviews-list">
          {commentLikes.map(comments=>{
            return comments.response[0] && <li className="film-detail liked-review film-not-watched" key={comments.response[0]._id}>
            <div
              className="react-component poster film-poster film-poster-357826 linked-film-poster removed-from-watchlist"
              data-component-class="globals.comps.FilmPosterComponent"
              data-film-id="357826"
              data-film-name="Annette"
              data-poster-url="/film/annette/image-150/"
              data-film-release-year="2021"
              data-new-list-with-film-action="/list/new/with/annette/"
              data-remove-from-watchlist-action="/film/annette/remove-from-watchlist/"
              data-add-to-watchlist-action="/film/annette/add-to-watchlist/"
              data-rate-action="/film/annette/rate/"
              data-mark-as-watched-action="/film/annette/mark-as-watched/"
              data-mark-as-not-watched-action="/film/annette/mark-as-not-watched/"
              data-film-link="/film/annette/"
              data-film-in-watchlist="false"
            >
              <div>
                <img
                  src={`https://image.tmdb.org/t/p/w92/${comments.response[0].movieId[0]?.image_path}`}
                  width="70"
                  height="105"
                  alt="Annette"
                  srcset="https://a.ltrbxd.com/resized/film-poster/3/5/7/8/2/6/357826-annette-0-140-0-210-crop.jpg?k=717df211e1 2x"
                  className="image"
                />
                <Link to={`/movie/${comments.response[0].movieId[0]?.tmdb_id}`} className="frame has-menu">
                  <span className="frame-title">{comments.response[0].movieId[0]?.original_title}</span>
                  <span className="overlay"></span>
                  
                </Link>
              </div>
            </div>
            <div className="film-detail-content">
              <h2 className="headline-3 prettify">
                <Link to={`/movie/${comments.response[0].movieId[0]?.tmdb_id}`}>{comments.response[0].movieId[0]?.original_title}</Link>
                {/* <small className="metadata">
                  <a href="/films/year/2021/">2021</a>
                </small> */}
              </h2>
              <div className="attribution-block">
                <Link
                  className="avatar -a16"
                  to={`/member-card/${comments.response[0].userId[0]?._id}`}
                  data-original-title=""
                >
                  <img
                    src={comments.response[0].userId[0]?.mediaId[0].url}
                    alt="Ash"
                    width="16"
                    height="16"
                  />{" "}
                </Link>
                <p className="attribution">
                  {" "}
                  <strong className="name">
                    <Link to={`/member-card/${comments.response[0].userId[0]?._id}`}>{comments.response[0].userId[0]?.firstname}</Link>
                  </strong>{" "}
                  <span className="rating -green rated-9"> ★★★★½ </span>{" "}
                </p>
              </div>
              <div className="body-text -prose -small">
                {" "}
                <p>
                  {comments.response[0].content}
                </p>
              </div>{" "}
            </div>{" "}
          </li>
          })}
        </ul>
      </section>

      <section className="liked-column -lists">
        <h2 className="section-heading">
          <span
            style={{color:"#ec165c"}}
            className="tooltip"
            data-original-title="331&nbsp;lists"
          >
            {language === "EN" && "Lists" || language === "TR" && "Listeler" || language === "DE" && "Liste"}
          </span>
        </h2>
        {/* <a href="/jay/likes/lists/" className="all-link">
          All
        </a> */}

          {likedLists.map(list=>{
            return <section
          className="list -overlapped -stacked -ellipsis-250"
          data-film-list-id="18498317"
          data-person="tiff_net"
          key={list.response[0]._id}
        >
          <Link
            to={`/list-card/${list.response[0]._id}`}
            className="list-link"
          >
            <div className="list-link-stacked clear">
              <ul className="poster-list -overlapped -p70">
                {list?.response[0].movieIds.map((movie,index)=>{
                  return (
                    index < 5 && (
                      <li
                        className="react-component poster film-poster film-poster-700928 listitem"
                        data-component-class="globals.comps.FilmPosterComponent"
                        data-film-id="700928"
                        data-film-name="All My Puny Sorrows"
                        data-poster-url="/film/all-my-puny-sorrows/image-150/"
                        data-film-release-year=""
                        data-new-list-with-film-action="/list/new/with/all-my-puny-sorrows/"
                        data-remove-from-watchlist-action="/film/all-my-puny-sorrows/remove-from-watchlist/"
                        data-add-to-watchlist-action="/film/all-my-puny-sorrows/add-to-watchlist/"
                        data-rate-action="/film/all-my-puny-sorrows/rate/"
                        data-mark-as-watched-action="/film/all-my-puny-sorrows/mark-as-watched/"
                        data-mark-as-not-watched-action="/film/all-my-puny-sorrows/mark-as-not-watched/"
                        data-film-link="/film/all-my-puny-sorrows/"
                        key={movie._id}
                      >
                        <div>
                          <img
                            src={`https://image.tmdb.org/t/p/w92/${movie.image_path}`}
                            width="70"
                            height="105"
                            alt={movie.original_title}
                            srcset="https://a.ltrbxd.com/resized/film-poster/7/0/0/9/2/8/700928-all-my-puny-sorrows-0-140-0-210-crop.jpg?k=23e4d4acb1 2x"
                            className="image"
                          />
                          <span className="frame">
                            <span className="frame-title">{movie.original_title}</span>
                          </span>
                        </div>
                      </li>
                    )
                  )
                })}
                
              </ul>
            </div>
            <span className="overlay"></span>
          </Link>

          <h3 className="title-3 prettify">
            {" "}
            <Link to={`/list-card/${list.response[0]._id}`}>
              {list?.response[0].name}
            </Link>{" "}
          </h3>
          <div className="attribution-block">
            <Link className="avatar -a16" to={`/member-card/${list.response[0].userId[0]?._id}`} data-original-title="">
              {" "}
              <img
                src={list.response[0].userId[0]?.mediaId[0].url}
                alt={list.response[0].userId[0]?.firstname}
                width="16"
                height="16"
              />{" "}
            </Link>

            <p className="attribution">
              <strong className="name">
                <Link to={`/member-card/${list.response[0].userId[0]?._id}`}>{list.response[0].userId[0]?.firstname}</Link>
              </strong>

              <small className="value">{list?.response[0].movieIds.length}&nbsp;{language === "EN" && "films" || language === "TR" && "film" || language === "DE" && "filme"}</small>
            </p>
          </div>
        </section>
          })}
        
        
      </section>
    </div>
  );
}
