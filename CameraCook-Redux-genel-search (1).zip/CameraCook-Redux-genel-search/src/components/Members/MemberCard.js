import React, {useEffect, useState, useRef} from 'react';
import { useParams } from "react-router-dom";
import axios from "axios"
 import "./MemberCard.css";
import "./TabsOfMemberCard/Tab.css";
import Tabs from "./TabsOfMemberCard/Tabs";
import UserLikes from './UserLikes';
import UserWatched from './UserWatched';
import UserWatchlist from './UserWatchlist';
import UserReviews from './UserReviews';
import UserLists from './UserLists';
import PhotoUpload from "./PhotoUpload"
import { useSelector } from "react-redux";
import { API_BASE }  from "../../actions/api_base";



export default function UserCard() {
	const [state, setstate] = useState([])
	const [watched, setWatched] = useState([])
  const [reversedLikedMovies, setreversedLikedMovies] = useState([]);
  const [listLikes, setListLikes] = useState([]);
  const [totalReviews, setTotalReviews] = useState([]);
  const [totalLists, setTotalLists] = useState([]);
  const ppRef = useRef()
	const {memberId} = useParams()
  const { language } = useSelector((state) => state.searchMovies);

	const GetUserInfo = () => {
      axios.get(`${API_BASE}users/${memberId}`)
      .then(res=>{
        console.log(res.data.response)
        setstate(res.data.response)
        setreversedLikedMovies(res.data.response[0].liked.reverse())
        setWatched(res.data.response[0].watched.reverse())
        console.log("eeee")
      })
      .catch(err=>console.log(err))
    }

    const GetLikedLists = () => {
      axios.get(`${API_BASE}listlikes/user/${memberId}`)
      .then(res=>{
          console.log(res.data)
          setListLikes(res.data.data)
      
      })
      .catch(err=>console.log(err))
  
    };

	useEffect(() => {
		GetUserInfo();
    GetLikedLists()

    axios.get(`${API_BASE}comments/user/${memberId}`)
        .then(res=>{
            setTotalReviews(res.data.response)
            //console.log(res.data.response)
        })
        .catch(err=>console.log(err))

        axios
      .get(
        `${API_BASE}lists/userid/${memberId}`
      )
      .then((res) => {
        //console.log(res.data)
        setTotalLists(res.data.response);
      })
      .catch((err) => {
        console.log(err);
      });
	}, [memberId])

  const ProfilePicture = () => {
    ppRef.current.style.display = "inline-block"

    setTimeout(() => {
      ppRef.current.style.display = "none"
    }, 4000);
    
  }


  return (
    <div>
      
      <body className="profile backdropped logged-out backdrop-loaded" data-owner="demiadejuyigbe" style={{zoom: "1"}}>

	<div className="backdrop-container">
     <div id="backdrop" className="backdrop-wrapper  -loaded" data-backdrop="https://a.ltrbxd.com/resized/sm/upload/vc/43/v7/fl/hot-rod-1200-1200-675-675-crop-000000.jpg?k=b7d64bddc0" data-backdrop2x="https://a.ltrbxd.com/resized/sm/upload/vc/43/v7/fl/hot-rod-1920-1920-1080-1080-crop-000000.jpg?k=494f4af9c3" data-backdropmobile="https://a.ltrbxd.com/resized/sm/upload/vc/43/v7/fl/hot-rod-960-960-540-540-crop-000000.jpg?k=92a48cb723" data-offset="0"> 
     
     <div className="backdropplaceholder js-backdrop-placeholder" style={{backgroundImage: "url(https://a.ltrbxd.com/resized/sm/upload/vc/43/v7/fl/hot-rod-48-48-27-27-crop.png?k=94c05f686c)", backgroundPosition: "center -0px"}}>
    </div> 
  
  <div className="backdropimage js-backdrop-image" style={{backgroundPosition: "center 0px", backgroundImage: `url(${state[0]?.backgroundImageId[0]?.url})`}}>
    </div> 
    <div className="backdropmask js-backdrop-fade">
      </div>
       </div> 
       </div>

<div id="content" className="site-body -backdrop">
	<div className="content-wrap">

<section id="profile-header" className="js-profile-header -is-not-mini-nav" data-person={state[0]?.firstname}>	
		<div className="profile-summary js-profile-summary" data-profile-summary-options="{&quot;hasMeta&quot;: true, &quot;hasBio&quot;: false}">
			<div className="profile-avatar">
				<span className="avatar -a110 -large">
           <img src={state[0]?.mediaId[0].url} alt={state[0]?.firstname} width="110" height="110"/> 
            {/* <a id="avatar-zoom" href="#avatar-large" className="cboxElement"></a> */}
            <PhotoUpload avatarComponent={true} memberId={memberId} ProfilePicture={ProfilePicture}/>
             
        </span>
        <span ref={ppRef} style={{color:"#41b816", fontWeight:"bold", marginTop:"15px", display:"none", fontSize:"20px", backgroundColor:"black", borderRadius:"1rem", padding:"10px"}}>Succesfull... Please, refresh your page!</span>
			</div>
			{/* <div hidden="" aria-hidden="true">
				<div id="avatar-large">
					<span className="avatar -a500 -borderless -large">
             <img src="https://a.ltrbxd.com/resized/avatar/upload/2/4/3/0/5/shard/avtr-0-1000-0-1000-crop.jpg?k=56e1f8f97f" alt="demi adejuyigbe" width="500" height="500"/> </span>
				</div>
			</div> */}
			<div className="profile-name js-profile-name" style={{paddingRight: "395px"}}>
				<div className="profile-name-wrap">
					<h1 title="demi adejuyigbe" className="title-1">{state[0]?.firstname} {state[0]?.lastname}</h1>
					
				</div>				
			</div>			
			<div className="profile-info -has-no-bio -has-meta -is-not-hq js-profile-info">			
	<div className="profile-stats js-profile-stats" style={{marginTop: "-21.4062px"}}>
				<h4 className="profile-statistic statistic"><span className="thousands">
          <span className="value">{state[0]?.watched.length}</span>
          <span className="definition">{language === "EN" && "Watched" || language === "TR" && "İzledi" || language === "DE" && "Schaute"}</span></span></h4>
				<h4 className="profile-statistic statistic"><span>
          <span className="value">{state[0]?.liked.length}</span><span className="definition">{language === "EN" && "Likes" || language === "TR" && "Beğendi" || language === "DE" && "Gefallen"}</span>
        </span></h4>
				<h4 className="profile-statistic statistic">
          <span>
            <span className="value">{totalReviews.length}</span>
            <span className="definition">{language === "EN" && "Comments" || language === "TR" && "Yorumlar" || language === "DE" && "Kommentare"}</span>
            </span></h4>
            <h4 className="profile-statistic statistic">
          <span>
            <span className="value">{totalLists.length}</span>
            <span className="definition">{language === "EN" && "Lists" || language === "TR" && "Listeler" || language === "DE" && "Liste"}</span>
            </span></h4>
				
				
			
	</div>
					<div className="profile-metadata js-profile-metadata" style={{maxWidth: "435px"}}>						
							<div className="metadatum -has-label js-metadatum">						
								<svg className="glyph" aria-hidden="true" role="presentation" width="8" height="16" xmlns="http://www.w3.org/2000/svg"><path d="M4.25 2.735a.749.749 0 111.5 0 .749.749 0 11-1.5 0zM8 4.75c0-2.21-1.79-4-4-4s-4 1.79-4 4a4 4 0 003.5 3.97v6.53h1V8.72A4 4 0 008 4.75z" fill="#000" fill-rule="evenodd"></path></svg>
								<span className="label">{state[0]?.country}
							</span>
              </div>								
					</div>

					<div className="follow-button-wrapper js-follow-button-wrapper" 
					data-username="demiadejuyigbe" 
					data-profile="true" 
					style={{visibility: "visible"}}>

		</div>

			</div>
		<div className="_context-observer" aria-hidden="true">
      </div>
      </div>

	<header>
	<div
    id="tabbed-content"
    data-selected-tab=""
    className="selected tabbed-content"
  >
	<div className="tab-list">
      {/* <h1>Tabs Demo</h1> */}
      <Tabs>
        <div label={language === "EN" && "Profile" || language === "TR" && "Profil" || language === "DE" && "Profil"}>
          
        </div>
       
        <div label={language === "EN" && "Watched" || language === "TR" && "İzledi" || language === "DE" && "Schaute"}>
          
			<UserWatched state={watched}/>
          
        </div>
			<div label={language === "EN" && "Comments" || language === "TR" && "Yorumlar" || language === "DE" && "Kommentare"}>
          
          <UserReviews currentUser={state}/>

		</div>
        

		<div label={language === "EN" && "Watchlist" || language === "TR" && "İzlenecek" || language === "DE" && "Beobachtu..."}>
          
		   <UserWatchlist state={state[0]}/>
		  
        </div>

		<div label={language === "EN" && "Lists" || language === "TR" && "Listeler" || language === "DE" && "Liste"}>
          
          <UserLists state={state[0]}/>
		  	  
        </div>

		<div label={language === "EN" && "Likes" || language === "TR" && "Beğeniler" || language === "DE" && "Gefallen"}>
          
		  <UserLikes state={state[0]} userLiked={reversedLikedMovies} listLikes={listLikes}/>
		  </div>
		
		
      </Tabs>
    </div>

	</div>        
   </header>

</section>


<div className="cols-2">
	<div className="col-16">
		
		
		
								
				{/* <section id="recent-activity" className="section">
					<h2 className="section-heading">
            <a href="/demiadejuyigbe/activity/">Recent activity</a></h2>
					<a href="/demiadejuyigbe/films/" className="all-link">All</a>
					<ul className="poster-list -p150 -horizontal">

							
							<li className="poster-container">
								<div className="react-component poster film-poster film-poster-48813 linked-film-poster" data-component-className="globals.comps.FilmPosterComponent" data-film-id="48813" data-film-name="The Ladykillers" data-poster-url="/film/the-ladykillers-2004-6/image-150/" data-film-release-year="2004" data-new-list-with-film-action="/list/new/with/the-ladykillers-2004-6/" data-remove-from-watchlist-action="/film/the-ladykillers-2004-6/remove-from-watchlist/" data-add-to-watchlist-action="/film/the-ladykillers-2004-6/add-to-watchlist/" data-rate-action="/film/the-ladykillers-2004-6/rate/" data-mark-as-watched-action="/film/the-ladykillers-2004-6/mark-as-watched/" data-mark-as-not-watched-action="/film/the-ladykillers-2004-6/mark-as-not-watched/" data-film-link="/film/the-ladykillers-2004-6/">
                  
                  <div>
                  <img src="https://a.ltrbxd.com/resized/sm/upload/hn/ov/5p/bg/cDVMkR2NkOPllAbhdRH1Volw9DL-0-150-0-225-crop.jpg?k=74eabac3cd" width="150" height="225" alt="The Ladykillers" srcset="https://a.ltrbxd.com/resized/sm/upload/hn/ov/5p/bg/cDVMkR2NkOPllAbhdRH1Volw9DL-0-300-0-450-crop.jpg?k=ec45d10cbe 2x" className="image"/>
                  <a href="/demiadejuyigbe/film/the-ladykillers-2004-6/" className="frame" data-original-title="The Ladykillers (2004)">
                    <span className="frame-title">The Ladykillers (2004)</span>
                    <span className="overlay"></span></a>
                    </div>
                    </div>

								<p className="poster-viewingdata">
                  
										<a href="/demiadejuyigbe/film/the-ladykillers-2004-6/" className="has-icon icon-review icon-16 tooltip" data-original-title="Review with 19&nbsp;comments">
                      <span className="icon"></span></a>
									
								</p>
							</li>
              
					</ul>
				</section> */}
			
        </div>

      </div>

          </div> 
        </div> 


      </body>
    </div>
  )
}
