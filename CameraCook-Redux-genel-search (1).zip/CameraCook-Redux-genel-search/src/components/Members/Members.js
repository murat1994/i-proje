import React, { useEffect, useState } from "react";
import "./Members.css";
import { getUsers } from "../../actions/auth.action";
import { useDispatch } from "react-redux";
import { Link } from "react-router-dom";
import axios from "axios";
import { useSelector } from "react-redux";
import { API_BASE }  from "../../actions/api_base";

export default function Members1() {
  const [state, setstate] = useState({});
  const [stateList, setstateList] = useState([]);
  const [paginateUsers, setPaginateUsers] = useState(1);
  const [viewMore, setViewMore] = useState(1);
  const [userLists, setUserLists] = useState([]);
  const [userComments, setUserComments] = useState([]);
  const { language } = useSelector((state) => state.searchMovies);

  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(getUsers());
  }, [dispatch]);

  useEffect(() => {
    BringAllUsers();
    BringAllUsersDropDown()
  }, [paginateUsers]);

  useEffect(() => {
    BringAllUsersDropDown()
  }, [viewMore]);

  const BringAllUsers = () => {
    axios
      .get(
        `${API_BASE}users?limit=10&page=${paginateUsers}`
      )
      .then((res) => {
        setstate(res.data);
      })
      .catch((err) => console.log(err));
  };
  const BringAllUsersDropDown = () => {
    axios
      .get(
        `${API_BASE}users?limit=10&page=${viewMore}`
      )
      .then((res) => {
        console.log(res.data)
        viewMore===1 && setstateList(res.data.response)
        viewMore!==1 && setstateList(stateList.concat(res.data.response))
      })
      .catch((err) => console.log(err));
  };
  useEffect(() => {
    userListsFunc()
    userReviewsFunc()
  }, [stateList])

  const userListsFunc = ()=> {
    let promises = stateList.map(users => {
      return axios.get(`${API_BASE}lists/userid/${users._id}`)
        .then(res => {
          return res.data;
        })
    });

    Promise.all(promises)
      .then(results => {
        //console.log(results)
        setUserLists(results)
      })
      .catch(e => {
        console.error(e);
      })
  }

  const userReviewsFunc = ()=> {
    let promises = stateList.map(users => {
      return axios.get(`${API_BASE}comments/user/${users._id}`)
        .then(res => {
          return res.data;
        })
    });

    Promise.all(promises)
      .then(results => {
        console.log(results)
        setUserComments(results)
      })
      .catch(e => {
        console.error(e);
      })
  }
  //console.log(stateList)
  return (
    <div className="main-type">
     
     <div id="members-main" class="wrapper members-main">
  <div class="box11 box12">
    <div class="nested">
    <h1 className="title-hero-members">
              {language === "EN" && "Film lovers, critics and friends — find popular members." || language === "TR" && "Film severler, eleştirmenler ve arkadaşlar — Popüler üyeler bulabilirsiniz." || language === "DE" && "Filmliebhaber, Kritiker und Freunde – finden Sie beliebte Mitglieder."}
            </h1>
    </div>
    <div class="nested">
    <h2 className="section-heading-member under-line-1">
                <a href="/members/popular/this/week/">
                {language === "EN" && "Popular this week" || language === "TR" && "Bu Haftanin Popülerleri" || language === "DE" && "Beliebt diese Woche"}
                </a>
              </h2>
    </div>
    <div class="nested">
    <ul className="featured-people-list-item-1 ">
                {state.response?.map((user) => {
                  return (
                    <li className="featured-person list-item">
                      <Link
                        className="avatar -a150 -large"
                        to={`/member-card/${user._id}`}
                        data-original-title=""
                      >
                        <img
                          src={user.mediaId[0].url}
                          alt="{user.firstname} {user.lastname}"
                          width="150vw"
                          height="150vh"
                        />{" "}
                      </Link>
                      <h3 className="title-3">
                        <Link to={`/member-card/${user._id}`}>
                          {user?.firstname}{" "} {user?.lastname}
                        </Link>
                      </h3>

                      <div
                        className="follow-button-wrapper js-follow-button-wrapper"
                        data-username="{user.firstname} {user.lastname}"
                        data-profile="false"
                        style={{ visibility: "visible" }}
                      >
                        <a
                          href="#"
                          data-action="#"
                          className="ajax-click-action button -compact -following js-button-following"
                          style={{ display: "none" }}
                        >
                          <span className="icon"></span>
                          <span className="button-text">Following</span>
                        </a>
                        <a
                          href="#"
                          data-action="/username/follow/"
                          data-recaptcha-action="follow"
                          className="ajax-click-action button -compact under-member-card  -follow js-button-follow"
                        >
                          <span className="icon"></span>
                          <span className="button-text">Follow</span>
                        </a>
                      </div>
                      <p className="stats">
                        <span>
                          <b style={{ color: "orange" }}>
                            {user.watched.length}
                          </b>{" "}
                          {language === "EN" && "watched" || language === "TR" && "izlendi" || language === "DE" && "schaute"}
                        </span>
                        <span>
                          <b style={{ color: "orange", marginLeft: "10%" }}>
                            {user.liked.length}
                          </b>{" "}
                          {language === "EN" && "likes" || language === "TR" && "begendi" || language === "DE" && "likes"}
                        </span>
                      </p>
                      <div className="person-faves">
                        <ul className="poster-list -p46">
                          {user.liked.map((likedMovie, index) => {
                            return index < 3 ? (
                              <li
                                className="react-component poster film-poster-ilk-sayfa film-poster-7211 linked-film-poster"
                                data-component-className="globals.comps.FilmPosterComponent"
                                data-film-id="7211"
                                data-film-name="Mikey and Nicky"
                                data-poster-url="/film/mikey-and-nicky/image-150/"
                                data-film-release-year="1976"
                                data-new-list-with-film-action="with/mikey-and-nicky/"
                                data-remove-from-watchlist-action="/remove-from-watchlist/"
                                data-add-to-watchlist-action="/add-to-watchlist/"
                                data-rate-action="/film/mikey-and-nicky/rate/"
                                data-mark-as-watched-action="/film/mikey-and-nicky/mark-as-watched/"
                                data-mark-as-not-watched-action="/film/mikey-and-nicky/mark-as-not-watched/"
                                data-film-link="/film/mikey-and-nicky/"
                              >
                                <div>
                                  <img
                                    src={`https://image.tmdb.org/t/p/w92/${likedMovie?.movieId[0]?.image_path}`}
                                    width="70"
                                    height="105"
                                    alt="Mikey and Nicky"
                                    className="image"
                                  />
                                  <Link
                                    to={`/movie/${likedMovie?.movieId[0]?.tmdb_id}`}
                                    className="frame"
                                    data-original-title="Mikey and Nicky (1976)"
                                  >
                                    <span className="frame-title">
                                      Mikey and Nicky (1976)
                                    </span>
                                    <span className="overlay"></span>
                                  </Link>
                                </div>
                              </li>
                            ) : (
                              ""
                            );
                          })}
                        </ul>
                      </div>
                    </li>
                  );
                })}
                <div
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    marginTop: "5%",
                  }}
                  className="under-line-1 paginate-1"
                >
                  {paginateUsers !== 1 ? <span
                    className="paginateButtons"
                    onClick={() => {
                      paginateUsers !== 1 &&
                        setPaginateUsers(paginateUsers - 1);
                    }}
                  >
                    {"<--"} {language === "EN" && "Previous" || language === "TR" && "Önceki" || language === "DE" && "Vorherige"}
                  </span> : <span></span>}
                  {state.pages !== paginateUsers ? <span
                    className="paginateButtons"
                    onClick={() => {
                      paginateUsers !== state.pages &&
                        setPaginateUsers(paginateUsers + 1);
                    }}
                  >
                    {language === "EN" && "Next" || language === "TR" && "Sonraki" || language === "DE" && "Nächste"} {"-->"}
                  </span> : ""}
                </div>
              </ul>
    </div>
    <div class="nested"></div>
  </div>
  <div class="box box13">
    
 
                <section className="section" id="most-active">
                  <table className="person-table">
                    <thead>
                      <tr>
                        <th className="left-th">Name</th>

                        <th>Watched</th>
                        <th>Lists</th>
                        <th>Likes</th>

                        <th className=""></th>
                      </tr>
                    </thead>

                    <tbody>
                      {stateList?.map((users,index)=>{
                        return <tr className="user-line" key={users._id}>
                        <td className="table-person-list">
                          <div className="person-summary-members">
                            <Link
                              className="avatar -a40"
                              to={`/member-card/${users._id}`}
                              data-original-title=""
                            >
                              <img
                                src={users.mediaId[0].url}
                                alt="Siegel™"
                                width="40"
                                height="40"
                              />{" "}
                            </Link>
                            <h3 className="title-3">
                              {" "}
                              <Link to={`/member-card/${users._id}`}>
                                {" "}
                                {users?.firstname}{" "}{users?.lastname}{" "}
                                </Link>{" "}
                            </h3>
                            <small className="metadata">
                              <span style={{color:"white"}}>
                              {userComments[index]?.response.length}&nbsp;{language === "EN" && "reviews" || language === "TR" && "yorumlar" || language === "DE" && "kommentare"}
                              </span>
                            </small>
                          </div>
                        </td>
                        <td className="table-stats">
                          <Link
                            className="has-icon-member-list icon-16 icon-watched"
                            to={`/member-card/${users._id}`}
                          >
                            <span className="fas fa-eye icon-eye"></span> {users.watched.length}
                          </Link>
                        </td>
                        <td className="table-stats">
                          <Link
                            className="has-icon-member-list icon-16 icon-list"
                            to={`/member-card/${users._id}`}
                          >
                            <span className="fab fa-windows  icon-window"></span>{" "}
                            {userLists[index]?.response.length}
                          </Link>
                        </td>
                        <td className="table-stats">
                          <Link
                            className="has-icon-member-list icon-16 icon-liked"
                            to={`/member-card/${users._id}`}
                          >
                            <span className="fas fa-heart  icon-heart"></span>{" "}
                            {users.liked.length}
                          </Link>
                        </td>

                        {/* <td className="table-follow-status">
                          <div
                            className="follow-button-wrapper js-follow-button-wrapper"
                            data-username="Siegel"
                            data-profile="false"
                            style={{ visibility: "visible" }}
                          >
                            <a
                              href="#"
                              data-action="/siegel/unfollow/"
                              className="ajax-click-action button -compact -following js-button-following"
                              style={{ display: "none" }}
                            >
                              <span className="icon"></span>
                              <span className="button-text">Following</span>
                            </a>
                            <a
                              href="#"
                              data-action="/siegel/follow/"
                              data-recaptcha-action="follow"
                              className="ajax-click-action button -compact -follow js-button-follow"
                            >
                              <span className="icon"></span>
                              <span className="button-text">Follow</span>
                            </a>
                          </div>
                        </td> */}
                      </tr>
                      })}


                    </tbody>
                  </table>
                </section>
                {state.pages !== viewMore ? <span
                  className="load-more-button btn-hover"
                  style={{cursor:"pointer"}}
                  onClick={()=>setViewMore(viewMore+1)}
                >
                  {language === "EN" && "View more" || language === "TR" && "Daha Fazla" || language === "DE" && "Mehr sehen"}
                </span> : ""}
                
             
  </div>
  
 
</div>

     




    </div>
  );
}