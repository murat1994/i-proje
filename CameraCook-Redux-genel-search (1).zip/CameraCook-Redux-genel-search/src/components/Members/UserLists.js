import axios from "axios";
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import {useSelector } from "react-redux";
import { API_BASE }  from "../../actions/api_base";

export default function UserLists(props) {
  const [state, setstate] = useState([]);
  const { language } = useSelector((state) => state.searchMovies);

  useEffect(() => {
    //console.log(props.userInfo);
    GetMyLists();
  }, []);

  const GetMyLists = () => {
    axios
      .get(
        `${API_BASE}lists/userid/${props.state._id}`
      )
      .then((res) => {
        console.log(res.data)
        setstate(res.data);
      })
      .catch((err) => {
        console.log(err);
      });
  };
  return (
    <div>
      <section
        className="section col-17 col-main overflow"
        style={{ paddingTop: "3%" }}
      >
        <div id="content-nav">
          {" "}
          <h2 className="section-heading">
            <span className="tooltip" data-original-title="84&nbsp;lists">
              <span
                className="replace-if-you"
                data-replacement="Public Lists"
                data-person="jay"
              >
                {language === "EN" && "Lists" || language === "TR" && "Listeler" || language === "DE" && "Liste"}
              </span>{" "}
            </span>{" "}
          </h2>
          {/* <div className="sorting-selects">
            <section className="smenu-wrapper">
              {" "}
              <strong className="smenu-label">Sort by</strong>
              <div className="smenu">
                {" "}
                <label>
                  When Updated<i className="ir s icon"></i>
                </label>
              </div>
            </section>
          </div>
          <div className="clear"></div> */}
        </div>
        <section className="list-set">
          {state.response?.reverse().map((lists) => {
            return (
              <section
                className="list -overlapped -summary "
                data-film-list-id="19341118"
                data-person="jay"
                key={lists._id}
              >
                <Link to={`/list-card/${lists._id}`} className="list-link">
                  <ul className="poster-list -p70 -overlapped">
                    {lists.movieIds?.map((moviePosters, index) => {
                      return (
                        index < 5 && (
                          <li
                            className="react-component poster film-poster film-poster-390116 listitem"
                            data-component-class="globals.comps.FilmPosterComponent"
                            data-film-id="390116"
                            data-film-name="Palmer"
                            data-poster-url="/film/palmer/image-150/"
                            data-film-release-year="2021"
                            data-new-list-with-film-action="/list/new/with/palmer/"
                            data-remove-from-watchlist-action="/film/palmer/remove-from-watchlist/"
                            data-add-to-watchlist-action="/film/palmer/add-to-watchlist/"
                            data-rate-action="/film/palmer/rate/"
                            data-mark-as-watched-action="/film/palmer/mark-as-watched/"
                            data-mark-as-not-watched-action="/film/palmer/mark-as-not-watched/"
                            data-film-link="/film/palmer/"
                            key={moviePosters._id}
                          >
                            <div>
                              <img
                                src={`https://image.tmdb.org/t/p/w92/${moviePosters.image_path}`}
                                width="70"
                                height="105"
                                alt="Palmer"
                                srcSet="https://a.ltrbxd.com/resized/film-poster/3/9/0/1/1/6/390116-palmer-0-140-0-210-crop.jpg?k=25768d15fa 2x"
                                className="image"
                              />
                              <span className="frame">
                                <span className="frame-title">
                                  ${moviePosters.original_title} (2021)
                                </span>
                              </span>
                            </div>
                          </li>
                        )
                      );
                    })}
                    <li className="listitem poster -placeholder"></li>
                    <li className="listitem poster -placeholder"></li>
                  </ul>
                  <span className="overlay"></span>{" "}
                </Link>
                <div >
                  {" "}
                  <h2 className="title-2 prettify">
                    <Link to={`/list-card/${lists._id}`}>
                      {lists.name.length > 170
                        ? lists.name.substr(0, 170) + " ..."
                        : lists.name}
                    </Link>{" "}
                  </h2>{" "}
                  {/* <span style={{display:"block"}}>sdf</span> */}
                  <br/>
                  <p className="list-summary-meta">
                    {" "}
                    <small className="value">
                      {lists.movieIds.length}&nbsp;{language === "EN" && "films" || language === "TR" && "film" || language === "DE" && "filme"}
                    </small>{" "}
                    <span className="content-metadata">
                      {" "}

                      <span className="has-icon icon-16 icon-like">
                        <span className="fas fa-heart"></span>&nbsp;{lists.listLikesCount}
                      </span>{" "}

                      <span className="has-icon icon-16 icon-comment">
                        <span className="fas fa-comment-alt"></span> 888{" "}
                      </span>{" "}

                    </span>{" "}
                  </p>
                </div>
              </section>
            );
          })}

          {/* <div className="pagination">
            <div className="paginate-nextprev paginate-disabled">
              <span className="previous">Newer</span>
            </div>{" "}
            <div className="paginate-nextprev">
              <a className="next" href="/jay/lists/page/2/">
                Older
              </a>
            </div>
            <div className="paginate-pages">
              <ul>
                <li className="paginate-page paginate-current">
                  <span>1</span>
                </li>{" "}
                <li className="paginate-page">
                  <a href="/jay/lists/page/2/">2</a>
                </li>
                <li className="paginate-page">
                  <a href="/jay/lists/page/3/">3</a>
                </li>
                <li className="paginate-page">
                  <a href="/jay/lists/page/4/">4</a>
                </li>
                <li className="paginate-page">
                  <a href="/jay/lists/page/5/">5</a>
                </li>{" "}
                <li className="paginate-page">
                  <a href="/jay/lists/page/6/">6</a>
                </li>
                <li className="paginate-page">
                  <a href="/jay/lists/page/7/">7</a>
                </li>
              </ul>
            </div>
          </div> */}
        </section>
        <div className="clear"></div>
      </section>
    </div>
  );
}
