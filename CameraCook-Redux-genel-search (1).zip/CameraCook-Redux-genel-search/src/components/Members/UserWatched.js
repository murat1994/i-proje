import React, {useEffect, useState} from 'react';
import { Link } from "react-router-dom"

export default function UserWatched(props) {
    const [state, setstate] = useState([]);
    

    useEffect(() => {
        //console.log(props.userInfo);
        GetWatchedMovies()
    }, [])

    const GetWatchedMovies = () => {

        setstate(props.state)
        console.log(props.state)
    }
    return (
        <ul className="poster-list -p70 -grid film-list clear" style={{paddingTop: "3%"}}>
					{state.map(movie=>{
                        return <li className="poster-container film-not-watched" key={movie?.movieId[0]._id}>
                            
                        <div className="react-component poster film-poster film-poster-63058 linked-film-poster removed-from-watchlist" 
                        data-component-class="globals.comps.FilmPosterComponent" 
                        data-film-id="63058" 
                        data-film-name="Avatar 2" 
                        data-poster-url="/film/avatar-2/image-150/" 
                        data-film-release-year="2022" 
                        data-new-list-with-film-action="/list/new/with/avatar-2/" 
                        data-remove-from-watchlist-action="/film/avatar-2/remove-from-watchlist/" 
                        data-add-to-watchlist-action="/film/avatar-2/add-to-watchlist/" 
                        data-rate-action="/film/avatar-2/rate/" 
                        data-mark-as-watched-action="/film/avatar-2/mark-as-watched/" 
                        data-mark-as-not-watched-action="/film/avatar-2/mark-as-not-watched/" 
                        data-film-link="/film/avatar-2/" 
                        data-film-in-watchlist="false">
                            <div>
                                <img src={`https://image.tmdb.org/t/p/w92/${movie?.movieId[0].image_path}`} 
                                width="70" height="105" alt="Avatar 2" 
                                srcset="https://a.ltrbxd.com/resized/film-poster/6/3/0/5/8/63058-avatar-2-0-140-0-210-crop.jpg?k=47047ec13a 2x" 
                                className="image"/><Link to={`/movie/${movie?.movieId[0].tmdb_id}`} 
                                className="frame has-menu" 
                                data-original-title="Avatar 2 (2022)">
                                    <span className="frame-title">Avatar 2 (2022)</span>
                                    <span className="overlay"></span>
                                    <span className="overlay-actions js-film-options -w70" style={{display: "none"}}>
                                        <span className="film-watch-link-target" data-film-id="63058">
                                            <span className="film-watch-link">
                                                <span className="has-icon icon-16 icon-watch ajax-click-action" 
                                                data-action="/film/avatar-2/mark-as-watched/">
                                                    <span className="replace icon"></span>Seen this film?</span></span></span>
                                                    <span className="like-link-target" data-likeable-uid="film:63058">
                                                        <span className="like-link">
                                                            <span className="has-icon icon-16 ajax-click-action  icon-like" 
                                                            data-action="/s/film:63058/like/" data-recaptcha-action="film_like">
                                                                <span className="icon"></span>Like this film?</span></span></span>
                                                                <span className="replace menu-link icon"></span></span></Link>
                                        </div>
                           </div> 
                          <p className="poster-viewingdata -rated-and-liked"> </p>
                          
                    </li>
                    })}
                    
                
                    
                
            </ul>
    )
}
