import React, {useEffect, useState} from 'react';
import { Link } from "react-router-dom";
import {useSelector } from "react-redux";

export default function UserWatchlist(props) {
    const [state, setstate] = useState([]);
    const [userInfo, setUserInfo] = useState({});
    const { language } = useSelector((state) => state.searchMovies);

    

    useEffect(() => {
        //console.log(props.userInfo);
        GetWatchlist()
    }, [])

    const GetWatchlist = () => {

        setstate(props.state.watchlist);
        setUserInfo(props.state)
        console.log(props.state)
    }
    return (
        <div className="cols-2 js-watchlist-content" 
data-path="/esi/watchlist/1320372/default/page/1/?esiAllowFilters=true&amp;esiAllowUser=true" data-num-entries="769">
			<section className="section col-24 col-main js-watchlist-main-content">
                <div id="content-nav" className="basic"> 
                <h1 className="section-heading">
                    <span className="replace-if-you" data-replacement="You want" data-person="jay">
                        {language === "EN" && `${userInfo.firstname} wants to see ${userInfo.watchlist?.length} films` || language === "TR" && `${userInfo.firstname} bu ${userInfo.watchlist?.length} filmi izlemek istiyor` || language === "DE" && `${userInfo.firstname} WILL ${userInfo.watchlist?.length} FILME SEHEN`} 
                    </span>
                </h1>
                {/* <div className="sorting-selects has-hide-toggle">
                    <section className="smenu-wrapper hide-toggle-menu"> 
                <div className="smenu"> <label><span className="ir s hide-toggle-icon">Visibility Filters</span>
                <i className="ir s icon"></i></label>
                </div>
                    </section>
                    <section className="smenu-wrapper"> <strong className="smenu-label">Sort by</strong> 
                <div className="smenu"> <label>When Added<i className="ir s icon"></i></label> 
                </div> 
                </section> 
                <section className="smenu-wrapper">
                    <div className="smenu"> <label>Service<i className="ir s icon"></i></label>
                    </div> 
                    </section>
                <section className="smenu-wrapper">
                    <div className="smenu"> <label> Genre<i className="ir s icon"></i> </label> 
                    </div> 
                    </section> <section className="smenu-wrapper"> 
                    <div className="smenu"> <label className="x"> Decade<i className="ir s icon"></i> </label> 
                    </div> </section> 
                    </div> <div className="clear">
                        </div>  */}
                </div>

                <ul className="poster-list -p125 -grid -scaled128">
                    {state.reverse().map(movie=>{
                        return <li className="poster-container film-not-watched" data-owner-rating="0" key={movie.movieId[0]._id}>
                            
                            <div className="react-component poster film-poster film-poster-581946 linked-film-poster removed-from-watchlist" data-component-class="globals.comps.FilmPosterComponent" data-film-id="581946" data-film-name="Jackass Forever" data-poster-url="/film/jackass-forever/image-150/" data-film-release-year="2021" data-new-list-with-film-action="/list/new/with/jackass-forever/" data-remove-from-watchlist-action="/film/jackass-forever/remove-from-watchlist/" data-add-to-watchlist-action="/film/jackass-forever/add-to-watchlist/" data-rate-action="/film/jackass-forever/rate/" data-mark-as-watched-action="/film/jackass-forever/mark-as-watched/" data-mark-as-not-watched-action="/film/jackass-forever/mark-as-not-watched/" data-film-link="/film/jackass-forever/" data-film-in-watchlist="false">
                                <div>
                                    <img src={`https://image.tmdb.org/t/p/w154/${movie?.movieId[0].image_path}`} 
                                width="125" height="187" alt="Jackass Forever" 
                                srcset="https://a.ltrbxd.com/resized/film-poster/5/8/1/9/4/6/581946-jackass-forever-0-250-0-375-crop.jpg?k=82e3107ec9 2x" className="image"/><Link to={`/movie/${movie.movieId[0].tmdb_id}`} className="frame has-menu" data-original-title="Jackass Forever (2021)"><span className="frame-title">Jackass Forever (2021)</span><span className="overlay"></span><span className="overlay-actions js-film-options -w125" style={{display: "none"}}><span className="film-watch-link-target" data-film-id="581946"><span className="film-watch-link"><span className="has-icon icon-16 icon-watch ajax-click-action" data-action="/film/jackass-forever/mark-as-watched/"><span className="replace icon"></span>Seen this film?</span></span></span><span className="like-link-target" data-likeable-uid="film:581946"><span className="like-link"><span className="has-icon icon-16 ajax-click-action  icon-like" data-action="/s/film:581946/like/" data-recaptcha-action="film_like"><span className="icon"></span>Like this film?</span></span></span><span className="replace menu-link icon"></span></span></Link>
                                </div>
                                </div>
                                
                        </li>
                    })}
                        
								
					</ul>
                    {/* <div className="pagination">
                        <div className="paginate-nextprev paginate-disabled"><span className="previous">Newer</span>
                        </div> 
                        <div className="paginate-nextprev"><a className="next" href="/jay/watchlist/page/2/">Older</a>
                        </div>
                        <div className="paginate-pages"> <ul> <li className="paginate-page paginate-current"><span>1</span></li> <li className="paginate-page"><a href="/jay/watchlist/page/2/">2</a></li> <li className="paginate-page"><a href="/jay/watchlist/page/3/">3</a></li> <li className="paginate-page unseen-pages">…</li> <li className="paginate-page"><a href="/jay/watchlist/page/28/">28</a></li> </ul>
                        </div> </div>
                
                    <div className="clear"></div> */}
			</section>				
		</div>
    )
}
