import React, {useEffect, useState} from 'react';
import axios from 'axios';
import { Link, useParams } from "react-router-dom"
import {useSelector } from "react-redux";
import { API_BASE }  from "../../actions/api_base";

export default function UserReviews(props) {

    const [state, setstate] = useState([]);
    const {memberId} = useParams()
    const [reviewLikes, setReviewLikes] = useState([]);
    const [watchedBy, setWatchedBy] = useState([]);
    const [editReviewClicked, setEditReviewClicked] = useState(false)
    const { language } = useSelector((state) => state.searchMovies);
    
    

    useEffect(() => {
        console.log(props);
        GetMovieReviews()
        const array = []
        props.currentUser[0]?.commentLikes.map(likes=>{
          return array.push(likes.commentId)
        })
        setReviewLikes(array)

        const array2 = []
        props.currentUser[0]?.watched.map(movie=>{
          return array2.push(movie.movieId[0].tmdb_id)
        })
        setWatchedBy(array2)
    }, [])

    const GetMovieReviews = () => {

        axios.get(`${API_BASE}comments/user/${memberId}`)
        .then(res=>{
            setstate(res.data.response.reverse())
            //console.log(res.data.response)
        })
        .catch(err=>console.log(err))
    }

    const ReviewLike = (e) => {
        console.log(e)
        
        axios.post(`${API_BASE}commentlikes`, {
          userId: props.currentUser[0]._id,
          commentId: e.target.id
        })
        .then(res=>{
          console.log(res.data)
          //console.log(e.target.className)
          if(e.target.className === "notLiked"){
            e.target.classList.remove("notLiked")
            e.target.classList.add("alreadyLiked")
            e.target.nextElementSibling.innerText = parseInt(e.target.nextElementSibling.innerText) +1
          } else if (e.target.className === "alreadyLiked"){
            e.target.classList.remove("alreadyLiked")
            e.target.classList.add("notLiked")
            e.target.nextElementSibling.innerText = parseInt(e.target.nextElementSibling.innerText) -1
          }
        })
        .catch(err=>console.log(err))
  
      }


      const EditReview = (e) => {
        if(!editReviewClicked){
            
            
            const targetInput = e.target.id + "59"
            e.target.parentElement.parentElement.parentElement.nextElementSibling.nextElementSibling.children[0].id = targetInput
            // e.target.parentElement.parentElement.parentElement.parentElement.nextElementSibling.children[1].id = targetInput
            e.target.parentElement.parentElement.parentElement.nextElementSibling.nextElementSibling.style.height = "280px"
            e.target.parentElement.parentElement.parentElement.nextElementSibling.nextElementSibling.children[0].disabled = false;
            e.target.parentElement.parentElement.parentElement.nextElementSibling.nextElementSibling.children[0].style.border = "red solid 2px"
            e.target.parentElement.href = `#${targetInput}`
            

            setEditReviewClicked(true)
        }
    }

    const RemoveReview = (e) => {
        if(!editReviewClicked){
            axios.delete(`${API_BASE}comments/${e.target.id}`)
            .then(res=>{
                //console.log(res.data)
                GetMovieReviews()
            })
            .catch(err=>console.log(err))
        }
    }

    const updateReview = (e) => {
        
        const str = e.target.id
        

      if(e.target.value !== ""){
        axios.put(`${API_BASE}comments/${str.substring(0, str.length - 2)}`, {content: e.target.value})
            .then(res=>{
                //console.log(res.data);
                e.target.parentElement.style.height = "110px"
                e.target.style.border = "none";
                e.target.disabled = true;
                setTimeout(() => {
                    setEditReviewClicked(false)
                }, 1000);
                GetMovieReviews()
            })
            .catch(err=>console.log(err))
      } else {
        axios.delete(`${API_BASE}comments/${str.substring(0, str.length - 2)}`)
        .then(res=>{
            //console.log(res.data)
            e.target.parentElement.style.height = "110px"
                e.target.style.border = "none";
                e.target.disabled = true;
                setTimeout(() => {
                    setEditReviewClicked(false)
                }, 1000);
                GetMovieReviews()
        })
        .catch(err=>console.log(err))        
      } 
    }

    console.log(state)
    return (
        <div >
            <section className="section col-main overflow col-17" >
			

			<ul className="poster-list -p70 film-list clear film-details-list no-title" style={{paddingTop: "3%"}}>
                {state?.map(review=>{
                    return review.movieId.length !== 0 &&
                        <li className="film-detail film-not-watched" key={review._id}> 
                    <div className="react-component poster film-poster film-poster-479814 linked-film-poster removed-from-watchlist" data-component-class="globals.comps.FilmPosterComponent" data-film-id="479814" data-film-name="Free Guy" data-poster-url="/film/free-guy/image-150/" data-film-release-year="2021" data-new-list-with-film-action="/list/new/with/free-guy/" data-remove-from-watchlist-action="/film/free-guy/remove-from-watchlist/" data-add-to-watchlist-action="/film/free-guy/add-to-watchlist/" data-rate-action="/film/free-guy/rate/" data-mark-as-watched-action="/film/free-guy/mark-as-watched/" data-mark-as-not-watched-action="/film/free-guy/mark-as-not-watched/" data-film-link="/film/free-guy/" data-film-in-watchlist="false">
                        <Link to={`/movie/${review.movieId[0]?.tmdb_id}`}>
                        <div>
                            <img src={`https://image.tmdb.org/t/p/w154/${review?.movieId[0]?.image_path}`} width="70" height="105" alt="Free Guy" srcSet="https://a.ltrbxd.com/resized/film-poster/4/7/9/8/1/4/479814-free-guy-0-140-0-210-crop.jpg?k=68c7eacffb 2x" className="image"/>
                            {/* <a href={`/movie/${review.movieId[0]?.tmdb_id}`} className="frame"><span className="frame-title">{review?.movieId?.original_title} (2021)</span><span className="overlay"></span></a> */}
                        </div>
                        </Link>
                        </div> 
                        <div className="film-detail-content"> 
                        <h2 className="headline-2 prettify"><Link to={`/movie/${review.movieId[0]?.tmdb_id}`}>{review?.movieId[0]?.original_title.length > 30 ? review?.movieId[0]?.original_title.substr(0, 30) + "..." : review?.movieId[0]?.original_title}</Link> 
                        {review.userId[0]._id === props.currentUser[0]._id ?
                            <span style={{position: "absolute",right:"0"}}>
                                <a><i className="fas fa-edit" style={{cursor:"pointer", marginRight:"10px",fontSize:"medium"}}  id={review._id}  onClick={EditReview}></i></a>
                                <i className="fas fa-trash" id={review._id} style={{cursor:"pointer",fontSize:"medium"}} onClick={RemoveReview}></i>
                            </span> : ""
                        }
                        </h2>
                        <div className="attribution-block -large"> <p className="attribution"> <span className="rating -green rated-4"> ★★ </span> <span className="content-metadata"><span className="date"> <a href="/jay/film/free-guy/" className="context"> 
                        {watchedBy.includes(review.movieId[0]?.tmdb_id) ? "Watched by " : "Commented by "}
                        <strong className="name">{review.userId[0]?.firstname}</strong> </a> 
                        {/* <span className="_nobr">18 Aug 2021</span> */} 
                        <i className="fa fa-calendar-o" aria-hidden="true"></i>
                         </span> 
                         {/* <a href="/jay/film/free-guy/" className="has-icon icon-comment icon-16 comment-count"><span className="icon"></span>3</a> */}
                         </span> </p>
                         </div>
                          <div id="ctn" className="body-text -prose collapsible-text" data-full-text-url="/s/full-text/viewing:190369905/"> 
                          {/* <p>
                          {review.content.length > 200 ? review.content.substr(0,200) + "..." : review.content}
                          </p>  */}
                          <textarea type="text" id={review._id} className="target-label" defaultValue={review.content} style={{backgroundColor:"#141414", border:"none", width:"550px", height:"110px", lineHeight:"30px",paddingTop:"10px", resize:"none"}} disabled={true} onBlur={updateReview}/>
                          </div> 
                          <p className="like-link-target react-component -monotone" data-component-class="globals.comps.LikeLinkComponent" data-likeable-uid="viewing:190369905" data-likeable-name="review" data-likeable="true" data-likes-page="/jay/film/free-guy/likes/" data-format="svg" data-owner="jay"><span >
                                  <span
                                        onClick={ReviewLike}
                                          id={review._id}
                                          className={reviewLikes.includes(review._id) ? "alreadyLiked" : "notLiked"}
                                        >
                                          Like review
                                        </span>
                                    &nbsp;
                                    <span style={{color:"#9ab"}}>
                                      {review.commentLikesCount}
                                    </span>
                                    &nbsp;
                                    <span style={{color:"#9ab"}}>
                                      likes
                                    </span>
                                  </span></p>
                           </div> </li>
                    
                    
                })}
	
			</ul>

			
			{/* <div className="pagination">
                 <div className="paginate-nextprev paginate-disabled"><span className="previous">Newer</span>
                 </div> 
                 <div className="paginate-nextprev"><a className="next" href="/jay/films/reviews/page/2/">Older</a>
                 </div>
                  <div className="paginate-pages"> 
				  <ul> 
					  <li className="paginate-page paginate-current"><span>1</span></li> 
				  <li className="paginate-page"><a href="/jay/films/reviews/page/2/">2</a></li>
				   <li className="paginate-page"><a href="/jay/films/reviews/page/3/">3</a></li>
				    <li className="paginate-page unseen-pages">…</li> 
					<li className="paginate-page"><a href="/jay/films/reviews/page/91/">91</a></li>
					 </ul> 
                  </div>
                   </div>
		
                <div className="clear"></div> */}
            </section>




            {/* <aside className="sidebar">
                <section className="section"> <h3 className="section-heading"><a href="/jay/tags/">Review Tags</a></h3>
                <a href="/jay/tags/reviews/" className="all-link">78</a>
                <ul className="tags clear"> <li>
                    <a href="/jay/tag/watched-with-iana/reviews/"> watched with iana </a> </li>
                        <li> <a href="/jay/tag/watched-with-charlie/reviews/"> watched with charlie </a> </li> 
                        <li> <a href="/jay/tag/watched-with-jess/reviews/"> watched with jess </a> </li>
                        <li> <a href="/jay/tag/watched-with-lyanna/reviews/"> watched with lyanna </a> </li> 
                        <li> <a href="/jay/tag/watched-with-ross/reviews/"> watched with ross </a> </li>
                        <li> <a href="/jay/tag/quaran-streamed/reviews/"> quaran-streamed </a> </li> 
                        <li> <a href="/jay/tag/watched-with-will/reviews/"> watched with will </a> </li>
                        <li> <a href="/jay/tag/watched-with-family/reviews/"> watched with family </a> </li>
                            <li> <a href="/jay/tag/watched-with-rhiannon/reviews/"> watched with rhiannon </a> </li> 
                            <li> <a href="/jay/tag/watched-with-sayna/reviews/"> watched with sayna </a> </li> 
                            <li> <a href="/jay/tag/watched-with-adam/reviews/"> watched with adam </a> </li> 
                            <li> <a href="/jay/tag/london-film-festival/reviews/"> london film festival </a> </li> 
                            <li> <a href="/jay/tag/watched-with-kirst/reviews/"> watched with kirst </a> </li> <li> <a href="/jay/tag/watched-with-leon/reviews/"> watched with leon </a> </li> <li> <a href="/jay/tag/watched-with-connor/reviews/"> watched with connor </a> </li> <li> <a href="/jay/tag/watched-with-ella/reviews/"> watched with ella </a> </li> <li> <a href="/jay/tag/watched-with-patrick/reviews/"> watched with patrick </a> </li> <li> <a href="/jay/tag/watched-with-sam/reviews/"> watched with sam </a> </li> <li> <a href="/jay/tag/uk-premiere/reviews/"> uk premiere </a> </li> <li> <a href="/jay/tag/watched-with-louis/reviews/"> watched with louis </a> </li> <li> <a href="/jay/tag/argo/reviews/"> argo </a> </li> <li> <a href="/jay/tag/screener/reviews/"> screener </a> </li> <li> <a href="/jay/tag/watched-with-harry/reviews/"> watched with harry </a> </li> <li> <a href="/jay/tag/watched-with-work/reviews/"> watched with work </a> </li> <li> <a href="/jay/tag/watched-with-yazz/reviews/"> watched with yazz </a> </li> <li> <a href="/jay/tag/at-a-cinema/reviews/"> at a cinema </a> </li> <li> <a href="/jay/tag/cannes-film-festival/reviews/"> cannes film festival </a> </li> <li> <a href="/jay/tag/watched-with-ash/reviews/"> watched with ash </a> </li> <li> <a href="/jay/tag/boothathon/reviews/"> boothathon </a> </li> <li> <a href="/jay/tag/princes-charles-cinema/reviews/"> princes charles cinema </a> </li> <li> <a href="/jay/tag/watched-with-ben/reviews/"> watched with ben </a> </li> <li> <a href="/jay/tag/watched-with-caitie/reviews/"> watched with caitie </a> 
                </li> 
                </ul> 
                </section>

            </aside> */}

            {/* <div className="clear"></div> */}
        </div>
    )
}
