import React, { useState } from 'react';
import '../components/css/Footer.css';
import {Link} from 'react-router-dom';


import {
	IoIosArrowUp
} from 'react-icons/io';

const Footer = () => {


	return (
		<div className="footer-top">
		<div >
		<footer id="contact" className="footer-one iq-bg-dark">
     
		 {/* <!-- Address --> */}
		 <div >
				 <div className="footer-top container-fluid-footer">
						 <div className="row-footer footer-standard">
								 <div className="col-lg-7">
										 <div className="widget text-left">
												 <div className="menu-footer-link-1-container">
														 <ul id="menu-footer-link-1" className="menu p-0">
																 <li id="menu-item-7314" className="menu-item menu-item-type-post_type menu-item-object-page menu-item-7314">
																		 <Link to="#">Terms Of Use</Link>
																 </li>
																 <li id="menu-item-7316" className="menu-item menu-item-type-post_type menu-item-object-page menu-item-7316">
																		 <Link to="../html/privacy-policy.html">Privacy-Policy</Link>
																 </li>
																 <li id="menu-item-7118" className="menu-item menu-item-type-post_type menu-item-object-page menu-item-7118">
																		<Link to="../html/faq.html">FAQ</Link>
																</li>
																 <li id="menu-item-7118" className="menu-item menu-item-type-post_type menu-item-object-page menu-item-7118">
																		 <Link to="../html/watch-video.html">Watch List</Link>
																 </li>
														 </ul>
												 </div>
										 </div>
										 <div className="widget text-left">			
												 <div className="textwidget">
														 <p><small>© 2021 CINETRAIL. All Rights Reserved. All videos and shows on this platform are trademarks of, and all related images and content are the property of, XPRSOFT Duplication and copy of this is strictly prohibited. All rights reserved. </small></p>
												 </div>
										 </div>                        
								 </div>
								 <div className="col-lg-2 col-md-6 mt-4 mt-lg-0">
										 <h6 className="footer-link-title">
												 Follow Us :
										 </h6>
										 <ul className="info-share"> 
												 <li><Link  target="_blank" to="#"><i className="icon-hover fa fa-facebook"></i></Link></li>
												 <li><Link  target="_blank" to="#"><i className="icon-hover fa fa-twitter"></i></Link></li>
												 <li><Link  target="_blank" to="#"><i className="icon-hover fa fa-google-plus"></i></Link></li>
												 <li><Link  target="_blank" to="#"><i className="icon-hover fa fa-github"></i></Link></li>
												
                             
                           
										 </ul>

								 </div>
								 <div className="col-lg-3 col-md-6 mt-4 mt-lg-0">
										 <div className="widget text-left">
												 <div className="textwidget">
														 <h6 className="footer-link-title">Cinetrail App</h6>
														 <div className="d-flex align-items-center">
																 <Link className="app-image" to="#">
																		 <img src="https://vinzator.com/movieProject/images/footer/01.png" alt="play-store"/>
																 </Link>
																 <Link className="ml-3 app-image" to="#"><img src="https://vinzator.com/movieProject/images/footer/02.png" alt="app-store"/></Link>
														 </div>
												 </div>
										 </div>
								 </div>
						 </div>
				 </div>
		 </div>
		 <li><a className="top" href="#top"><IoIosArrowUp/></a></li>
		 {/* <!-- Address END --> */}
 </footer>
		</div>
		</div>
	);
};

export default Footer;