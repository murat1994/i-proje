import React, { useEffect, useState } from "react";
import "./css/Parallax.css";
import { FaStar, FaStarHalf } from "react-icons/fa";
import { Link } from "react-router-dom";
import axios from "axios";

export const Parallax = () => {
  const [movie, setMovie] = useState({});

  useEffect(() => {
    const latestMovie = async () => {
      try {
        const {
          data: { results },
        } = await axios.get(
          `https://api.themoviedb.org/3/discover/tv?api_key=${process.env.REACT_APP_API_KEY}&with_networks=213`
        );
        setMovie(results[
          Math.floor(Math.random() *results.length -1)
      ]);
      } catch (error) {}
    };
    latestMovie();
  }, []);

  return (
    <div>
      <div className="carousel-inner">
        <div className="carousel-item active">
          <div
            className="slick-bg1 d-block"
            alt="..."
            style={{
              backgroundImage: `url(
                https://image.tmdb.org/t/p/w1280/${movie?.backdrop_path}
              )`,
            }}
          ></div>
          <div className="parallax-carousel-caption container-fluid d-block">
            <div className="row">
              <div className="col-4">
                <h5
                  className="animated fadeInLeft"
                  style={{ animationDelay: 0.6 + "s" }}
                >
                  {movie?.name}
                </h5>
                <div className="d-flex flex-wrap align-items-center fadeInLeft animated">
                  <div className="slider-ratting d-flex align-items-center me-4 mt-2 my-md-3">
                    <span className="text-white ml-2">{movie?.vote_average}(Imbd)</span>
                  </div>
                  <div className="d-flex align-items-center my-2">
                    <span className="badge badge-secondary p-2">Season</span>
                    <span className="ms-3">TvShows</span>
                  </div>
                </div>
                <p
                  className="animated fadeInUp info-p"
                  style={{ animationDelay: 1.2 + "s" }}
                >
                  {movie?.overview}
                </p>

                <div
                  className="d-flex align-items-center r-mb-23 fadeInUp animated "
                  style={{ animationDelay: 1.2 + "s" }}
                >
                  <Link to="/" className="play-now btn-hover">
                    PLAY NOW
                  </Link>
                  <Link to={`/movie/${movie?.id}`} className="more-details">
                    More Details
                  </Link>
                </div>
              </div>
              <div className="col-8">
                <div className="parallax-img">
                  <Link to={`/movie/${movie.id}`}>
                    <img
                      src={`https://image.tmdb.org/t/p/w780/${movie?.backdrop_path}`}
                      className="prlx-img-fluid w-100 dikey"
                      alt="bailey"
                    />
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
