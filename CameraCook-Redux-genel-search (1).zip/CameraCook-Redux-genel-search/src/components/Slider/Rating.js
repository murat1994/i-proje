import React from "react";
import { FaStar, FaStarHalf } from "react-icons/fa";
import { BsStar } from "react-icons/bs";
const Rating = ({ vote_average }) => {
  return (
    <>
      <li>
        {vote_average / 2 >= 1 ? (
          <FaStar className="fa slider-fa" />
        ) : vote_average / 2 >= 0.5 ? (
          <FaStarHalf className="fa slider-fa" />
        ) : (
          <BsStar className="fa slider-fa" />
        )}
      </li>
      <li>
        {vote_average / 2 >= 2 ? (
          <FaStar className="fa slider-fa" />
        ) : vote_average / 2 >= 1.5 ? (
          <FaStarHalf className="fa slider-fa" />
        ) : (
          <BsStar className="fa slider-fa" />
        )}
      </li>
      <li>
        {vote_average / 2 >= 3 ? (
          <FaStar className="fa slider-fa" />
        ) : vote_average / 2 >= 2.5 ? (
          <FaStarHalf className="fa slider-fa" />
        ) : (
          <BsStar className="fa slider-fa" />
        )}
      </li>
      <li>
        {vote_average / 2 >= 4 ? (
          <FaStar className="fa slider-fa" />
        ) : vote_average / 2 >= 3.5 ? (
          <FaStarHalf className="fa slider-fa" />
        ) : (
          <BsStar className="fa slider-fa" />
        )}
      </li>
      <li>
        {vote_average / 2 >= 5 ? (
          <FaStar className="fa slider-fa" />
        ) : vote_average / 2 >= 4.5 ? (
          <FaStarHalf className="fa slider-fa" />
        ) : (
          <BsStar className="fa slider-fa" />
        )}
      </li>
    </>
  );
};

export default Rating;
