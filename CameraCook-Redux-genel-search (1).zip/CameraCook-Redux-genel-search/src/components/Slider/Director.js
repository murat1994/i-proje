import axios from "axios";
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useSelector } from "react-redux";

const Director = ({ id, type }) => {
  const [directorName, setDirectorName] = useState("");
  const { language } = useSelector((state) => state.searchMovies);
  useEffect(() => {
    axios
      .get(
        `https://api.themoviedb.org/3/movie/${id}?api_key=${process.env.REACT_APP_API_KEY}&append_to_response=credits&language=tr-TR`
      )
      .then(
        ({
          data: {
            credits: { crew },
          },
        }) => {
          setDirectorName(crew.find((el) => el?.job === "Director")?.name);
        }
      );
  }, [id]);
  if (type === "slider") {
    return (
      <div className="title starring ">
        {language === "EN" && "Director" || language === "TR" && "Yönetmen" || language === "DE" && "Direktor"}: <span className="text-white">{directorName}</span>
      </div>
    );
  }
  if (type === "movieCard") {
    return (
      <Link to={`/director/${directorName}/`}>
        <span className="prettify">{directorName}</span>
      </Link>
    );
  }
};

export default Director;