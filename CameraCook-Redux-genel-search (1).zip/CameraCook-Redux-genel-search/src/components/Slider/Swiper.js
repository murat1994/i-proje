import SwiperCore, { Navigation, Pagination, Scrollbar, A11y } from "swiper";
import "../css/Slider.css";
import { useDispatch, useSelector } from "react-redux";

import SliderSingleMovie from "./SliderSingleMovie";
import "reactjs-popup/dist/index.css";
import React, { useState, useEffect } from "react";
import { Swiper, SwiperSlide } from "swiper/react";

// Import Swiper styles
import "swiper/swiper.scss";
import "swiper/components/navigation/navigation.scss";
import "swiper/components/pagination/pagination.scss";
import "swiper/components/scrollbar/scrollbar.scss";
import getPopularMovies from "../../actions/popularMovies";

// install Swiper modules
SwiperCore.use([Navigation, Pagination, Scrollbar, A11y]);

const Slider = () => {
  const { trailers: storeTrailers } = useSelector((state) => state.getTrailers);
  const { language } = useSelector((state) => state.searchMovies);
  const [trailers, setTrailers] = useState(storeTrailers);
  const dispatch = useDispatch();
  
  useEffect(() => {
    // setTrailers(storeTrailers);
    dispatch(getPopularMovies()); 
  }, [language]); 
  //console.log(language,'hasan' );

  useEffect(() => {
    setTrailers(storeTrailers);
    // dispatch(getPopularMovies()); 
  }, [storeTrailers]); 
  
  return (
    <div
      id="carouselExampleCaptions"
      className="carousel slide"
      data-bs-ride="carousel"
    >
      <Swiper
        className="mySwiper"
        spaceBetween={50}
        slidesPerView={1}
        navigation
        pagination={{ clickable: true }}
        scrollbar={{ draggable: true }}
        // onSwiper={(swiper) => console.log(swiper)}
        // onSlideChange={() => console.log("slide change")}
      >
        {trailers.length > 0 &&
          trailers.map((movie) => (
            <SwiperSlide className="slick-bg d-block" key={movie.id}>
              <SliderSingleMovie {...movie} />
            </SwiperSlide>
          ))}
      </Swiper>
    </div>
  );
};
export default Slider;
