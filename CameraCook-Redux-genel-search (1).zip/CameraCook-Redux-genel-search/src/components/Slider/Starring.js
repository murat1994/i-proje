import axios from "axios";
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";

const Starring = ({ id, page }) => {
  const [cast, setCast] = useState([]);

  useEffect(() => {
    axios
      .get(
        `https://api.themoviedb.org/3/movie/${id}?api_key=${process.env.REACT_APP_API_KEY}&append_to_response=credits&language=tr-TR`
      )
      .then(
        ({
          data: {
            credits: { cast },
          },
          
        }) => {
          setCast(cast.map((info) => info));
          
        }
      );
  }, [id]);
  //console.log(cast)
  if (page === "slider") {
    return <span className="text-white">{cast?.map((name,index)=>{
      return index<5 && name.name+", "
    })}</span>;
  }
  if (page === "movie") {
    return (
      <p>
        {cast.map((person) => (
          <Link
            key={person.name}
            to={`/people/${person.id}`}
            className="text-slug tooltip starring "
            data-original-title="Harleen Quinzel / Harley Quinn"
          >
            {person.name}
          </Link>
        ))}
      </p>
    );
  }
};

export default Starring;
