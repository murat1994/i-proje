import React, { useState, useEffect } from "react";
import "../css/Slider.css";

import Carousel from "react-bootstrap/Carousel";
import "reactjs-popup/dist/index.css";

import { useSelector } from "react-redux";

import SliderSingleMovie from "./SliderSingleMovie";
export const Slider = () => {
  const { trailers: storeTrailers } = useSelector((state) => state.getTrailers);
  const [trailers, setTrailers] = useState(storeTrailers);

  const [index, setIndex] = useState(0);

  const handleSelect = (selectedIndex, e) => {
    setIndex(selectedIndex);
  };
  useEffect(() => {
    setTrailers(storeTrailers);
  }, [storeTrailers]);

  return (
    <div
      id="carouselExampleCaptions"
      className="carousel slide"
      data-bs-ride="carousel"
    >
      <Carousel activeIndex={index} onSelect={handleSelect} timeout={0}>
        {trailers.length > 0 &&
          trailers.map((movie) => (
            <Carousel.Item
              key={movie.id}
              type="button"
              data-bs-target="#carouselExampleCaptions"
              data-bs-slide-to="2"
              aria-label="Slide 3"
            >
              <SliderSingleMovie {...movie} />
            </Carousel.Item>
          ))}
      </Carousel>
    </div>
  );
};
