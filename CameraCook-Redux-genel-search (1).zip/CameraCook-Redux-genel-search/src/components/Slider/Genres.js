import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import genresObject from "../../genres.json";
const Genres = ({ genre_ids }) => {
  const { language } = useSelector((state) => state.searchMovies);
  const [genreObject, setGenreObject] = useState("genresEnglish");
  useEffect(() => {
    setGenreObject(
      (language == "EN" && "genresEnglish") ||
        (language == "TR" && "genresTurkish") ||
        (language == "TR" && "genresTurkish") ||
        "genresGerman"
    );
  }, [language]);

  return (
    <div className="title starring ">
      {language === "EN" && "Genres" || language === "TR" && "Tür" || language === "DE" && "Genres"}:{" "}
      {genre_ids?.map((genre, idx) => {
        return (
          <span key={idx} className="text-white">
            {genresObject[genreObject]?.filter(
              ({ id, name }) => id === genre
            )[0].name + ", "}
          </span>
        );
      })}
    </div>
  );
};

export default Genres;
