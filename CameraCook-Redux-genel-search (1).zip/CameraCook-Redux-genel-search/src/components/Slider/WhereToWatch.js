import axios from "axios";
import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";


const WhereToWatch = ({ id }) => {
  const [providers, setProviders] = useState([]);
  const { language } = useSelector((state) => state.searchMovies);
  useEffect(() => {
    axios
      .get(`https://api.themoviedb.org/3/movie/${id}/watch/providers?api_key=${process.env.REACT_APP_API_KEY}`)
      .then(({ data: { results } }) => {
        //console.log(results);
        setProviders(results?.US?.flatrate);
      });
  }, [id]);

  return (
    <>
      {providers?.length > 0 && (
        <nav aria-label="breadcrumb">
          <ol className="breadcrumb watch-panel">
            <li className="breadcrumb-item">
              <h3 className="hdtitle watch-panel js-watch-panel">
              {language === "EN" && "Where to watch" || language === "TR" && "Nerede İzlenir" || language === "DE" && "Wo zu sehen"}
              </h3>{" "}
            </li>

            {providers
              .filter((el) => !!el)
              .map(({ logo_path, provider_name }, idx) => (
                <li key={idx} className=" hdtitle-child " 
                // className="breadcrumb-item hdtitle-child " 
                style={{marginRight:"10px",cursor:"unset", display: "inline" }}>
                  <span
                    // href={`https://www.${provider_name.toLowerCase().split(" ")[0]}.com`}
                    target="_blank"
                    rel="noreferrer"
                  >
                    <img
                      width="24"
                      height="24"
                      alt={provider_name}
                      src={`https://image.tmdb.org/t/p/original/${logo_path}`}
                      className="where-play-icon"
                    />
                  </span>
                </li>
              ))}
          </ol>
        </nav>
      )}
    </>
  );
};

export default WhereToWatch;