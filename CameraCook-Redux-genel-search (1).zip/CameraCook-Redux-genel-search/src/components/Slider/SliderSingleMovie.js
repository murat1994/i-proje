import React, { useState } from "react";
import { Link } from "react-router-dom";
import { useSelector } from "react-redux";
import Rating from "./Rating";
import Director from "./Director";
import Modal from "../VideoModal1";
import PlayButton from "./PlayButton";
import "../css/Slider.css";
import Genres from "./Genres";
import Carousel from "react-bootstrap/Carousel";
import "reactjs-popup/dist/index.css";
import WhereToWatch from "./WhereToWatch";
import Starring from "./Starring";
const SliderSingleMovie = ({
  adult,
  backdrop_path,
  genre_ids,
  id,
  original_title,
  overview,
  name,
  first_air_date,
  popularity,
  poster_path,
  relase_date,
  title,
  vote_average,
  vote_count,
  setModalVisibility
}) => {
  const { language } = useSelector((state) => state.searchMovies);
  
  return (
    <>
      <img
        src={` https://image.tmdb.org/t/p/original/${backdrop_path}`}
        className="slick-bg d-block w-100 yatay"
        alt="Fashion"
      />
      <img
        src={`https://image.tmdb.org/t/p/original/${poster_path}`}
        className="slick-bg d-block w-100 dikey"
        alt="Animal"
      />

      <Carousel.Caption>
        <ul className="carousel-caption d-block">
          <a href="javascript:void(0);" tabIndex="0">
            <div
              className="channel-logo fadeInLeft animated"
              data-animation-in="fadeInLeft"
              data-delay-in="0.5"
              style={{ opacity: "1 animation-delay: 0.5s" }}
            >
              <img
                src="https://vinzator.com/movieProject/logo.png"
                className="c-logo"
                alt="CineTrail"
              />
            </div>
          </a>

          <h1
            className="slider-text big-title
          
          title text-uppercase fadeInLeft animated "
            data-animation-in="fadeInLeft"
            style={{ opacity: "1" }}
          >
            {original_title}
          </h1>
          <div className="d-flex flex-wrap align-items-center fadeInLeft animated ">
            <div className="slider-ratting d-flex align-items-center me-4 mt-2 my-md-3">
              <ul className="ratting-start p-0 m-0 list-inline d-flex align-items-center justify-content-left">
                <Rating vote_average={vote_average} />
              </ul>
              <span className="text-white ml-2">{vote_average}(Imdb)</span>
            </div>
            <div className="d-flex align-items-center my-2">
              <span className="badge badge-secondary p-2">
                {adult && "+18"}
              </span>
            </div>
          </div>
          {/* NERDE FILM IZLE BASLADI  */}
          <WhereToWatch id={id} />
          {/* NERDE FILMI IZLE BITTI */}
          <p
            className="text-white animated fadeInUp info-p "
            style={{ animationDelay: 1.2 + "s" }}
          >
            {overview}
          </p>
          <div className="slider-trending-list">
            <div className="title starring ">
            {language === "EN" && "Starrings" || language === "TR" && "Oyuncular" || language === "DE" && "Sternenringe"}: <Starring page={"slider"} id={id} />{" "}
            </div>
            <Genres genre_ids={genre_ids} type="slider" />

            <Director id={id} type="slider" />
          </div>
          <div></div>
          <div
            className="d-flex align-items-center r-mb-23 fadeInUp animated "
            style={{ animationDelay: 1.2 + "s" }}
          >
            <a>
              {" "}
              <Modal id={id} />{" "}
            </a>
            <Link to={`/movie/${id}`} className="more-details">
            {language === "EN" && "More Details" || language === "TR" && "Daha Fazlasi" || language === "DE" && "Mehr Details"}
            </Link>{" "}
          </div>
          {/* <PlayButton /> */}
        </ul>
      </Carousel.Caption>
    </>
  );
};

export default SliderSingleMovie;
