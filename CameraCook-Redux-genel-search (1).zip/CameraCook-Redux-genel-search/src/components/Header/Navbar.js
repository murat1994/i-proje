import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";

import { useDispatch, useSelector } from "react-redux";
import { useHistory, useLocation } from "react-router-dom";
import { logout } from "../../actions/auth.action";
import SearchToggle from "./SearchToggle";
import { searchMovie } from "../../utils/search";
import DropDowns from "./DropDowns";

const Navbar = () => {
  const [searchTerm, setSearchTerm] = useState(" ");
  const [movie, setMovie] = useState([]);
  useEffect(() => {
    searchMovie(searchTerm, setMovie);
  }, [searchTerm]);

  return (
    <>
      <DropDowns />
      <SearchToggle />
    </>
  );
};

export default Navbar;
