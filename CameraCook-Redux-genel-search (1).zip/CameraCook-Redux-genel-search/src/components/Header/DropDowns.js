import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { useHistory, useLocation } from "react-router-dom";
import { logout } from "../../actions/auth.action";
import { Link } from "react-router-dom";
import Notifications from "./Notification";
import Search from "./Search";
import "./DropDowns.css";

const DropDowns = () => {
  const { user } = useSelector((state) => state.auth);
  const history = useHistory();

  const dispatch = useDispatch();

  const handleLogout = () => {
    dispatch(logout());
    history.push("/");
  };

  return (
    <>
      <Link
        to="#"
        className="navbar-toggler c-toggler collapsed"
        data-toggle="collapse"
        data-target="#navbarSupportedContent"
        aria-controls="navbarSupportedContent"
        aria-expanded="false"
        aria-label="Toggle navigation"
      >
        <div className="navbar-toggler-icon" data-toggle="collapse">
          <span className="navbar-menu-icon navbar-menu-icon--top"></span>
          <span className="navbar-menu-icon navbar-menu-icon--middle"></span>
          <span className="navbar-menu-icon navbar-menu-icon--bottom"></span>
        </div>
      </Link>
      <Link className="navbar-brand" to="/">
        {" "}
        <img
          className="img-fluid logo"
          src="https://vinzator.com/movieProject/logo.png"
          alt="CineTrail"
        />{" "}
      </Link>
      <div className="navbar-collapse collapse" id="navbarSupportedContent">
        <div className="menu-main-menu-container">
          <ul id="top-menu" className="navbar-nav ml-auto">
            <li className="menu-item">
              <Link to="/">Home</Link>
            </li>

            <li className="menu-item">
              <Link to="#">Medias</Link>
              <ul className="sub-menu">
                <li className="menu-item under-line">
                  <Link to="/movies">Movies</Link>
                </li>

                <li className="menu-item under-line">
                  <Link to="/list">List</Link>
                </li>

                <li className="menu-item under-line">
                  <Link to="/members">Members</Link>
                </li>

                <li className="menu-item under-line">
                  <Link to="/search-page">SearchPage</Link>
                </li>
            
                
              </ul>
            </li>
            <li className="menu-item">
              <Link to="/">Blog</Link>
            </li>

            <li className="menu-item">
              <Link to="/">Pages</Link>
              <ul className="sub-menu">
                <li className="menu-item under-line">
                  <Link to="/about">About Us</Link>
                </li>
                <li className="menu-item under-line">
                  <Link to="/contact-us">Contact</Link>
                </li>
                <li className="menu-item under-line">
                  <Link to="/faq">FAQ</Link>
                </li>
                <li className="menu-item under-line">
                  <Link to="/policies">Privacy-Policy</Link>
                </li>
              </ul>
            </li>

            <li className="menu-item">
              <Link
                to="/list/add-new-list/"
                id="add-new-button"
                className="button -action button-action button-add cboxElement"
              >
              ADD LIST
              </Link>
              </li>
       
          </ul>
        </div>
      </div>

      <div className="mobile-more-menu">
        <Link
          href="javascript:void(0);"
          className="more-toggle"
          id="dropdownMenuButton"
          data-toggle="more-toggle"
          aria-haspopup="true"
          aria-expanded="false"
        >
          <i className="ri-more-line"></i>
        </Link>
        <div className="more-menu" aria-labelledby="dropdownMenuButton">
          <div className="navbar-right position-relative">
            <ul className="d-flex align-items-center justify-content-end list-inline m-0">
              <li>
                <Link to="/" className="search-toggle">
                  <i className="ri-search-line"></i>
                </Link>
                <div className="search-box iq-search-bar">
                  <form action="#" className="searchbox">
                    <div className="form-group position-relative">
                      <input
                        type="text"
                        className="text search-input font-size-12"
                        placeholder="type here to search..."
                      />
                      <i className="search-link ri-search-line"></i>
                    </div>
                  </form>
                </div>
              </li>

              <li>
                <select name="change_language" className="select-language">
                  <option className="turkce">TR</option>
                  <option className="english">EN</option>
                  <option className="german">DE</option>
                </select>
              </li>

              <li className="nav-item nav-icon">
                <Link to="/" className="search-toggle position-relative">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    viewBox="0 0 24 24"
                    width="22"
                    height="22"
                    className="noti-svg"
                  >
                    <path fill="none" d="M0 0h24v24H0z"></path>
                    <path d="M18 10a6 6 0 1 0-12 0v8h12v-8zm2 8.667l.4.533a.5.5 0 0 1-.4.8H4a.5.5 0 0 1-.4-.8l.4-.533V10a8 8 0 1 1 16 0v8.667zM9.5 21h5a2.5 2.5 0 1 1-5 0z"></path>
                  </svg>
                  <span className="bg-danger dots"></span>
                </Link>
                <div className="iq-sub-dropdown">
                  <div className="iq-card shadow-none m-0">
                    <div className="iq-card-body">
                      <Link to="/" className="iq-sub-card">
                        <div className="media align-items-center">
                          <img
                            src="https://vinzator.com/movieProject/images/notify/thumb-1.jpg"
                            className="img-fluid mr-3"
                            alt="CineTrail"
                          />
                          <div className="media-body">
                            <h6 className="mb-0 ">Boop Bitty</h6>
                            <small className="font-size-12"> just now</small>
                          </div>
                        </div>
                      </Link>
                      <Link to="/" className="iq-sub-card">
                        <div className="media align-items-center">
                          <img
                            src="https://vinzator.com/movieProject/images/notify/thumb-2.jpg"
                            className="img-fluid mr-3"
                            alt="CineTrail"
                          />
                          <div className="media-body">
                            <h6 className="mb-0 ">The Last Breath</h6>
                            <small className="font-size-12">
                              15 minutes ago
                            </small>
                          </div>
                        </div>
                      </Link>
                      <Link to="/" className="iq-sub-card">
                        <div className="media align-items-center">
                          <img
                            src="https://vinzator.com/movieProject/images/notify/thumb-3.jpg"
                            className="img-fluid mr-3"
                            alt="CineTrail"
                          />
                          <div className="media-body">
                            <h6 className="mb-0 ">The Hero Camp</h6>
                            <small className="font-size-12">1 hour ago</small>
                          </div>
                        </div>
                      </Link>
                    </div>
                  </div>
                </div>
              </li>

              <li>
                <Link
                  to="/"
                  className="iq-user-dropdown search-toggle d-flex align-items-center"
                >
                  USERNAME1
                  <img
                    src={user?.mediaId?.url}
                    className="img-fluid avatar-40 rounded-circle"
                    alt="CineTrail user"
                  />
                </Link>

                <div className="iq-sub-dropdown iq-user-dropdown">
                  <div className="iq-card shadow-none m-0">
                    <div className="iq-card-body p-0 pl-3 pr-3">
                      <Link
                        to="/ManageProfile"
                        className="iq-sub-card setting-dropdown"
                      >
                        <div className="media align-items-center">
                          <div className="right-icon">
                            <i className="ri-profile-line text-primary"></i>
                          </div>
                          <div className="media-body ml-3"> Profile</div>
                        </div>
                      </Link>

                      <Link
                        to="/ManageProfile"
                        className="iq-sub-card setting-dropdown"
                      >
                        <div className="media align-items-center">
                          <div className="right-icon">
                            <i className="ri-file-user-line text-primary"></i>
                          </div>
                          <div className="media-body ml-3">Manage Profile1</div>
                        </div>
                      </Link>
                      <Link
                        to="/Settings"
                        className="iq-sub-card setting-dropdown"
                      >
                        <div className="media align-items-center">
                          <div className="right-icon">
                            <i className="ri-settings-4-line text-primary"></i>
                          </div>
                          <div className="media-body ml-3">Settings</div>
                        </div>
                      </Link>

                      <Link
                        to="/Signup"
                        className="iq-sub-card setting-dropdown"
                      >
                        <div className="media align-items-center">
                          <div className="right-icon">
                            <i className="ri-login-circle-line text-primary"></i>
                          </div>
                          <div className="media-body ml-3">Register</div>
                        </div>
                      </Link>

                      <Link
                        to=""
                        className="iq-sub-card setting-dropdown"
                        onClick={handleLogout}
                      >
                        <div className="media align-items-center">
                          <div className="right-icon">
                            <i className="ri-logout-circle-line text-primary"></i>
                          </div>
                          <div className="media-body ml-3">Logout</div>
                        </div>
                      </Link>
                    </div>
                  </div>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </>
  );
};

export default DropDowns;
