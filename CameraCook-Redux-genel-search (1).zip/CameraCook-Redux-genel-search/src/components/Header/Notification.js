import React from "react";
import { Link } from "react-router-dom";

const Notification = () => {
  return (
    <li className="nav-item nav-icon">
      <Link to="/" className="search-toggle" data-toggle="search-toggle">
        <svg
          xmlns="http://www.w3.org/2000/svg"
          viewBox="0 0 24 24"
          width="22"
          height="22"
          className="noti-svg"
        >
          <path fill="none" d="M0 0h24v24H0z"></path>
          <path d="M18 10a6 6 0 1 0-12 0v8h12v-8zm2 8.667l.4.533a.5.5 0 0 1-.4.8H4a.5.5 0 0 1-.4-.8l.4-.533V10a8 8 0 1 1 16 0v8.667zM9.5 21h5a2.5 2.5 0 1 1-5 0z"></path>
        </svg>
        <span className="bg-danger dots"></span>
      </Link>
      <div className="iq-sub-dropdown">
        <div className="iq-card shadow-none m-0">
          <div className="iq-card-body">
            <Link to="/" className="iq-sub-card">
              <div className="media align-items-center">
                <img
                  src="https://vinzator.com/movieProject/images/notify/thumb-1.jpg"
                  className="img-fluid mr-3"
                  alt="CineTrail"
                />
                <div className="media-body">
                  <h6 className="mb-0 ">Boot Bitty</h6>
                  <small className="font-size-12"> just now</small>
                </div>
              </div>
            </Link>
            <Link to="/" className="iq-sub-card">
              <div className="media align-items-center">
                <img
                  src="https://vinzator.com/movieProject/images/notify/thumb-2.jpg"
                  className="img-fluid mr-3"
                  alt="CineTrail"
                />
                <div className="media-body">
                  <h6 className="mb-0 ">The Last Breath</h6>
                  <small className="font-size-12">15 minutes ago</small>
                </div>
              </div>
            </Link>
            <a href="#" className="iq-sub-card">
              <div className="media align-items-center">
                <img
                  src="https://vinzator.com/movieProject/images/notify/thumb-3.jpg"
                  className="img-fluid mr-3"
                  alt="CineTrail"
                />
                <div className="media-body">
                  <h6 className="mb-0 ">The Hero Camp</h6>
                  <small className="font-size-12">1 hour ago</small>
                </div>
              </div>
            </a>
          </div>
        </div>
      </div>
    </li>
  );
};

export default Notification;
