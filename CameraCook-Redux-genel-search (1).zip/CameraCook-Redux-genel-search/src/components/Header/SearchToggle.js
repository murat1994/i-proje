import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useHistory, useLocation } from "react-router-dom";
import { logout } from "../../actions/auth.action";
import Notifications from "./Notification";
import { Link } from "react-router-dom";
import Search from "./Search";

const SearchToggle = () => {
  const [language, setLanguage] = useState("TR");

  const history = useHistory();

  const dispatch = useDispatch();

  const handleLogout = () => {
    dispatch(logout());
    history.push("/");
  };

  const { user } = useSelector((state) => state.auth);
  useEffect(() => {
    dispatch({
      type: "CHANGE_LANGUAGE",
      payload: language,
    });
  }, [language, dispatch]);
  return (
    <div className="navbar-right menu-right">
      <ul className="d-flex align-items-center list-inline m-0">
        <Search />

        <li>
          <select
            // value={language}
            name="change_language"
            className="select-language"
            onChange={(e) => setLanguage(e.target.value)}
          >
            <option className="turkce">TR</option>
            <option className="english">EN</option>
            <option className="german">DE</option>
          </select>
        </li>

        <Notifications />
        <li className="nav-item nav-icon">
          <Link
            to="/"
            className="iq-user-dropdown search-toggle p-0 d-flex align-items-center"
            data-toggle="search-toggle"
          >
            {user.firstname.toUpperCase()}
            <img
              src={user?.mediaId?.url}
              className="img-fluid avatar-40 rounded-circle"
              alt="CineTrail user"
            />
          </Link>

          <div className="iq-sub-dropdown iq-user-dropdown">
            <div className="iq-card shadow-none m-0">
              <div className="iq-card-body p-0 pl-3 pr-3">
                <Link
                  to="/ManageProfile"
                  className="iq-sub-card setting-dropdown"
                >
                  <div className="media align-items-center">
                    <div className="right-icon">
                      <i className="ri-profile-line text-primary"></i>
                    </div>
                    <div className="media-body ml-3"> Profile</div>
                  </div>
                </Link>

                <Link
                  to="/ManageProfile"
                  className="iq-sub-card setting-dropdown"
                >
                  <div className="media align-items-center">
                    <div className="right-icon">
                      <i className="ri-file-user-line text-primary"></i>
                    </div>
                    <div className="media-body ml-3">Manage Profile</div>
                  </div>
                </Link>
                <Link to="/Settings" className="iq-sub-card setting-dropdown">
                  <div className="media align-items-center">
                    <div className="right-icon">
                      <i className="ri-settings-4-line text-primary"></i>
                    </div>
                    <div className="media-body ml-3">Settings</div>
                  </div>
                </Link>
                <Link to="/Signup" className="iq-sub-card setting-dropdown">
                  <div className="media align-items-center">
                    <div className="right-icon">
                      <i className="ri-login-circle-line text-primary"></i>
                    </div>
                    <div className="media-body ml-3">Register</div>
                  </div>
                </Link>

                <a
                  href=""
                  className="iq-sub-card setting-dropdown"
                  onClick={handleLogout}
                >
                  <div className="media align-items-center">
                    <div className="right-icon">
                      <i className="ri-logout-circle-line text-primary"></i>
                    </div>
                    <div className="media-body ml-3">Logout</div>
                  </div>
                </a>
              </div>
            </div>
          </div>
        </li>
      </ul>
    </div>
  );
};

export default SearchToggle;
