import axios from "axios";
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";

const Search = () => {
  const [movies, setMovies] = useState([]);
  const [keyTerm, setKeyTerm] = useState("");
  const [show, setShow] = useState(false);
  useEffect(() => {
    const searchMovie = async () => {
      try {
        const {
          data: { results },
        } = await axios.get(
          `https://api.themoviedb.org/3/search/movie?api_key=${process.env.REACT_APP_API_KEY}&language=tr-TR&query=${keyTerm}`
        );
        setMovies(results);
        setShow(true);
      } catch (error) {
        console.log(error);
      }
    };

    searchMovie();
  }, [keyTerm]);
  return (
    <li
      className={`nav-item nav-icon`}
      name="search"
      onClick={(e) => {
        e.target.name === "search" ? setShow(true) : setShow(false);
      }}
    >
      <Link to="#" className="search-toggle device-search">
        <i className="ri-search-line" name="search"></i>
      </Link>
      <div className="search-box iq-search-bar d-search">
        <form action="#" className="searchbox">
          <div className="form-group position-relative">
            <input
              onChange={(e) => setKeyTerm(e.target.value)}
              value={keyTerm}
              type="text"
              className="text search-input font-size-12"
              placeholder="type here to search..."
            />
            <i className="search-link ri-search-line"></i>
          </div>
          <ul className="search-list">
            {show &&
              movies.length > 0 &&
              movies.map(({ id, backdrop_path, original_title }) => (
                <li key={id}>
                  <Link to={`/movie/${id}`}>
                    <p>{original_title}</p>
                  </Link>
                </li>
              ))}
          </ul>
        </form>
      </div>
    </li>
  );
};

export default Search;
