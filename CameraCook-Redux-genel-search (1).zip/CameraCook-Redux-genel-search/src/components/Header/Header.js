import React from "react";
import "../css/Header.css";
import "remixicon/fonts/remixicon.css";

import Navbar from "./Navbar";

export const Header = () => {
  return (
    <header id="main-header">
      <div className="main-header">
        <div className="container-fluid">
          <div className="row">
            <div className="col-sm-12">
              <nav className="navbar navbar-expand-lg navbar-light p-0">
                <Navbar />
              </nav>
              <div className="nav-overlay"></div>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};
