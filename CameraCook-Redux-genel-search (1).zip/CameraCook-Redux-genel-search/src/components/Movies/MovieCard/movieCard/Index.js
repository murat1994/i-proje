import React from 'react';
import Tabs from "./Tabs"; 
import './Index.css';

function AppTab() {
  return (
    <div>
      <h1>tabbed-content</h1>
     <Tabs> 
       <div label="CAST"> 
         See ya later, <em>CAST</em>! 
       </div> 
       <div label="CREW"> 
         After 'while, <em>CREW</em>! 
       </div> 
       <div label="DETAILS"> 
         Nothing to see here, this tab is <em>DETAILS</em>! 
       </div> 
    
     <div label="GENRES"> 
         Nothing to see here, this tab is <em>GENRES</em>! 
       </div> 
       </Tabs> 
    </div>
  );
}

export default AppTab;
