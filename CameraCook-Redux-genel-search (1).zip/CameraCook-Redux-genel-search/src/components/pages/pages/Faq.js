import React,{useEffect,useState} from "react";
import "../../css/Faq.css";
// import "../../css/style.css";
import axios from "axios"
import { API_BASE }  from "../../../actions/api_base";



const Faq = () => {
  const [state, setstate] = useState([])

  const GetMyQuestions = () => {
    axios.get(`${API_BASE}faqs`)
    .then(res=>{
      console.log(res)
      setstate(res.data.response)
    })
    .catch(err=>console.log(err))
  }

  useEffect(() => {
    GetMyQuestions()
  }, [])

  return (
    <div className="faq-accordion-div">
      <div
        className="iq-breadcrumb-one  iq-bg-over iq-over-dark-50"
        style={{
          backgroundImage: `url(
				"https://media.istockphoto.com/illustrations/faq-special-blue-banner-background-illustration-id1017117266"
			)`,
        }}
      >
        <div className="container-fluid">
          <div className="row align-items-center">
            <div className="col-sm-12">
              <nav className="text-center ">
                <h2 className="faq-title">FAQ</h2>
                <ol>
                  <li className="faq-title-home ">
                    <a href="/">Home - </a>
                  </li>
                  <li className="faq-title-home ">
                    <a href="/faq">- faq </a>
                  </li>
                </ol>
              </nav>
            </div>
          </div>
        </div>
      </div>

      <div className="faq-container" >
      <div className="accordion accordion-flush" id="accordionFlushExample">

        {state.map((faq,index)=>{
          return <div className="accordion-item" key={faq._id}>
          <h2 className="accordion-header" id={`flush-heading${index}`}>
            <button
              className="accordion-button collapsed shadow-none"
              type="button"
              data-bs-toggle="collapse"
              data-bs-target={`#flush-collapse${index}`}
              aria-expanded="false"
              aria-controls={`flush-collapse${index}`}
            >
              {faq.question}
            </button>
          </h2>
          <div
            id={`flush-collapse${index}`}
            className="accordion-collapse collapse"
            aria-labelledby={`flush-heading${index}`}
            data-bs-parent="#accordionFlushExample"
          >
            <div className="accordion-body">
              {faq.answer}
            </div>
          </div>
        </div>
        })}
        

        {/* <div className="accordion-item">
          <h2 className="accordion-header" id="flush-headingTwo">
            <button
              className="accordion-button collapsed shadow-none"
              type="button"
              data-bs-toggle="collapse"
              data-bs-target="#flush-collapseTwo"
              aria-expanded="false"
              aria-controls="flush-collapseTwo"
            >
              Accordion Item 2
            </button>
          </h2>
          <div
            id="flush-collapseTwo"
            className="accordion-collapse collapse"
            aria-labelledby="flush-headingTwo"
            data-bs-parent="#accordionFlushExample"
          >
            <div className="accordion-body">
              Placeholder content for this accordion, which is intended to
              demonstrate the <code>.accordion-flush</code> class. This is the
              second item's accordion body. Let's imagine this being filled with
              some actual content.
            </div>
          </div>
        </div> */}

        

        {/* <div className="accordion-item">
          <h2 className="accordion-header" id="flush-headingThree">
            <button
              className="accordion-button collapsed shadow-none"
              type="button"
              data-bs-toggle="collapse"
              data-bs-target="#flush-collapseThree"
              aria-expanded="false"
              aria-controls="flush-collapseThree"
            >
              Accordion Item 3
            </button>
          </h2>
          <div
            id="flush-collapseThree"
            className="accordion-collapse collapse"
            aria-labelledby="flush-headingThree"
            data-bs-parent="#accordionFlushExample"
          >
            <div className="accordion-body">
              Placeholder content for this accordion, which is intended to
              demonstrate the <code>.accordion-flush</code> class. This is the
              third item's accordion body. Nothing more exciting happening here
              in terms of content, but just filling up the space to make it
              look, at least at first glance, a bit more representative of how
              this would look in a real-world application.
            </div>
          </div>
        </div> */}



      </div>
    </div>
   
    </div>
  );
};

export default Faq;
