import React from "react";
import "../../css/About.css";

export default function About() {
  return (

    <div className="developers ">

      <div
        className="iq-breadcrumb-one  iq-bg-over iq-over-dark-50"
        style={{
          backgroundImage: `url(
				"https://vinzator.com/movieProject/images/about-us/01.jpg"
			)`,
        }}
      >
        <div className="container-fluid">
          <div className=" align-items-center">
            <div className="col-sm-12">
              <nav className="text-center ">
                <h2 className="faq-title">About Us</h2>
                <ol>
                  <li className="faq-title-home ">
                    <a href="/">Home - </a>
                  </li>
                  <li className="faq-title-home ">
                    <a href="/AboutUs"> - About Us </a>
                  </li>
                </ol>
              </nav>
            </div>
          </div>
        </div>
      </div>
     
            <div className="container ">
               <div className="about-us-row">
                  <div className="col-lg-12 col-sm-12 mb-sm-4">

                     <div className="text-center iq-title-box iq-title-default">
                        <h2 className="about-iq-title text-capitalize">
                           Masterminds team
                        </h2>
                        <p className="iq-title-desc">Your CineTrail is build by one of the best and well experienced web developers and an <br/>awarded Envato Elite Author.</p>
                     </div>
                  </div>
               </div>
            </div>

            <div className="container-md container-fluid ">

                     <div className="about-us-row about-us-detail ">
                        <div className="col-md-3 mb-4">
                           <div className="image-box">
                              <img className="developersbox img-fluid attachment-large size-large" src="https://vinzator.com/movieProject/images/about-us/02.jpg" width="265"  height="345"></img>
                           </div>

                           <div className="icon-box-content">
                              <div className="widget-container">
                                 <p className="heading-title size-default">ceo</p>		
                              </div>
                              <div className="widget-container">
                                 <h4 className="heading-title size-default">Hasan SAFE</h4>
                              </div>
                           </div>
                        </div>

                        <div className="col-md-3 mb-4">
                           <div className="image-box">
                           <img className="developersbox img-fluid attachment-large size-large" src="https://vinzator.com/movieProject/images/about-us/03.jpg" width="265"  height="345"></img>
                           </div>

                           <div className="icon-box-content">
                              <div className="widget-container">
                                 <p className="heading-title size-default">Designer</p>		
                              </div>
                              <div className="widget-container">
                                 <h4 className="heading-title size-default">David FISH</h4>
                              </div>
                           </div>
                        </div>

                        <div className="col-md-3 mb-4">
                           <div className="image-box">
                            <img className="developersbox img-fluid attachment-large size-large" src="https://vinzator.com/movieProject/images/about-us/04.jpg" width="265"  height="345"></img>
                           </div>

                           <div className="icon-box-content">
                              <div className="widget-container">
                                 <p className="heading-title size-default">Developer</p>		
                              </div>
                              <div className="widget-container">
                                 <h4 className="heading-title size-default">Murat NIYAZOV</h4>
                              </div>
                           </div>
                        </div>

                        <div className="col-md-3 mb-4">
                           <div className="image-box">
                           <img className="developersbox img-fluid attachment-large size-large" src="https://vinzator.com/movieProject/images/about-us/05.jpg" width="265"  height="345"></img>
                           </div>

                           <div className="icon-box-content">
                              <div className="widget-container">
                                 <p className="heading-title size-default">Designer</p>		
                              </div>
                              <div className="widget-container">
                                 <h4 className="heading-title size-default">Enesh ORAZOVA</h4>
                              </div>
                           </div>
                        </div>

                
                     </div>
            </div>                  
         

         <div className="container-fluid p-0">
            <div className="map-container" >

               <div className="container">
                  <div className=" about-us-row text-center align-items-center">
                     <div className="col-md-6">
                        <div className="text-center">
                        <img className="developersbox img-fluid attachment-large size-large" src="https://vinzator.com/movieProject/images/about-us/06.jpg"></img>
                        </div>
                     </div>
                     <div className="col-md-6">
                        <div className=" text-left iq-title-box iq-title-default">
                           <h2 className="about-iq-title">
                              Contact Us Here
                           </h2>                        
                           <p className="iq-title-desc">Streamit is located in Los Angeles city and you can contact us at <a href="#">hello@streamit.com</a> for any tech-related support and assistance. We love to hear from our Streamit users.</p>
                           
                           <div className="about-us-row mt-2">
                              <div className="col-md-4">
                                 <div className="counter">                                 
                                    <span className="counter-number" data-duration="2000" data-to-value="4" data-from-value="0" data-delimiter=",">4</span>
                                 </div>
                                 <div className="counter-title">Branch</div>
                              </div>
   
                              <div className="col-md-4">
                                 <div className="iq-contact-list" data-element_type="column">
                                 <div className="counter">                                 
                                    <span className="counter-number" data-duration="2000" data-to-value="4" data-from-value="0" data-delimiter=",">
                                       500+
                                    </span>
                                 </div>
                                 <div className="counter-title">Employee</div>
                                 </div>
                              </div>
                              
                              <div className="col-md-4">
                                 <div className="iq-contact-list" data-element_type="column">
                                 <div className="counter">                                 
                                    <span className="counter-number" data-duration="2000" data-to-value="4" data-from-value="0" data-delimiter=",">
                                       1,000+
                                    </span>
                                 </div>
                                 <div className="counter-title">Clients</div>
                                 </div>
                              </div>
   
                           </div>
                        </div>
                     </div>
                  </div>
               </div>               
            </div>
         </div>

         <div className="container-fluid">
            <div className="svg-header">
               <div className="svg-mini-header">
                  <div className="text-center iq-title-box iq-title-default">
                     <h2 className="about-iq-title">
                        Work With the Best	
                     </h2>
                  </div>
               </div>
            </div>
         </div>
         <div className="container">
            <div className="about-us-row text-center d-flex justify-content-center">
               <div className="col-sm-2 ">
                  <div className="image-box">
                  <img className="svgbox" src="https://vinzator.com/movieProject/abouth/svgexport-3.svg"></img>
                  </div>
               </div>

               <div className="col-sm-2">
                  <div className="image-box">
                  <img className="svgbox" src="https://vinzator.com/movieProject/abouth/svgexport-4.svg"></img>
                  </div>
               </div>

               <div className="col-sm-2">
                  <div className="image-box">
                  <img className="svgbox" src="https://vinzator.com/movieProject/abouth/svgexport-5.svg"></img>
                  </div>
               </div>

               <div className="col-sm-2">
                  <div className="image-box">
                  <img className="svgbox" src="https://vinzator.com/movieProject/abouth/svgexport-6.svg"></img>
                  </div>
               </div>

               <div className="col-sm-2">
                  <div className="image-box">
                  <img className="svgbox" src="https://vinzator.com/movieProject/abouth/svgexport-7.svg"></img>
                  </div>
               </div>
               
            </div>
            
         </div>

    </div>
  );
}
