import React from 'react'
import './Settings.css';

 function Settings() {
    return (
        
            <section className="m-profile setting-wrapper" >        
        <div className="container">
            {/* <h4 className="main-title mb-4">Account Setting</h4> */}
            <div className="row" >
                <div className="col-lg-4 mb-3">
                    <div className="sign-user_card text-center">
                        <img src="https://embodiedfacilitator.com/wp-content/uploads/2018/05/human-icon-png-1901.png" className="rounded-circle img-fluid d-block mx-auto mb-3" alt="user"/>
                        <h4 className="mb-3">John Doe</h4>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
                        <a href="#" className="edit-icon text-primary" >Edit</a>
                    </div>
                </div>
                <div className="col-lg-8" style={{color:'white',fontSize:'19px'}}>
                    <div className="sign-user_card">
                        <h5 className="mb-3 pb-3 mt-1 a-border">Personal Details</h5>
                                <hr/>
                        <div className="row align-items-center justify-content-between mb-3">
                            <div className="col-md-8">
                                <span className="text-light font-size-16">Email</span>
                                <p className="mb-0 mt-0">example@gmail.com</p>
                            </div>   
                            <div className="col-md-4 text-md-right text-right" >                      
                                <a href="#" className="text-primary" >Change</a>
                            </div>
                        </div>
                        <div className="row align-items-center justify-content-between mb-3">
                            <div className="col-md-8">
                                <span className="text-light font-size-16">Password</span>
                                <p className="mb-0 mt-0">**********</p>
                            </div>
                            <div className="col-md-4 text-md-right text-right">
                                <a href="#" className="text-primary">Change</a>
                            </div>
                        </div>
                        <div className="row align-items-center justify-content-between mb-3">
                            <div className="col-md-8">
                                <span className="text-light font-size-16">Date of Birth</span>
                                <p className="mb-0 mt-0" >08-03-1995</p>
                            </div>
                            <div className="col-md-4 text-md-right text-right">
                                <a href="#" className="text-primary">Change</a>
                            </div>
                        </div>
                        <div className="row align-items-center justify-content-between">
                            <div className="col-md-8">
                                <span className="text-light font-size-16">Language</span>
                                <p className="mb-0 mt-0">English</p>
                            </div>
                            <div className="col-md-4 text-md-right text-right">
                                <a href="#" className="text-primary">Change</a>
                            </div>
                        </div>
                        
                        {/* <div className="row justify-content-between mb-3">
                            <div className="col-md-8 r-mb-15"> 
                            </div>
                            <div className="col-md-4 text-md-right text-left">
                            </div>
                        </div> */}
                        {/* <div className="row justify-content-between mb-3">
                            <div className="col-md-8">
                             
                            </div>
                            <div className="col-md-4 text-md-right text-left">
                                
                            </div>
                        </div> */}
                        <h5 className="mb-3 pb-3 mt-4 a-border ">Setting</h5>
                        <hr/>
                        <div className="row">
                            <div className="col-12 setting">
                                <a href="#" className="text-body d-block mb-1 ">Recent device streaming activity</a>
                                <a href="#" className="text-body d-block mb-1">Sign out of all devices </a>
                                <a href="#" className="text-body d-block">Download your person information</a>
                            </div>                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    )
}
export default Settings;