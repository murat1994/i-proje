import React, { useState } from "react";
import { Link } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";

import { register } from "../../../actions/auth.action";

import "./Signup.css";

const initialState = {
  firstname: "",
  lastname: "",
  email: "",
  password: "",
  country: "",
  mediaId: "",
};

function Signup(props) {
  const [state, setstate] = useState(initialState);
  const [modal, setModal] = useState(true);
  const store = useSelector(store => store);
    console.log(store)
  const dispatch = useDispatch();

  const handleInput = (e) => {
    setstate({ ...state, [e.target.name]: e.target.value });
  };

  const onChangePhoto = (e) => {
    //console.log(e.target.files);
    setstate({ ...state, mediaId: e.target.files[0] });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const fd = new FormData();
    if (state.mediaId.name) {
      fd.set("mediaId", state.mediaId, state.mediaId.name);
    }
    fd.set("firstname", state.firstname);
    fd.set("lastname", state.lastname);
    fd.set("email", state.email);
    fd.set("password", state.password);
    fd.set("country", state.country);

    //console.log(fd.getAll('mediaId'))
    dispatch(register(fd)).then((res) => {
        //console.log(res)
      if (res) {
        window.$('#registerModal').modal("show")
        setTimeout(() => {
            setModal(false);
            window.$('#registerModal').modal("hide")
          props.history.push("/signin");
        }, 2000);
      } 
    });
    setstate(initialState);
  };

  //console.log(state)

  return (
    <section className="login">
      <div className="loginContainer">
        <div className="c-avatar-register">
          <img
            src={
              state.mediaId.name
                ? URL.createObjectURL(state.mediaId)
                : "avatars/avatar.png"
            }
            className="c-avatar-img profile-img-card"
            alt="profile-img"
          />
          <span className="c-avatar-add">
            <input
              type="file"
              onChange={onChangePhoto}
              id="file-input"
              name="file-input"
              className="c-avatar-input"
            />
            <label htmlFor="file-input" className="c-avatar-label">
              <i className="fa fa-camera" aria-hidden="true"></i>
            </label>
          </span>
        </div>
        <label>First Name</label>
        <input
        defaultValue={state.firstname}
          onChange={handleInput}
          type="text"
          placeholder="First Name"
          name="firstname"
          required
          autoFocus
        />
        <label>Last Name</label>
        <input
        defaultValue={state.lastname}
          onChange={handleInput}
          type="text"
          placeholder="Last Name"
          name="lastname"
          required
        />
        <label>E-mail</label>
        <input
        defaultValue={state.email}
          onChange={handleInput}
          type="text"
          placeholder="E-mail"
          name="email"
          required
        />
        <label>Password</label>
        <input
        defaultValue={state.password}
          onChange={handleInput}
          type="password"
          placeholder="Password"
          name="password"
          required
        />
        <label>Country</label>
        <input
        defaultValue={state.country}
          onChange={handleInput}
          type="text"
          placeholder="Enter Country"
          name="country"
          required
        />
        <div className="btnContainer">
          <button type="button" onClick={handleSubmit}>
            Sign up
          </button>
          <p>
            {" "}
            Have an account ?
            <Link to="/Signin" style={{ color: "red", padding: "5px" }}>
              Login
            </Link>
          </p>
        </div>
      </div>
      <div
        className="modal fade"
        id="registerModal"
        tabindex="-1"
        role="dialog"
        aria-labelledby="registerModalLabel"
        
        
        onClose={setModal} 
      >
        <div className="modal-dialog modal-dialog-centered" show={modal} role="document" >
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title" id="registerModalLabel">
               Register
              </h5>
              <button
                type="button"
                className="close"
                data-dismiss="modal"
                aria-label="Close"
              >
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div className="modal-body">{store.error?store.error:store.msg}<br></br> {store.msg? "Redirecting signin page!" : ""}</div>
            <div className="modal-footer">
              <button
                type="button"
                className="btn btn-secondary"
                data-dismiss="modal"
                onClick={() => setModal(false)}
              >
                Close
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export default Signup;
