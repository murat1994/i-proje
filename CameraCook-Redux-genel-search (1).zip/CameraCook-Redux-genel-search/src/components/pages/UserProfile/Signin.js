import React, {useState} from "react";
import { Link } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { login } from "../../../actions/auth.action";
import "./Signin.css";


const initialState = {
    email:"",
    password:""
  }

function Signin(props) {
  const [state, setstate] = useState(initialState);
  const [loading, setLoading] = useState(false);
  const dispatch = useDispatch();

  const handleInput = (e) => {
    setstate({ ...state, [e.target.name]: e.target.value });
  };

  const handleSubmit = () => {
      console.log("login pressed")
       
        setLoading(true);
        const fd = new FormData();
        fd.set("email", state.email);
        fd.set("password", state.password);
        dispatch(login(fd))
          .then((res) => {
            if(res.isActive) {
              props.history.push("/");
            }
          })
          .catch(() => {
            setLoading(false);
          });
    
      };

      console.log(state)
  return (
    <section className="login">
      <div className="loginContainer">
        <h1 style={{ textAlign: "center" }}>Login</h1>
        <label>E-mail</label>
        <input
        defaultValue={state.email}
          onChange={handleInput}
          type="text"
          placeholder="E-mail"
          name="email"
          autoFocus
          required
          />
        <label>Password</label>
        <input
        defaultValue={state.password}
          onChange={handleInput}
          type="password"
          placeholder="Password"
          name="password"
          required
        />
        <div className="btnContainer">
            <button type="button" onClick={handleSubmit} >Login</button>
            {/* <label className="custom-control-label"for="customCheck">Remember Me</label> */}
            <p>
              Dont have an account?
              <Link to="/Signup" style={{ color: "red", padding: "5px" }}>
                Sign up
              </Link>
              <br />
              {/* <span to="#" style={{color:'white',padding:'00px'}}>Forgot your password?</span> */}
              {/* Forgot your password? */}
            </p>
        </div>
      </div>
    </section>
  );
}

export default Signin;
