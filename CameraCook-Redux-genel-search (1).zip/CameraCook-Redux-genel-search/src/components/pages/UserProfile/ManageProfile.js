import React from "react";
import "./ManageProfile.css";
import {
  Combobox,
  ComboboxInput,
  ComboboxPopover,
  ComboboxList,
  ComboboxOption
} from "@reach/combobox";
import "@reach/combobox/styles.css";
import {Link} from 'react-router-dom';

function ManageProfile() {
  return (
    <section className="m-profile manage-p" style={{ color: 'white' }} >
      <div className="container h-100">
        <div className="row align-items-center justify-content-center h-100">
          <div className="col-lg-10" data-select2-id="24">
            <div className="sign-user_card" data-select2-id="20">
              <div className="row" data-select2-id="19">
                <div className="col-lg-2">
                  <div className="upload_profile d-inline-block">
                    <img
                      src="https://embodiedfacilitator.com/wp-content/uploads/2018/05/human-icon-png-1901.png"
                      className="profile-pic rounded-circle img-fluid"
                      alt="user"
                    />
                    <div className="p-image">
                      <i className="ri-pencil-line upload-button"></i>
                      <input className="file-upload" type="file" accept="image/*" />
                    </div>
                  </div>
                </div>
                <div className="col-lg-10 device-margin" data-select2-id="18">
                  <div className="profile-from" data-select2-id="17">
                    <h4 className="mb-3 mt-0">Manage Profile</h4>
                    <form className="mt-4" action="index.html" data-select2-id="16">
                      <div className="form-group">
                        <label>Name</label>
                        <input
                          type="text"
                          className="form-control mb-0"
                          id="exampleInputl2"
                          placeholder="Enter Your Name"
                          autocomplete="off"
                          required=""
                        />
                      </div>
                      <div className="form-group">
                        <label>Date of Birth</label>
                        <input
                          type="text"
                          className="form-control date-input basicFlatpickr mb-0 flatpickr-input"
                          placeholder="Select Date"
                          id="exampleInputPassword2"
                          required=""
                        // readonly="readonly"
                        />
                      </div>
                      <div >
                        <div style={{ display: 'flex', paddingBottom: '10px' }}>
                          <Combobox aria-label="choose lang-dropdown dropdownMenuButton">
                            <ComboboxInput
                              placeholder="Choose your gender"
                              style={{ width: 185 }}
                            />
                            <ComboboxPopover >
                              <ComboboxList style={{ color: '#393E46'}}>
                                <ComboboxOption value="Female" />
                                <ComboboxOption value="Male" />
                              </ComboboxList>
                            </ComboboxPopover>
                          </Combobox>
                          <Combobox aria-labelledby="demo lang-dropdown">
                            <ComboboxInput
                              placeholder="Language Preferenceng"
                              style={{ width: 200,backgroundColor:'#141414' }}
                            />
                            <ComboboxPopover>
                              <ComboboxList style={{ color: '#393E46' }}>
                                <ComboboxOption value="Turkish" />
                                <ComboboxOption value="English" />
                                <ComboboxOption value="Russian" />
                                <ComboboxOption value="Hindi" />
                                <ComboboxOption value="Bengali" />
                              </ComboboxList>
                            </ComboboxPopover>
                          </Combobox>
                        </div>
                        <span
                          className="dropdown-wrapper"
                          aria-hidden="true"
                        ></span>

                      </div>
                      <div className="button d-flex">
                        <Link to="#" className="btn btn-hover">
                          Save
                        </Link>
                        <Link to="#" className="btn btn-hover">
                          Cancel
                        </Link>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
export default ManageProfile;
