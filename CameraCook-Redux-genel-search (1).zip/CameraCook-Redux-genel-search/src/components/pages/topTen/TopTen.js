import React, { useEffect, useState } from "react";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import "../../css/TopTen.css";
import SingleTopTen from "./SingleTopTen";
import settings from "../setting.json";
import axios from "axios";

export default function TopTen() {
  const [movies, setMovies] = useState([]);
  useEffect(() => {
    const getTopTen = async () => {
      try {
        const {
          data: { results },
        } = await axios.get(`
        https://api.themoviedb.org/3/movie/top_rated?api_key=${process.env.REACT_APP_API_KEY}&language=tr-TR&page=1`);

        setMovies(results.slice(0, 10));
      } catch (error) {
        console.log(error);
      }
    };

    getTopTen();
  }, []);

  return (
    <div className="main-contens-topten">
      <div className="topten-contens">
        <div className="headersettingtop iq-header d-flex align-items-center justify-content-between">
          <h3 className="main-title-top">Top 10</h3>
          {/* <a className="iq-view-all" href="#">
            View All
          </a> */}
        </div>
        <Slider {...settings}>
          {movies.map((movie, index) => (
            <div key={index} id="topbg" className="bg-img-top">
              <SingleTopTen {...movie} />
            </div>
          ))}
        </Slider>
      </div>
    </div>
  );
}
