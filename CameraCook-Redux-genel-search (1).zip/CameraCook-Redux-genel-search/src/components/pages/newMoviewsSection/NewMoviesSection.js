import React, { useEffect } from "react";
import "./newMoviesSection.css";
import MovieFilterSection from "../../newMoviesSection/movieFilter/MovieFilterSection";
import PopularMoviesTop from "../../newMoviesSection/popularMoviesTop/PopularMoviesTop";
import PopularMoviesBottom from "../../newMoviesSection/popularMoviesBottom/PopularMoviesBottom";
import CrewPicks from "../../newMoviesSection/crewPicks/CrewPicks";
import JustReviewed from "../../newMoviesSection/justReviewed/JustReviewedMovies";
import { useDispatch } from "react-redux";
import getPopularMovies from "../../../actions/popularMovies";
import getJustReviewed from "../../../actions/justReviewed";
const NewMoviesSection = () => {
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(getPopularMovies());
    dispatch(getJustReviewed());
  }, []);
  return (
    <div className="d-flex flex-column">
      <MovieFilterSection />
      <PopularMoviesTop />
      {/* <JustReviewed /> */}
      <div className="row bottom-side-container">
        <div className="col-8 popular-movies-bottom-container">
          <PopularMoviesBottom />
        </div>
        <div className="col-4 crews-picks-popular-reiviewers-container">
          <CrewPicks />
         
        </div>
      </div>
    </div>
  );
};

export default NewMoviesSection;
