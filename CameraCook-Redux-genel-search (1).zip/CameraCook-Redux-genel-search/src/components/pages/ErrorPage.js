import React from "react";

import { Link } from "react-router-dom";

const classes = {
  btnPrimary: {
    display: "inline-block",
    textDecoration: "none",
    letterSpacing: "3px",
    color: "#222",
    background: "#af9a7d",
    padding: "0.4rem 0.9rem",
    border: "3px solid #af9a7d",
    transition: "all 0.3s linea",
    textRransform: "uppercase",
    cursor: "pointer",
  },
  banner: {
    display: "inline-block",
    background: "rgba(0, 0, 0, 0.5)",
    color: "#fff",
    padding: "2rem 1rem",
    textAlign: "center",
    textTransform: "capitalize",
    letterSpacing: "3px",
  },
  hero: {
    minHeight: "calc(100vh - 66px)",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
  },
};

export default function Error() {
  return (
    <header className={classes.hero}>
      <div className={classes.banner}>
        <h1>"404"</h1>
        <div />
        <p>page not found</p>
        <Link to="/" className={classes.btnPrimary}>
          return home
        </Link>
      </div>
    </header>
  );
}
