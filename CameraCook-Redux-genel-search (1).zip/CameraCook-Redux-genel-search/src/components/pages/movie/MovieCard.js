import React, { useState, useEffect, useRef, Fragment } from "react";
import axios from "axios";
import { Link, useParams } from "react-router-dom";
import WhereToWatch from "../../Slider/WhereToWatch";
import Director from "../../Slider/Director";
import "./MovieCard.css";
import "./Tabs/Tab.css";
import "./Card.css";
import Tabs from "./Tabs/Tabs";
import Starring from "../../Slider/Starring";
import Crew from "./Crew";
import Details from "./Details";
import ReactStars from "react-rating-stars-component";
import { useSelector } from "react-redux";
import MovieReviews from "./MovieReviews";
import SimilarMovies from "./SimilarMovies";
import PopularLists from "./PopularLists";
import MultiSelect1 from "./Multiselect";
import { API_BASE }  from "../../../actions/api_base";


export default function MovieCard5(props) {
  const [movie, setMovies] = useState();
  const [userRating, setUserRating] = useState(0);
  const [videoId, setVideoId] = useState("");
  const { id } = useParams();
  const [currentUser, setCurrentUser] = useState([]);
  const [movieInDatabase, setMovieInDatabase] = useState([]);
  const [watchedInfo, setWatchedInfo] = useState(false);
  const [likedInfo, setLikedInfo] = useState(false);
  const [watchlistInfo, setWatchlistInfo] = useState(false);
  const [editRating, setEditRating] = useState(false);
  const [showRating, setShowRating] = useState(false);
  const [likesCount, setLikesCount] = useState(0);
  const [watchedCount, setWatchedCount] = useState(0);
  const [listedCount, setListedCount] = useState(0);
  const [comment, setComment] = useState({ title: "", content: "" });
  const [displayComments, setDisplayComments] = useState([]);
  const commentRef = useRef();
  const commentTitleRef = useRef();
  const commentContentRef = useRef();
  const { language } = useSelector((state) => state.searchMovies);

  //console.log(language);
  useEffect(() => {
    const user = JSON.parse(localStorage.getItem("user"));
    setWatchedInfo(false)
    setLikedInfo(false)
    setWatchlistInfo(false);

    setUserRating(0);
    setEditRating(false);
    setShowRating(false)

    axios
      .get(`${API_BASE}users/${user.id}`)
      .then((res) => {
        setCurrentUser(res.data.response);
      })
      .catch((err) => console.log(err));

    const getDetails = async () => {
      try {
        const { data } = await axios.get(
          `https://api.themoviedb.org/3/movie/${id}?api_key=${process.env.REACT_APP_API_KEY}&language=${
            language.toLowerCase() + "-" + language
          }`
        );
        setMovies(data);
      } catch (error) {}
    };
    getDetails();
  }, [id, language]);

  useEffect(() => {
    if (movie?.id) {
      axios
        .post(`${API_BASE}movies`, {
          imdb_id: movie.imdb_id,
          imdb_rating: movie.vote_average,
          tmdb_id: movie.id.toString(),
          original_title: movie.original_title,
          image_path: movie.poster_path,
          backdrop_path: movie.backdrop_path,
        })
        .then((res) => {
          setMovieInDatabase(res.data.data);
        })
        .catch((err) => console.log(err));
    }
  }, [movie]);

  useEffect(() => {
    console.log(movie)
    console.log(movieInDatabase)
    console.log(currentUser)

    currentUser[0]?.watched.filter((watchedMovies) => {
      return watchedMovies.movieId[0]?._id === movieInDatabase[0]?._id
        ? setWatchedInfo(true)
        : "";
    });

    currentUser[0]?.liked.filter((likedMovies) => {
      return likedMovies.movieId[0]?._id === movieInDatabase[0]?._id
        ? setLikedInfo(true)
        : "";
    });

    currentUser[0]?.watchlist.filter((watchlistMovies) => {
      return watchlistMovies.movieId[0]?._id === movieInDatabase[0]?._id
        ? setWatchlistInfo(true)
        : "";
    });

    if(movieInDatabase[0]?.userRatingIds.length !== 0){
      for(let i = 0; i<movieInDatabase[0]?.userRatingIds.length; i++){  
            if(movieInDatabase[0]?.userRatingIds[i].userId === currentUser[0]?._id){
              console.log(movieInDatabase[0]?.userRatingIds[i])
              setUserRating(movieInDatabase[0]?.userRatingIds[i].rating/2);
              setEditRating(true);
              setShowRating(true)
            }
          }
    } else {
        setUserRating(0);
        setEditRating(false);
        setShowRating(false)
    }
    


    setLikesCount(movieInDatabase[0]?.likesCount);
    setWatchedCount(movieInDatabase[0]?.watchedCount);
    setListedCount(movieInDatabase[0]?.listedCount);
  }, [movieInDatabase]);

  useEffect(() => {
      const getTrailer = async () => {
      try {
        const {
          data: { results },
        } = await axios.get(`
        https://api.themoviedb.org/3/movie/${id}/videos?api_key=${process.env.REACT_APP_API_KEY}&language=${
          language.toLowerCase() + "-" + language
        }`);
        if(results.length !== 0){
          setVideoId(results.filter(({ site, key }) => site !== "Youtube")[0].key);
        } else {
          setVideoId("")
        }
        //console.log(results)
      } catch (error) {console.log(error)}
    };

    getTrailer();
  }, [id,language])

  
  
  const handleWatchClick = () => {
    if (!watchedInfo) {
      axios
        .post(`${API_BASE}watched`, {
          userId: currentUser[0]._id,
          movieId: movieInDatabase[0]._id,
        })
        .then((res) => {
          setWatchedInfo(true);
          setWatchedCount(watchedCount + 1);
        })
        .catch((err) => console.log(err));
    } else {
      axios
        .post(`${API_BASE}watched`, {
          userId: currentUser[0]._id,
          movieId: movieInDatabase[0]._id,
        })
        .then((res) => {
          setWatchedInfo(false);
          setWatchedCount(watchedCount - 1);
        })
        .catch((err) => console.log(err));
    }
  };

  const handleLikeClick = () => {
    if (!likedInfo) {
      axios
        .post(`${API_BASE}liked`, {
          userId: currentUser[0]._id,
          movieId: movieInDatabase[0]._id,
        })
        .then((res) => {
          setLikedInfo(true);
          setLikesCount(likesCount + 1);
        })
        .catch((err) => console.log(err));
    } else {
      axios
        .post(`${API_BASE}liked`, {
          userId: currentUser[0]._id,
          movieId: movieInDatabase[0]._id,
        })
        .then((res) => {
          setLikedInfo(false);
          setLikesCount(likesCount - 1);
        })
        .catch((err) => console.log(err));
    }
  };

  const handleWatchlistClick = () => {
    if (!watchlistInfo) {
      axios
        .post(`${API_BASE}watchlist`, {
          userId: currentUser[0]._id,
          movieId: movieInDatabase[0]._id,
        })
        .then((res) => {
          setWatchlistInfo(true);
        })
        .catch((err) => console.log(err));
    } else {
      axios
        .post(`${API_BASE}watchlist`, {
          userId: currentUser[0]._id,
          movieId: movieInDatabase[0]._id,
        })
        .then((res) => {
          setWatchlistInfo(false);
        })
        .catch((err) => console.log(err));
    }
  };

  const handleReviewChange = (e) => {
    setComment({ ...comment, [e.target.name]: e.target.value });
  };

  const postReview = () => {
    if (comment.title !== "" && comment.content !== "") {
      const query = {
        userId: currentUser[0]._id,
        movieId: movieInDatabase[0]._id,
        title: comment.title,
        content: comment.content,
      };
      axios
        .post(`${API_BASE}comments`, query)
        .then((res) => {
          setComment({ title: "", content: "" });
          commentContentRef.current.style.border = "solid white 2px";
          commentTitleRef.current.style.border = "solid white 2px";
          commentRef.current.style.display = "inline-block";
          setTimeout(() => {
            commentRef.current.style.display = "none";
          }, 2000);
          GetCommentsOfMovie();
        })
        .catch((err) => console.log(err));
    } else if (comment.title === "") {
      commentTitleRef.current.style.border = "solid red 4px";
    } else {
      commentContentRef.current.style.border = "solid red 4px";
    }
  };

  const GetCommentsOfMovie = () => {
    if(movieInDatabase[0]?._id){
      axios
      .get(
        `${API_BASE}comments/movie/${movieInDatabase[0]?._id}`
      )
      .then((res) => {
        setDisplayComments(res.data.response);
      })
      .catch((err) => console.log(err));
    }
    
  };

  useEffect(() => {
    GetCommentsOfMovie();
  }, [movieInDatabase]);


  const handleMovieRating = (newValue) => {
    setUserRating(newValue);
    if (currentUser.length !== 0 && newValue !== 0) {
      axios.post(`${API_BASE}userratings`, {
          userId: currentUser[0]._id,
          movieId: movieInDatabase[0]._id,
          rating: newValue * 2,
        })
        .then((res) => {
          setEditRating(true);
          setShowRating(true)
        })
        .catch((err) => console.log(err));
    }
  };
  //console.log(editRating);
  return (
    <body >
      <div className="film backdropped logged-in backdrop-loaded">
        <div id="pw-oop-flex_leaderboard_container">
          <div style={{ display: "none" }}></div>
        </div>

        <div className="backdrop-container movie-card">
          <div id="backdrop" className="backdrop-wrapper  -loaded">
            <div className="backdropplaceholder js-backdrop-placeholder"></div>
            <div
              className="backdropimage js-backdrop-image"
              style={{
                backgroundPosition: "center -7px",
                backgroundImage: `url(https://image.tmdb.org/t/p/w1280/${movie?.backdrop_path})`,
              }}
            ></div>
            <div className="backdropmask js-backdrop-fade"></div>
          </div>
        </div>

        <div className="site-body -backdrop">
          <div id="yorum-form-moviecard" className="content-wrap">
            <div className="cols-3 overflow" style={{ position: "relative" }}>
              <div id="sol-bolum" className="col-6 gutter-right-1 col-poster-large">
                <section className="poster-list -p230 -single no-hover el col">
                  <div id="movie-card-poster" className="react-component poster film-poster film-poster-369835 film-watched">
                    <div>
                      <img
                        src={`https://image.tmdb.org/t/p/w342/${movie?.poster_path}`}
                        width="100%"
                        height="345vh"
                        alt={movie?.original_title}
                        className="image"
                      />
                      <span className="frame has-menu movie-card">
                        <span className="frame-title">
                          {movie?.original_title}
                        </span>
                      </span>
                    </div>
                  </div>

                  <ul className="film-stats">
                    <li className="stat filmstat-watches">
                      <Link
                        to={`/movie/${movie?.original_title}/members/`}
                        className="has-icon icon-watched icon-16 tooltip"
                      >
                        <span className="icon"></span>
                        <small className="watched-liked">{language === "EN" && "watched" || language === "TR" && "izlendi" || language === "DE" && "schaute"} </small>{" "}
                        {watchedCount}<span className="fas fa-eye icon-eye"></span>
                      </Link>
                    </li>
                    <li className="stat filmstat-lists">
                      <Link
                        to={`/movie/${movie?.original_title}/lists/by/popular/`}
                        className="has-icon icon-list icon-16 tooltip"
                      >
                        <span className="icon"></span>
                        <small className="watched-liked">{language === "EN" && "listed" || language === "TR" && "listelendi" || language === "DE" && "gefallen"}</small>{" "}
                        {listedCount}<span className="fab fa-windows  icon-window"></span>
                      </Link>
                    </li>
                    <li className="stat filmstat-likes">
                      <Link
                        to={`/film/${movie?.original_title}/likes/`}
                        className="has-icon icon-like icon-liked icon-16 tooltip"
                      >
                        <span className="icon"></span>
                        <small className="watched-liked">{language === "EN" && "liked" || language === "TR" && "begendi" || language === "DE" && "gelistet"}</small>{" "}
                        {likesCount}<span className="fas fa-heart  icon-heart"></span>
                      </Link>
                    </li>
                  </ul>
                </section>

                <section id="whereto-watched-panel" className="watch-panel js-watch-panel">
                  <div className="header">
                    {/* <h3 className="title">{language === "EN" && "Where to watch" || language === "TR" && "Nerede İzlenir" || language === "DE" && "Wo zu sehen"}</h3> */}

                    <p className="trailer-link js-watch-panel-trailer">
                      <Link
                        className="play track-event js-video-zoom cboxElement"
                        data-track-category="Trailer"
                        target="_blank"
                        rel="noreferrer"
                        to={videoId !== "" ? `//www.youtube.com/embed/${videoId}?rel=0&amp;wmode=transparent` : "#"}
                      >
                        <span className="name">{language === "EN" && "Trailer" || language === "TR" && "Fragman" || language === "DE" && "Anhänger"}</span>{"  "}
                         <span  className="fas fa-play"
                         
                         >
</span>
                      </Link>
                    </p>
                  </div>

                  <div id="watch">
                     {/* <div className="other -message">
                      <a className="label" href="/pro/">
                        Go
                        <span className="badge -pro -small">Pro</span> to
                        customize
                        <span className="wide-only"> this list</span>
                      </a>
                    </div>  */}

                    <div className="other">
                      <span
                        className="more track-event js-film-availability-link cboxElement"
                      >
                        <WhereToWatch id={id} />
                        {/* <span className="qualifier">All</span>
                        <span className="wide-only"> services</span>… */}
                      </span>
                      {/* <Link
                        to="https://www.justwatch.com/"
                        target="_blank"
                        className="jw-branding"
                      >
                        JustWatch
                      </Link> */}
                    </div>
                  </div>
                </section>
              </div>

              <div id="orta-bolum" className="col-17">
                <section
                  id="featured-film-header"
                  className="film-header-lockup -default"
                >
                  <h1 className="headline-1 js-widont prettify">
                    {movie?.original_title}
                  </h1>
                  <p>
                    {" "}
                    <small className="number">
                      <Link
                        to={`/movie/year/${movie?.release_date.split("-")[0]}/`}
                      >
                        {movie?.release_date.split("-")[0]}
                      </Link>
                    </small>
                    {language === "EN" && "Directed By" || language === "TR" && "Yönetmen" || language === "DE" && "Direktor"}{" "}
                    <Director id={id} type="movieCard" />
                  </p>
                </section>

                <section className="section col-10 col-main">
                  <section>
                    <div className="review body-text -prose -hero prettify">
                      <h4 className="tagline">{movie?.tagline}</h4>

                      <div className="truncate" data-truncate="450">
                        <p className="description-box">{movie?.overview}</p>
                      </div>
                    </div>
                  </section>

                  {/* TAB AREA  */}
                  <div id="tabbed-content" className="selected tabbed-content">
                    <header>
                      <div>
                        <Tabs>
                          <div label={language === "EN" && "CAST" || language === "TR" && "OYUNCU..." || language === "DE" && "Werfen"}>
                            <br/>
                            <Starring id={id} page={"movie"} />
                          </div>
                          <div label={language === "EN" && "CREW" || language === "TR" && "EKIP" || language === "DE" && "Besat..."}>
                            <Crew id={id} />
                          </div>

                          <div label={language === "EN" && "DETAILS" || language === "TR" && "DETAYLAR" || language === "DE" && "Einzelheiten"}>
                            <Details {...movie} />
                          </div>


                          <div label={language === "EN" && "GENRES" || language === "TR" && "TÜR" || language === "DE" && "Genres"}>
                            <div>
                              {/* <h3 className="hidden">{language === "EN" && "Genres" || language === "TR" && "Tür" || language === "DE" && "Genres"}</h3> */}
                              <br/>
                              <div className="text-sluglist capitalize">
                                <p>
                                  {movie?.genres.map(({ id,name }) => (
                                    <Link
                                      to={`/moviesAll/${id}`}
                                      className="text-slug"
                                    >
                                      {name}
                                    </Link>
                                  ))}
                                </p>
                              </div>
                            </div>
                          </div>

                          <div label={language === "EN" && "SIMILARITY" || language === "TR" && "BENZER" || language === "DE" && "Ähnlichkeit"}>
                            <div>
                              {/* <h3 className="hidden">similarity</h3> */}
                             
                            <section id="liked-films" className="liked-column -films">

                                <h2 className="section-heading"><a href="/bratpitt/likes/films/" className="tooltip" data-original-title="487&nbsp;films">{language === "EN" && "Similar Films" || language === "TR" && "Benzer Filmler" || language === "DE" && "Ähnliche Filme"}</a></h2>
                                {/* <a href="/bratpitt/likes/films/" className="all-link">All</a> */}
                                  <SimilarMovies currentMovie={movie}/>
                            </section>        

                            </div>
                          </div>

                        </Tabs>
                      </div>
                    </header>
                  </div>

                  <p className="text-link text-footer">
                    {movie?.runtime}&nbsp;{language === "EN" && "mins" || language === "TR" && "dk" || language === "DE" && "minuten"} &nbsp; 
                    {language === "EN" && "More at" || language === "TR" && "Daha fazlası için" || language === "DE" && "Für mehr"}&nbsp;
                    <a
                      href={`http://www.imdb.com/title/${movie?.imdb_id}/maindetails`}
                      className="micro-button track-event"
                      data-track-action="IMDb"
                    >
                      IMDb
                    </a>&nbsp;
                    <a
                      href={`https://www.themoviedb.org/movie/${movie?.id}/`}
                      className="micro-button track-event"
                      data-track-action="TMDb"
                    >
                      TMDb
                    </a>
                    {/* <span
                      className="report-link has-icon icon-report tooltip tooltip-close-on-click cboxElement"
                      data-report-url="/ajax/film:369835/report-form"
                      data-original-title="Report this film"
                    >
                      <span className="icon"></span>Report this film
                    </span> */}
                  </p>
                </section>

                <div id="sag-bolum" className="aside sidebar">
                  <section id="userpanel" className="actions-panel">
                    <ul className="js-actions-panel">
                      <li
                        className="action-large -watch"
                        onClick={handleWatchClick}
                      >
                        <span
                          className="film-watch-link-target"
                          data-film-id="369835"
                        >
                          <span className="film-watch-link -large -watched">
                            {watchedInfo ? (
                              <i
                                className="fas fa-eye"
                                style={{
                                  fontSize: "35px",
                                  color: "#51E11E",
                                  cursor: "pointer",
                                }}
                              ></i>
                            ) : (
                              <i
                                className="far fa-eye"
                                style={{
                                  fontSize: "35px",
                                  color: "white",
                                  cursor: "pointer",
                                }}
                              ></i>
                            )}

                            <span
                              className="action -watch -on ajax-click-action"
                              data-action="/"
                            >
                              {language === "EN" && "Watched" || language === "TR" && "İzlendi" || language === "DE" && "Schaute"}
                            </span>
                          </span>
                        </span>
                      </li>
                      <li
                        className="action-large -like"
                        onClick={handleLikeClick}
                      >
                        <span className="like-link-target react-component">
                          <span className="like-link">
                       
                            {likedInfo ? (
                              <i
                                className="fas fa-heart"
                                style={{
                                  fontSize: "35px",
                                  color: "orange",
                                  cursor: "pointer",
                                }}
                              ></i>
                            ) : (
                              <i
                                className="far fa-heart"
                                style={{
                                  fontSize: "35px",
                                  color: "white",
                                  cursor: "pointer",
                                }}
                              ></i>
                            )}
                            <span
                              className="action -like ajax-click-action  -on"
                              data-action="/s/film:369835/like/"
                              data-recaptcha-action="film_like"
                            >
                              {language === "EN" && "Liked" || language === "TR" && "Begendi" || language === "DE" && "Gelistet"}
                            </span>
                          </span>
                        </span>
                      </li>

                      <li
                        className="action-large -watchlist"
                        onClick={handleWatchlistClick}
                      >
                        <span className="like-link-target react-component">
                          <span className="like-link">
                           

                            {watchlistInfo ? (
                              <i
                                className="fas fa-clock"
                                style={{
                                  fontSize: "35px",
                                  color: "#5157f0",
                                  cursor: "pointer",
                                }}
                              ></i>
                            ) : (
                              <i
                                className="far fa-clock"
                                style={{
                                  fontSize: "35px",
                                  color: "white",
                                  cursor: "pointer",
                                }}
                              ></i>
                            )}
                            <span
                              className="action -like ajax-click-action  -on"
                              data-action="/s/film:369835/like/"
                              data-recaptcha-action="film_like"
                            >
                              {language === "EN" && "Watchlist" || language === "TR" && "İzlenecek" || language === "DE" && "Beobachtu..."}
                            </span>
                          </span>
                        </span>
                      </li>
                     

                      <li className="-row-clear panel-rate js-panel-rate">
                        {!editRating ? <span className="rateit-label js-rateit-label">
                          <ReactStars
                            size={30}
                            isHalf={true}
                            char={"★"}
                            value={userRating}
                            onChange={handleMovieRating}
                          />
                        </span> : ""}
                        
                        {showRating ? <span className="rateit-label js-rateit-label">
                          <ReactStars
                            size={30}
                            isHalf={true}
                            char={"★"}
                            value={userRating}
                            edit={false}
                          />
                        </span> : ""}
                        
                        <input
                          id="frm-sidebar-rating"
                          data-film-id="369835"
                          className="panel-rateit-field"
                          type="range"
                          min="0"
                          max="10"
                          step="1"
                          value="0"
                          style={{ display: "none" }}
                        />
                        <div
                          className="rateit panel-rateit instant-rating"
                          data-film-id="369835"
                          data-rate-action="/film/the-suicide-squad/rate/"
                          data-rateit-backingfld="#frm-sidebar-rating"
                          data-rateit-starwidth="18"
                          data-rateit-starheight="32"
                          data-rateit-resetable="false"
                        >
                          <button
                            id="rateit-reset-2"
                            className="rateit-reset"
                            aria-label="reset rating"
                            aria-controls="rateit-range-2"
                            style={{ display: "none" }}
                          ></button>
                
                        </div>
                    
                      </li>

                    

                      <li id="main-content-list">  
 
                      <MultiSelect1 />
                      </li>                         
                      <li id="main-content-list">  
                        <a 
                          href="#"
                          className="new-list menu-item-add-to-list"
                          data-film-id="11111"
                          data-film-name="The name of film"
                          data-new-list-with-film-action="/list/new/with/the-name-film/"
                        >
                          {" "}
                          {language === "EN" && "Add to lists..." || language === "TR" && "Listeye ekle" || language === "DE" && "Zu Listen hinzufügen"}{" "}
                        </a>
                      </li>
                    </ul>
                  </section>
                </div>

                <section id="movie-card-yorumlar" className="film-recent-reviews">
                 
                  
                  <div>
                    <form>
                      <input
                        ref={commentTitleRef}
                        type="text"
                        name="title"
                        placeholder={language === "EN" && "Comment title..." || language === "TR" && "Yorum başlığı..." || language === "DE" && "Kommentartitel..."}
                        value={comment.title}
                        onChange={handleReviewChange}
                      />
                      <br />
                      <br />
                      <textarea
                        ref={commentContentRef}
                        name="content"
                        placeholder={language === "EN" && "Comment content..." || language === "TR" && "Yorum içeriği..." || language === "DE" && "Inhalt kommentieren..."}
                        value={comment.content}
                        onChange={handleReviewChange}
                      ></textarea>
                      <br />
                      <br />
                      <button
                        type="button"
                        onClick={postReview}
                        style={{ pointer: "cursor" }}
                      >
                        {language === "EN" && "Submit" || language === "TR" && "Gönder" || language === "DE" && "Einreichen"}
                      </button>
                      <span
                        ref={commentRef}
                        style={{
                          display: "none",
                          color: "#4DDC1A",
                          marginLeft: "3%",
                        }}
                      >
                        <b>{language === "EN" && "Successfully added!" || language === "TR" && "Başarıyla Eklendi!" || language === "DE" && "Erfolgreich hinzugefügt!"}</b>
                      </span>
                      <br />
                      <br />
                    </form>
                  </div>
                  <MovieReviews displayComments={displayComments} currentUser={currentUser} movieInDatabase={movieInDatabase}/>

                  {/* <section
                    id="popular-reviews"
                    className="film-reviews section"
                    data-url="/ajax/the-suicide-squad/popular-reviews/"
                    data-how-many="12"
                  >
                    <h2 className="section-heading under-line-1">
                      <a href="/film/the-suicide-squad/reviews/by/activity/">
                        Popular reviews
                      </a>
                    </h2>
                    <a
                      href="/film/the-suicide-squad/reviews/by/activity/"
                      className="all-link"
                    >
                      More
                    </a>
                    <ul className="film-popular-review">
                      
                    </ul>
                  </section> */}

                  {/* <section
                    id="recent-reviews"
                    className="film-reviews section"
                    data-url="/ajax/the-suicide-squad/recent-reviews/"
                    data-how-many="12"
                  >
                    <h2 className="section-heading under-line-1">
                      <a href="/film/the-suicide-squad/reviews/by/added/">
                        Recent reviews
                      </a>
                    </h2>
                    <a
                      href="/film/the-suicide-squad/reviews/by/added/"
                      className="all-link"
                    >
                      More
                    </a>
                    <ul className="film-popular-review">
                      
                    </ul>
                  </section> */}
                </section>

                <section id="film-popular-lists" className="list-set section">
                  <PopularLists />
                </ section>

              </div>
            </div>
          </div>
        </div>

        <div className="jnotify-container"></div>
      </div>
    </body>
  );
}