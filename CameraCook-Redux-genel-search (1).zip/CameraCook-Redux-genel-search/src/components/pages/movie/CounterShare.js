import React, { useEffect, useState } from "react";
import { IoMdPlay } from "react-icons/io";
import { RiLinksFill, RiFacebookFill } from "react-icons/ri";
import { GoPlus } from "react-icons/go";
import { Link } from "react-router-dom";
import { VscTwitter } from "react-icons/vsc";
import { ImHeart, ImShare2 } from "react-icons/im";
import axios from "axios";
import { calculateDuration } from "../utils/duration";
import "./CounterShare.css";

const SingleLatest = ({ poster_path, original_title, adult, id }) => {
  const [duration, setDuration] = useState("");
  useEffect(() => {
    const getDuration = async () => {
      try {
        const {
          data: { runtime },
        } = await axios.get(
          `https://api.themoviedb.org/3/movie/${id}?api_key=${process.env.REACT_APP_API_KEY}&append_to_response=credits&language=tr-TR`
        );
        setDuration(calculateDuration(runtime));
      } catch (error) {}
    };
    getDuration();
  }, [duration]);
  return (
    <React.Fragment>
      <img
        className="img-fluid"
        src={`https://image.tmdb.org/t/p/original/${poster_path}`}
      />
      <div className="container latest_card_container">
        <div className="block-description">
          <div className="movie-time">
            <span className="badge badge-secondary rounded-0 ">
              {adult && "+18"}
            </span>
            <span className="text-white filmduration">{duration}</span>
          </div>
          <div className="hover-button">
            <Link to={`/movie/${id}`}>
              <button
                type="button"
                className="btn btn-secondary rounded-0 play-button"
              >
                <span className="playnow">
                  <span className="playicon">
                    {" "}
                    <IoMdPlay className="io" />
                  </span>
                  PLAY
                </span>
              </button>
            </Link>
          </div>
        </div>
        <div className="block-social-info">
          <ul className="  d-flex flex-column paddingzero">
            <li className="socialinfo">
              <button
                id="btnsetting"
                type="button"
                className=" rounded-circle btn btn-heart position-relative border-secondary  border-3"
              >
                <ImShare2 className="iconshare" />
                <div className="share-box">
                  <div className="d-flex align-items-center">
                    <a
                      href="https://www.facebook.com/sharer?u=https://www.design.com/wp-themes/streamit_wp/movie/shadow/"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="share-ico"
                      tabIndex="0"
                    >
                      <RiFacebookFill />
                    </a>
                    <a
                      href="https://twitter.com/intent/tweet?text=Currentlyreading"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="share-ico"
                      tabIndex="0"
                    >
                      <VscTwitter />
                    </a>
                    <a
                      href="#"
                      data-link="https://www.design.com/wp-themes/streamit_wp/movie/shadow/"
                      className="share-ico iq-copy-link"
                      tabIndex="0"
                    >
                      <RiLinksFill />
                    </a>
                  </div>
                </div>
              </button>
            </li>
            <li className="socialinfo ">
              <button
                id="btnsetting"
                type="button"
                className=" btnsetting rounded-circle btn btn-heart position-relative border-secondary  border-3"
              >
                <ImHeart className="iconshare" />
                <span className="position-absolute top-5 start-100 translate-middle  rounded-circle bg-secondary share-num">
                  +99{" "}
                </span>
              </button>
            </li>
            <li className="socialinfo ">
              <button
                id="btnsetting"
                type="button"
                className=" btnsetting rounded-circle btn btn-heart position-relative border-secondary  border-3"
              >
                <GoPlus className="iconshare" />{" "}
              </button>
            </li>
          </ul>
        </div>
      </div>
    </React.Fragment>
  );
};
export default SingleLatest;
