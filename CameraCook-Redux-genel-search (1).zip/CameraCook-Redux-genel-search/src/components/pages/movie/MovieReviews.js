import React,{useEffect,useState} from 'react'
import { useSelector } from "react-redux"
import axios from 'axios'
import { Link } from 'react-router-dom';
import "./movieReview.css";
import { API_BASE }  from "../../../actions/api_base";

export default function MovieReviews(props) {
    const [state, setstate] = useState([]);
    const [editReviewClicked, setEditReviewClicked] = useState(false)
    const [reviewLikes, setReviewLikes] = useState([])
    const { language } = useSelector((state) => state.searchMovies);

    useEffect(() => {
        GetCommentsOfMovie()
        const array = []
        props.currentUser[0]?.commentLikes.map(likes=>{
          return array.push(likes.commentId)
        })
        setReviewLikes(array)
        //console.log(array)
    }, [props])

    const GetCommentsOfMovie = () => {
        if(props.movieInDatabase[0]?._id){
          axios
          .get(
            `${API_BASE}comments/movie/${props.movieInDatabase[0]?._id}`
          )
          .then((res) => {
            //console.log(res.data.response)
            setstate(res.data.response.reverse());
          })
          .catch((err) => console.log(err));
        } 
      };


    const EditReview = (e) => {
        if(!editReviewClicked){

            const targetInput = e.target.id + "59"
            e.target.parentElement.parentElement.parentElement.parentElement.nextElementSibling.children[0].id = targetInput
            // e.target.parentElement.parentElement.parentElement.parentElement.nextElementSibling.children[1].id = targetInput
            e.target.parentElement.parentElement.parentElement.parentElement.nextElementSibling.style.height = "280px"
            e.target.parentElement.parentElement.parentElement.parentElement.nextElementSibling.children[0].disabled = false;
            e.target.parentElement.parentElement.parentElement.parentElement.nextElementSibling.children[0].style.border = "red solid 2px"
            e.target.parentElement.href = `#${targetInput}`
            setEditReviewClicked(true)
        }
    }

    const RemoveReview = (e) => {
        if(!editReviewClicked){
            axios.delete(`${API_BASE}comments/${e.target.id}`)
            .then(res=>{
                console.log(res.data)
                GetCommentsOfMovie()
            })
            .catch(err=>console.log(err))
        }
    }

    const updateReview = (e) => {
        
        const str = e.target.id
        

      if(e.target.value !== ""){
        axios.put(`${API_BASE}comments/${str.substring(0, str.length - 2)}`, {content: e.target.value})
            .then(res=>{
                console.log(res.data);
                e.target.parentElement.style.height = "110px"
                e.target.style.border = "none";
                e.target.disabled = true;
                setTimeout(() => {
                    setEditReviewClicked(false)
                }, 1000);
                GetCommentsOfMovie()
            })
            .catch(err=>console.log(err))
      } else {
        axios.delete(`${API_BASE}comments/${str.substring(0, str.length - 2)}`)
        .then(res=>{
            console.log(res.data)
            e.target.parentElement.style.height = "110px"
                e.target.style.border = "none";
                e.target.disabled = true;
                setTimeout(() => {
                    setEditReviewClicked(false)
                }, 1000);
            GetCommentsOfMovie()
        })
        .catch(err=>console.log(err))        
      } 
    }

    const ReviewLike = (e) => {
      console.log(e)
      
      axios.post(`${API_BASE}commentlikes`, {
        userId: props.currentUser[0]._id,
        commentId: e.target.id
      })
      .then(res=>{
        console.log(res.data)
        console.log(e.target.className)
        if(e.target.className === "notLiked"){
          e.target.classList.remove("notLiked")
          e.target.classList.add("alreadyLiked")
          e.target.nextElementSibling.innerText = parseInt(e.target.nextElementSibling.innerText) +1
        } else if (e.target.className === "alreadyLiked"){
          e.target.classList.remove("alreadyLiked")
          e.target.classList.add("notLiked")
          e.target.nextElementSibling.innerText = parseInt(e.target.nextElementSibling.innerText) -1
        }
      })
      .catch(err=>console.log(err))

    }

    return (
        <section
                    id="popular-reviews-with-friends"
                    className="film-reviews section"
                  >
                    <h2 className="section-heading">
                      <a href="/basribaba/friends/film/the-suicide-squad/reviews/by/activity/">
                      {language === "EN" && "REVIEWS" || language === "TR" && "YORUMLAR" || language === "DE" && "BEWERTUNGEN"}
                      </a>
                    </h2>
                    {/* <a
                      href="/basribaba/friends/film/the-suicide-squad/reviews/by/activity/"
                      className="all-link"
                    >
                      More
                    </a> */}
                    <ul className="film-popular-review">
                      {state?.length === 0 ? (
                        <span style={{ color: "gray" }}>
                          {language === "EN" && "There are no reviews yet !!!" || language === "TR" && "Henüz yorum yok !!!" || language === "DE" && "Es gibt noch keine Bewertungen !!!"}
                        </span>
                      ) : (
                        state?.map((review) => {
                          return (
                            <li
                              className="film-detail"
                              data-viewing-id="187768414"
                              data-person="Schaffrillas"
                              key={review._id}
                            >
                              <Link
                                className="avatar -a40"
                                to={`/member-card/${review.userId[0]._id}`}
                                data-original-title=""
                              >
                                <img
                                  src={review.userId[0]?.mediaId[0]?.url}
                                  alt={review.userId?.firstname}
                                  width="40"
                                  height="40"
                                />
                              </Link>{" "}
                              <div className="film-detail-content">
                                <div className="attribution-block -large">
                                  <p className="attribution">
                                    <Link
                                      to={`/member-card/${review.userId[0]._id}`}
                                      className="context"
                                      title="Read James (Schaffrillas)’s review"
                                    >
                                      {" "}
                                      {language === "EN" && "Commented by" || language === "TR" && "Yorumlayan" || language === "DE" && "Kommentiert von"}&nbsp;
                                      <strong className="name">
                                        {review.userId[0].firstname}
                                      </strong>{" "}
                                    </Link>
                                    {/* <span className="rating -green rated-9">
                                      {" "}
                                      ★★★★½{" "}
                                    </span> */}
                                    {/* <span className="content-metadata">
                                      <a
                                        href="/schaffrillas/film/the-suicide-squad/"
                                        className="has-icon icon-comment icon-16 comment-count"
                                      >
                                        <span className="fas fa-comment-alt"></span>{" "}
                                        167
                                      </a>{" "}
                                    </span>{" "} */}
                                    {review.userId[0]._id === props.currentUser[0]._id ?
                                        <span style={{position: "absolute",right:"0"}}>
                                            <a><i className="fas fa-edit" style={{cursor:"pointer", marginRight:"10px"}}  id={review._id}  onClick={EditReview}></i></a>
                                            <i className="fas fa-trash" id={review._id} style={{cursor:"pointer"}} onClick={RemoveReview}></i>
                                        </span> : ""
                                    }
                                    
                                  </p>
                                  
                                </div>
                                <div
                                  id="ctn"
                                  className="body-text -prose collapsible-text"
                                  data-full-text-url="/s/full-text/viewing:187768414/"
                                >
                                    {/* <a name="target">&nbsp;</a> */}
                                    <textarea type="text" id={review._id} className="target-label" defaultValue={review.content} style={{backgroundColor:"#141414", border:"none", width:"550px", height:"110px", lineHeight:"30px",paddingTop:"10px", resize:"none"}} disabled={true} onBlur={updateReview}/>
                                    
                                  
                                </div>
                                <p
                                  className="like-link-target react-component -monotone"
                                  data-likeable-uid="viewing:187768414"
                                  data-likeable-name="review"
                                  data-likeable="true"
                                  data-likes-page="/schaffrillas/film/the-suicide-squad/likes/"
                                  data-format="svg"
                                  data-owner="Schaffrillas"
                                >
                                  <span >
                                  <span
                                        onClick={ReviewLike}
                                          id={review._id}
                                          className={reviewLikes.includes(review._id) ? "alreadyLiked" : "notLiked"}
                                        >
                                          {language === "EN" && "Like review" || language === "TR" && "Yorumu beğen" || language === "DE" && "Bewertung liken"}
                                        </span>
                                    &nbsp;{" "}
                                    <span style={{color:"#9ab",fontSize:"18px"}}>
                                      {review.commentLikesCount}
                                    </span>
                                    &nbsp;
                                    <span style={{color:"#9ab"}}>
                                    {language === "EN" && "Likes" || language === "TR" && "Beğeniler" || language === "DE" && "Likes"}
                                    </span>
                                  </span>
                                </p>
                              </div>
                            </li>
                          );
                        })
                      )}
                    </ul>
                  </section>
    )
}