import axios from "axios";
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";

const Crew = ({ id }) => {
  const [crew, setCrew] = useState([]);

  useEffect(() => {
    axios
      .get(
        `https://api.themoviedb.org/3/movie/${id}?api_key=${process.env.REACT_APP_API_KEY}&append_to_response=credits&language=tr-TR`
      )
      .then(
        ({
          data: {
            credits: { crew },
          },
        }) => {
          console.log(crew);
          setCrew(
            Array.from(crew, ({ original_name, job }) => ({
              job,
              original_name,
            }))
          );
        }
      );
  }, [id]);

  return (
    <div label="CREW">
      {crew.map(({ job, original_name }, index) => (
        <div key={index}>
          <h3>
            <span>{job}</span>
          </h3>
          <div className="text-sluglist">
            <p>
              <Link to={`/People/${job}/${original_name}`} className="text-slug">
                {original_name}
              </Link>
            </p>
          </div>
        </div>
      ))}
    </div>
  );
};

export default Crew;
