import React,{ useState, useEffect} from 'react';
import { useSelector } from "react-redux";
import { Link } from 'react-router-dom';
import axios from 'axios';

export default function SimilarMovies(props) {
    const [state, setstate] = useState([]);
    const [page, setPage] = useState(1);
    const { language } = useSelector((state) => state.searchMovies);


    useEffect(() => {
        GetSimilarMovies()
    }, [props])

    const GetSimilarMovies = () => {
        axios.get(`https://api.themoviedb.org/3/movie/${props.currentMovie.id}/similar?api_key=${process.env.REACT_APP_API_KEY}&language=${
            language.toLowerCase() + "-" + language
          }&page=${page}`)
        .then(res=>{
            //console.log(res.data)
            setstate(res.data.results)
        })
        .catch(err=>console.log(err))
    }
    //console.log(props)
    return (
        <div>
            <ul className="poster-list -p70 -grid">
                {state.map(movie=>{
                    return <li className="poster-container film-not-watched" key={movie.id}>
                <div className="react-component poster film-poster film-poster-368594 linked-film-poster removed-from-watchlist" data-component-class="globals.comps.FilmPosterComponent" data-film-id="368594" data-film-name={movie.original_title} data-poster-url="/film/slaying-the-dragon/image-150/" data-film-release-year="1988" data-new-list-with-film-action="/list/new/with/slaying-the-dragon/" data-remove-from-watchlist-action="/film/slaying-the-dragon/remove-from-watchlist/" data-add-to-watchlist-action="/film/slaying-the-dragon/add-to-watchlist/" data-rate-action="/film/slaying-the-dragon/rate/" data-mark-as-watched-action="/film/slaying-the-dragon/mark-as-watched/" data-mark-as-not-watched-action="/film/slaying-the-dragon/mark-as-not-watched/" data-film-link="/film/slaying-the-dragon/" data-film-in-watchlist="false"><div><img src={`https://image.tmdb.org/t/p/w92/${movie?.poster_path}`} width="70" height="105" alt={movie.original_title} srcSet={`https://image.tmdb.org/t/p/w92/${movie?.poster_path}`} className="image"/><Link to={`/movie/${movie.id}`} className="frame has-menu" data-original-title="Slaying the Dragon (1988)"><span className="frame-title">{movie.original_title}</span><span className="overlay"></span><span className="overlay-actions js-film-options -w70" style={{display: "none"}}><span className="film-watch-link-target" data-film-id="368594"><span className="film-watch-link"><span className="has-icon icon-16 icon-watch ajax-click-action" data-action="/film/slaying-the-dragon/mark-as-watched/"><span className="replace icon"></span>Seen this film?</span></span></span><span className="like-link-target" data-likeable-uid="film:368594"><span className="like-link"><span className="has-icon icon-16 ajax-click-action  icon-like" data-action="/s/film:368594/like/" data-recaptcha-action="film_like"><span className="icon"></span>Like this film?</span></span></span><span className="replace menu-link icon"></span></span></Link></div></div>

                </li>
                })}                     
            </ul>		
        </div>
    )
}