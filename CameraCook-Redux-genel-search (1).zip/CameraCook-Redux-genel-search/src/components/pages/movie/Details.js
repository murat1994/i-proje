import React from "react";
import { Link } from "react-router-dom";

const Details = ({
  production_companies,
  production_countries,
  spoken_languages,
}) => {
  return (
    <div>
      <h3>
        <span>Studios</span>
      </h3>
      <div className="text-sluglist">
        <p>
          {production_companies.map(({ name }) => (
            <Link to={`/People/studio/${name}/`} className="text-slug">
              {name}
            </Link>
          ))}
        </p>
      </div>

      <h3>
        <span>Country</span>
      </h3>
      <div className="text-sluglist">
        <p>
          {production_countries.map(({ name }) => (
            <a href={`/movies/country/${name}/`} className="text-slug">
              {name}
            </a>
          ))}
        </p>
      </div>

      <h3>
        <span>Languages</span>
      </h3>
      <div className="text-sluglist">
        <p>
          {spoken_languages.map(({ english_name }) => (
            <a href={`/movies/language/${english_name}/`} className="text-slug">
              {english_name}
            </a>
          ))}
        </p>
      </div>
    </div>
  );
};

export default Details;
