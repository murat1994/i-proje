import React, {useEffect} from "react";
import {useSelector, useDispatch} from "react-redux";
import { Slider } from "../Slider/Slider";

import UpMovies from "../UpMovies";
import TopTen from "./topTen/TopTen";
// import FullHdLink from '../sil';
import { Parallax } from "../Parallax";
import Parallax1  from "../Parallax1";
// import {SlickSlider} from '../SlickSlider';
import Swiper from "../Slider/Swiper";
import {getUsers} from "../../actions/auth.action";
import Row from "../TvShows/Row";


function Home() {

  
  return (
    <>
      <Swiper />
      
      <TopTen />

      <UpMovies />
      {/* <FullHdLink/> */}

      <Parallax />
     
      {/* <Parallax1 /> */}
      <Row
        title="NETFLIX SERIALS"
        id="NETF"
        fetchUrl={`/discover/tv?api_key=${process.env.REACT_APP_API_KEY}&with_networks=213`}
        isLargeRow
      />
      <Row
        title="PRIME VIDEO "
        id="PRIME"
        fetchUrl={`/discover/tv?api_key=${process.env.REACT_APP_API_KEY}&with_networks=1024`}
        isLargeRow
      />
      <Row
        title="BLUTV "
        id="BLUTV"
        fetchUrl={`/discover/tv?api_key=${process.env.REACT_APP_API_KEY}&with_networks=1747`}
        isLargeRow
      />
    </>
  );
}

export default Home;
