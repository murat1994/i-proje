import React, {useEffect, useState} from 'react';
import { useParams } from 'react-router';
import { useSelector } from "react-redux";
import "./PeopleCard.css";
import axios from 'axios';
import { Link } from 'react-router-dom';
import { API_BASE }  from "../../actions/api_base";


export default function PeopleCard() {
  const [state, setstate] = useState([])
  const [movies, setMovies] = useState([])
  const [curentUser, setCurrentUser] = useState([])
  const [movieIds, setMovieIds] = useState([])
  const [countWatchedMovies, setCountWatchedMovies] = useState(0)
  const {id} = useParams()
  const { language } = useSelector((state) => state.searchMovies);
  const { user } = useSelector((state) => state.auth);

  useEffect(() => {
    getDetails();
    getMovies()
    getCurrentUser()
  }, [id, language])

  const getCurrentUser = ()=> {
    axios
      .get(`${API_BASE}users/${user.id}`)
      .then((res) => {
        setCurrentUser(res.data.response);
      })
      .catch((err) => console.log(err));
  }
  
  const getDetails = async () => {
    try {
      const { data } = await axios.get(
        `https://api.themoviedb.org/3/person/${id}?api_key=${process.env.REACT_APP_API_KEY}&language=${
          language.toLowerCase() + "-" + language
        }`
      );
      setstate([data]);
    } catch (error) {}
  };

  const getMovies = async () => {
    try {
      const { data } = await axios.get(
        `https://api.themoviedb.org/3/person/${id}/movie_credits?api_key=${process.env.REACT_APP_API_KEY}&language=${
          language.toLowerCase() + "-" + language
        }`
      );
      setMovies(data.cast);
      setMovieIds(data.cast.map(movie=>movie.id));
    } catch (error) {}
  };

  useEffect(() => {
    let count = 0
    curentUser[0]?.watched.forEach(watchedMovies=>{
      if(movieIds.includes(parseInt(watchedMovies.movieId[0].tmdb_id,10))){
        count ++
      }
    })
    setCountWatchedMovies(count)
  }, [curentUser,movieIds])

  console.log(state)
  return (
    <div>
      
<body className="wide crew-page filmography-page logged-in show-hide-toggle" data-type="actor" data-tmdb-type="person" data-tmdb-id="17628">
	
  <div id="content" className="site-body">
      <div className="content-wrap">
  <div className="cols-2">
  <section className="section col-17 col-main">
    <header className="page-header">
      <div className="contextual-title">
        <h1 className="title-1 prettify">
          <span className="context">{language === "EN" && "Films Starring" || language === "TR" && "Yildiz Oyuncu" || language === "DE" && "Filme in der Hauptrolle"}</span>
          {state[0]?.name}
        </h1>
      </div>
    </header>
    
        <ul className="poster-list -p150 -grid -constrained clear">
          {movies.map(movie=>{
            return movie.poster_path !== null && <li className="poster-container film-not-watched" key={movie?.id}>
              <div className="react-component poster film-poster film-poster-37833 linked-film-poster removed-from-watchlist" data-component-class="globals.comps.FilmPosterComponent" data-film-id="37833" data-film-name="Scott Pilgrim vs. the World" data-poster-url="/film/scott-pilgrim-vs-the-world/image-150/" data-film-release-year="2010" data-new-list-with-film-action="/list/new/with/scott-pilgrim-vs-the-world/" data-remove-from-watchlist-action="/film/scott-pilgrim-vs-the-world/remove-from-watchlist/" data-add-to-watchlist-action="/film/scott-pilgrim-vs-the-world/add-to-watchlist/" data-rate-action="/film/scott-pilgrim-vs-the-world/rate/" data-mark-as-watched-action="/film/scott-pilgrim-vs-the-world/mark-as-watched/" data-mark-as-not-watched-action="/film/scott-pilgrim-vs-the-world/mark-as-not-watched/" data-film-link="/film/scott-pilgrim-vs-the-world/" data-film-in-watchlist="false">
                <div>
                  <Link to={`/movie/${movie?.id}`}>
                    <img src={`https://image.tmdb.org/t/p/w342/${movie?.poster_path}`} width="150" height="225" alt={movie?.original_title} srcSet={`https://image.tmdb.org/t/p/w342/${movie?.poster_path}`} className="image"/>
                  </Link>
                </div></div>
            </li>
          })}
        </ul>		
  </section>

  <aside className="sidebar">
		<div className="avatar person-image image-loaded"><img src={`https://image.tmdb.org/t/p/w342/${state[0]?.profile_path}`} className="js-tmdb-person" alt={state[0]?.name} data-tmdb-id="17628" data-size="342"/>
    </div>
		<div className="js-tmdb-person-bio" data-tmdb-id="17628">
      
      <section className="section panel-text condensed">
        <p>
        {state[0]?.biography}
        </p>
        
        <p>
        <br/>
            {state[0]?.deathday === null ? 
            <span>{language === "EN" && "Birth Year" || language === "TR" && "Doğum yili" || language === "DE" && "Geburtsjahr"}: <span style={{color:"rgb(153, 170, 187)"}}>{state[0]?.birthday?.substr(0,4)}</span></span>
            :
            <span>{language === "EN" && "Birth Year" || language === "TR" && "Doğum yili" || language === "DE" && "Geburtsjahr"}: <span style={{color:"rgb(153, 170, 187)"}}>{state[0]?.birthday?.substr(0,4)} - {state[0]?.deathday.substr(0,4)}</span></span> 
          }
          <br/>
          <span>{language === "EN" && "Place of Birth" || language === "TR" && "Doğum yeri" || language === "DE" && "Geburtsort"}: <span style={{color:"rgb(153, 170, 187)"}}>{state[0]?.place_of_birth}</span></span>
        </p>
      </section>
      </div>
		<p className="text-link text-footer">{language === "EN" && "More details at" || language === "TR" && "Daha fazlasi icin" || language === "DE" && "Weitere Details unter"} <a href={`https://www.themoviedb.org/person/${state[0]?.id}/`} className="micro-button">TMDb</a></p>
    	
		
		<section className="progress-panel" data-count="0" data-total="42">
			<div className="progress-status">
				<h3>
        {language === "EN" && "You’ve watched " || language === "TR" && "Izlediniz" || language === "DE" && "Sie haben zugesehen"}
					
					<span className="progress-counter">
						<span className="progress-count"><span className="js-progress-count">{countWatchedMovies}</span> of {movies.length}</span>
						
					</span>
				</h3> 
				
				<p><span className="progress-percentage">{Math.round(countWatchedMovies*100/movies.length)}</span><span className="percent">%</span></p>
			</div>
			<div className="progress-container zero-count">
				<div className="progress-bar" style={{width: "0%"}}></div>
			</div>
		</section>	


<div className="pw-div pw-tag" data-pw-desk="sky_btf" id="pw-160x600_btf" data-google-query-id="CJOk7tjxiPMCFVKGgwcdjhoGrA" style={{display: "none"}}>
  
  <div id="google_ads_iframe_/154013155,12709546/1024338/72804/1024338-72804-160x600_0__container__" style={{border: "0pt none", width: "160px", height: "0px"}}>

  </div>
  </div>
	</aside>
    </div>
      </div> 
    </div> 
  </body>
    </div>
  )
}

