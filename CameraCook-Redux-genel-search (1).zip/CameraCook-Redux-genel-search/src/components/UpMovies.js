import React, { useEffect, useState } from "react";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import "../components/css/LatestMovies.css";

import SingleLatest from "./SingleLatest";
import settings from "./pages/setting.json";
import axios from "axios";
import { Link } from "react-router-dom";

export default function LatestMovies() {
  const [movies, setMovies] = useState([]);
  useEffect(() => {
    const getLatestMovies = async () => {
      try {
        const {
          data: { results },
        } = await axios.get(`
        
        https://api.themoviedb.org/3/movie/now_playing?api_key=${process.env.REACT_APP_API_KEY}&language=tr-TR&page=1`);
        setMovies(results);
      } catch (error) {
        console.log(error);
      }
    };
    getLatestMovies();
  }, []);

  return (
    <div className="main-contens-fav">
      <div className="favourite-contens">
        <div className="headersetting iq-header d-flex align-items-center justify-content-between">
          <h3 className="main-title-latest">Now Playing</h3>
          <a className="iq-view-all" href="#">
            View All
          </a>
        </div>
        <Slider {...settings}>
          {movies.map((movie, index) => (
            <Link
              to={`/movie/${movie.id}`}
              key={index}
              id="ltstbg"
              className="bg-img"
            >
              <SingleLatest {...movie} />
            </Link>
          ))}
        </Slider>
      </div>
    </div>
  );
}
