import React, { useEffect, useMemo, useState } from "react";
import { useSelector } from "react-redux";
import ModalVideo from "react-modal-video";
import "react-modal-video/scss/modal-video.scss";
import { IoMdPlay } from "react-icons/io";
import axios from "axios";

const VideoModal1 = (props) => {
  const [isOpen, setIsOpen] = useState(false);
  const [videoId, setVideoId] = useState("");
  const { language } = useSelector((state) => state.searchMovies);

  useEffect(() => {
    const getTrailer = async () => {
      const { id } = props;
      try {
        const {
          data: { results },
        } = await axios.get(`
        https://api.themoviedb.org/3/movie/${id}/videos?api_key=${process.env.REACT_APP_API_KEY}&language=${
          language.toLowerCase() + "-" + language
        }`);
        setVideoId(
          results.filter(({ site, key }) => site !== "Youtube")[0].key
        );
      } catch (error) {}
    };
    getTrailer();
  }, [props.id,language]);

  
  const openModal = () => {
    setIsOpen(true);
  };
  return (
    <div>
      <div>
        <ModalVideo
          channel="youtube"
          isOpen={isOpen}
          videoId={videoId}
          onClose={() => setIsOpen(false)}
        />
        <a id="slidervideo" className=" btn-hover " onClick={openModal}>
          <IoMdPlay className="io " />
          {language === "EN" && "Watch Trailer" || language === "TR" && "Fragmanı İzle" || language === "DE" && "Trailer Ansehen"}
        </a>
      </div>
    </div>
  );
};

export default VideoModal1;
