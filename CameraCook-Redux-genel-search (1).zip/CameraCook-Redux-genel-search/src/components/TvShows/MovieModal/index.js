import React,{useEffect, useState} from 'react';
import './MovieModal.css';
import { useSelector } from "react-redux";
import Youtube from "react-youtube";
import movieTrailer from "movie-trailer";
import CancelIcon from '@material-ui/icons/Cancel';
import axios from 'axios';

const MovieModal = ({backdrop_path,title,overview,name,release_date,first_air_date,vote_average,setModalVisibility, original_name, id}) => {
    const base_url = "https://image.tmdb.org/t/p/original/";
    const [trailerUrl ,setTrailerUrl] = useState("");
    const [videoId, setVideoId] = useState("");

    const { language } = useSelector((state) => state.searchMovies);

    const opts = {
        height : "390",
        width : "100%",
        playerVars : {
            autoplay : 1,
        },
    }
    const randomPorcentaje = ()=>{
        return Math.floor(Math.random() * 100);
    }

    useEffect(() => {
        const getTrailer = async () => {
          
          try {
            const {
              data: { results },
            } = await axios.get(`
            https://api.themoviedb.org/3/tv/${id}/videos?api_key=${process.env.REACT_APP_API_KEY}&language=${
              language.toLowerCase() + "-" + language
            }`);
            console.log(id)
            console.log(results)
            let filteredResuts = results.filter(({ type, key }) => type === "Trailer")
            setVideoId(
                filteredResuts[filteredResuts.length-1].key
            );
          } catch (error) {}
        };
        getTrailer();
      }, [id,language]);

    // useEffect(() => {
    //     if(trailerUrl){
    //         setTrailerUrl('')
    //     }else{
    //         movieTrailer(title || name || "")
    //         .then(url =>{
    //             //console.log(name)
    //             //console.log(url)
    //             const urlParams = new URLSearchParams(new URL(url).search);
    //             console.log(urlParams.get('v'))
    //             setTrailerUrl(urlParams.get('v'));
    //         }).catch(error => console.log(error))
    //     }
    // }, [])
    
    return (
        <div className="presentation" role="presentation">
            <div id="modal-wrapper" className="wrapper-modal">
                <div  id="modal-tvshow-index" className="modal">
                    <span onClick={()=>setModalVisibility(false)}className="modal-close">
                        <CancelIcon/>
                        </span>  
                        
                    {videoId ? <Youtube videoId={videoId} opts={opts}/> :                     
                        (<img
                        className="modal__poster-img"
                        src={`${base_url}${backdrop_path}`}
                        alt={name}
                    />)}

                    <div className="modal__content">

                        <p className="modal__details"><span className="modal__user-perc">{randomPorcentaje()}% for you</span> {release_date ? release_date : first_air_date}</p>
                        <h2 className="modal__title">{title ? title : name}</h2>
                        <p className="modal__overview" style={{minWidth:"686px"}}>{overview}</p>
                        <p className="modal__overview">Vote Average: {vote_average}</p>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default MovieModal
