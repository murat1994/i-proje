import axios from "axios";

export const searchMovie = async (term, setFunction) => {
  console.log(term);
  try {
    const {
      data: { results },
    } = await axios.get(
      `https://api.themoviedb.org/3/search/multi?api_key=${process.env.REACT_APP_API_KEY}&language=tr-TR&query=${term}`
    );
    setFunction(
      results.map((el) => el.name || el.original_name).filter((el) => !!el)
    );

    console.log(results);
  } catch (error) {
    console.log(error);
  }
};
