export rateMovie=(value)=>{
    
}