import axios from "axios";

export const searchMovie = async (keyTerm) => {
  try {
    const {
      data: { results },
    } = await axios.get(
      `https://api.themoviedb.org/3/search/movie?api_key=${process.env.REACT_APP_API_KEY}&language=en-US&query=${keyTerm}&include_adult=false`
    );
    return results;
  } catch (error) {
    console.log(error);
  }
};
