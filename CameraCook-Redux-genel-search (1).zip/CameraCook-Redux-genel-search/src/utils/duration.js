export const calculateDuration = (runtime) => {
  return runtime < 60
    ? runtime + "m"
    : runtime >= 60
    ? Math.floor(runtime / 60) +
      "h " +
      (runtime - Math.floor(runtime / 60) * 60) +
      " m"
    : null;
};
